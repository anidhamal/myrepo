//
//  ALMediaConnection.h
//  ADL_Core
//
//  Created by Juan Docal on 10.07.14.
//  Copyright (c) 2014 AddLive. All rights reserved.
//

#import "ALService.h"

@interface ALMediaConnection : NSObject

/**
 * A Dictionary having the user current state in which the key
 * will be the user id.
 *
 * `ALUser* userEvent = [usersInSessionList objectForKey:userId]`
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * @since 3.0.1.70
 * @see ALUser
 */
@property (readonly, nonatomic, copy) NSDictionary* usersInSession;

/** @name Publishing & unpublishing media streams */

/**
 * Starts publishing media of a particular type.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working).
 *   May be returned when publishing a video feed.
 *
 * @param Type of media stream to be published.
 * @param options Publishing options. **Not supported.** Set to `nil`.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) publishWithMediaType:(NSString*) what
                      options:(ALMediaPublishOptions*) options
                    responder:(ALResponder*) responder;

/**
 * Starts publishing video.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working).
 *   May be returned when publishing a video feed.
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) publishVideo:(ALResponder*) responder;

/**
 * Starts publishing audio.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working).
 *   May be returned when publishing a video feed.
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) publishAudio:(ALResponder*) responder;

/**
 * Stops publishing a media stream.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param Type of media stream to be unpublished.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) unpublishWithMediaType:(NSString*) what
                      responder:(ALResponder*) responder;

/**
 * Stops publishing video.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working).
 *   May be returned when publishing a video feed.
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) unpublishVideo:(ALResponder*) responder;

/**
 * Stops publishing audio.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working).
 *   May be returned when publishing a video feed.
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) unpublishAudio:(ALResponder*) responder;

/**
 * Updates configuration of the published video stream.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param descriptor New configuration of the video stream
 * @param responder  Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) reconfigureVideoStream: (ALVideoStreamDescriptor*) descriptor
                      responder: (ALResponder*) responder;

/**
 * Sends a custom message to other users connected to the same scope.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param message Raw byte buffer object containing the message.
 * @param recipientId Optional id of recipient. Set to `nil` if message should
 *                    be broadcasted to all participants.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) sendMessage:(NSData*) message
         recipientId:(NSNumber*) recipientId
           responder:(ALResponder*) responder;

/**
 * Disconnects previously established connection to the streaming server.
 *
 * All the resources used by the active session are release. This includes also
 * video sinks associated to the remote peers' video streams.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) disconnect:(ALResponder*) responder;

@end

// =============================================================================

/**
 *
 * Object containing the current state of the user in the session.
 *
 * @since 3.0.1.70
 * @see ALUser#videoPublished
 * @see ALUser#audioPublished
 * @see ALUser#screenPublished
 * @see ALUser#videoSinkId
 * @see ALUser#screenSinkId
 *
 */
@interface ALUser : NSObject

/** @name Properties */

/**
 * ID of a remote user to which this object belongs to.
 *
 * @since 3.0.1.70
 */
@property (nonatomic, assign) long long userId;

/**
 *
 * Flag defining whether the video stream is published by the user.
 *
 * @since 3.0.1.70
 */
@property (nonatomic, assign) BOOL videoPublished;

/**
 *
 * Flag defining whether the audio stream is published by the user.
 *
 * @since 3.0.1.70
 */
@property (nonatomic, assign) BOOL audioPublished;

/**
 *
 * Flag defining whether the screen sharing stream is published by the user.
 *
 * @since 3.0.1.0
 */
@property (nonatomic, assign) BOOL screenPublished;

/**
 *
 * ID of video sink that can be used to render user’s video stream.
 *
 * @since 3.0.1.70
 */
@property (nonatomic, copy) NSString* videoSinkId;

/**
 *
 * ID of video sink that can be used to render user’s screen sharing stream.
 *
 * @since 3.0.1.70
 */
@property (nonatomic, copy) NSString* screenSinkId;

@end
