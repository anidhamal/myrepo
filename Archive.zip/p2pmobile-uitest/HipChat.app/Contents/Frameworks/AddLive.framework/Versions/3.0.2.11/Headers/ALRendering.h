/*
 * Copyright (C) LiveFoundry Inc 2013
 *
 * All rights reserved. Any use, copying, modification, distribution and selling
 * of this software and it's documentation for any purposes without authors'
 * written permission is hereby prohibited.
 */

#import <Foundation/Foundation.h>

#import "ALDataTypes.h"

@class ALService;
@class ALResponder;
/**
 * Structure defining all attributes required to start rendering to a video
 * sink.
 */
@interface ALRenderRequest : NSObject

/** @name Properties */

/**
 * ID of video sink to render.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSString* sinkId;

/**
 * Callback that should be used to indicate the need to redraw the content
 * of the rendering view.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,retain) ALResponder* invalidate;

/**
 * Id of window to which the rendering will be done. OS X only.
 *
 * @sice 3.0.0.0
 */
@property (nonatomic,assign) id windowId;

/**
 * Id of scaling filter. OS X only.
 *
 * @sice 3.0.0.0
 */
@property (nonatomic, copy) NSString* filterId;

/**
 * Flag defining whether the rendering should be mirrored or not. OS X only.
 *
 * @sice 3.0.0.0
 */
@property (nonatomic, assign) BOOL mirror;

/** @name Initialization & disposal */


/**
 * Initialize object with video sink ID and receiver object which receives
 * invalidate calls.
 *
 * @param sId         ID of the video feed. SDK creates an ID for each video
 *                    feed.
 * @param invReceiver A receiver object on which `invalidate` will get called
 *                    when a new frame arrives.
 * @since 1.0.0.0
 */
- (id) initWithSinkId:(NSString*) sId withInvalidateReceiver:(id) invReceiver;

@end // @interface ALRenderRequest

// =============================================================================

/**
 * Defines all attributes needed to redraw the video feed.
 */
@interface ALDrawRequest : NSObject

/** @name Properties */

/**
 * Top rendering margin.
 *
 * Only zero allowed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int top;

/**
 * Left rendering margin.
 *
 * Only zero allowed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int left;

/**
 * Bottom rendering margin.
 *
 * The height of the video feed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int bottom;

/**
 * Right rendering margin.
 *
 * The width of the video feed.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) int right;

/**
 * The OpenGL texture ID for the Y component of the video feed.
 *
 * Texture format: GL_RED_EXT.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) unsigned int glTextureY;

/**
 * The OpenGL texture ID for the UV components of the video feed.
 *
 * Texture format: GL_RG_EXT.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,assign) unsigned int glTextureUV;

/**
 * ID of renderer which should be affected by the Draw request.
 *
 * @since 1.0.0.0
 */
@property (nonatomic,copy) NSNumber* rendererId;

@property (nonatomic, assign) id windowHandle;

/** @name Initialization & disposal */

/**
 * Initialize object with given renderer ID.
 *
 * @param rId Renderer ID.
 * @since 1.0.0.0
 */
- (id) initWithRendererId:(NSNumber*) rId;

@end // @interface ALDrawRequest

// =============================================================================


