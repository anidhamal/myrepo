/*
 * Copyright (C) LiveFoundry Inc 2013
 *
 * All rights reserved. Any use, copying, modification, distribution and selling
 * of this software and it's documentation for any purposes without authors' written
 * permission is hereby prohibited.
 */

#import "ALRendering.h"
#import "ALDataTypes.h"
#import "ALEvents.h"

typedef id(^DataConverter)(id);

typedef void(^ResultBlock)(ALError*, id);

/**
 * Delegates a response to given selector and object. Used for all asynchronous
 * calls into the AddLive SDK.
 *
 * The ALResponder interface is responsible for receiving results (both success
 * or failure) from all asynchronous method provided by the ALService interface.
 *
 * ### See Also:
 *
 * - ALService
 *
 * @since 1.0.0.0
 */
@interface ALResponder : NSObject

/** @name Properties */

/**
  * The selector the response is sent to.
  *
  * @since 1.0.0.0
  */
@property (nonatomic,assign) SEL sel;

/**
  * The object the response is sent to.
  *
  * @since 1.0.0.0
  */
@property (nonatomic,retain) id obj;

/**
  * A boolean flag defining whether the response should be dispatched using the
  * main thread or not.
  *
  * @since 1.0.0.0
  */
@property (nonatomic,assign) BOOL dis;

/**
  *
  * @since 3.0.0.0
  */
@property(readwrite, copy) ResultBlock resultHandler;

/** @name Initialization & disposal */

/**
 * Returns autoreleased and initialized ALResponder object. Dispatches response
 * to main thread.
 *
 * @param selector Method to which the response should be delegated to.
 * @param object   Object to which the response should be delegated to.
 * @since 1.0.0.0
 */
+ (ALResponder*) responderWithSelector:(SEL) selector
        object:(id) object;

/**
 * Initialize with given selector and object. Dispatches response to main
 * thread.
 *
 * @param selector Method to which the response should be delegated to.
 * @param object   Object to which the response should be delegated to.
 * @since 1.0.0.0
 */
- (id) initWithSelector:(SEL) selector
             withObject:(id) object;

/**
 * Initialize with given selector, object and dispatch to main thread flag.
 *
 * @param selector   Method to which the response should be delegated to.
 * @param object     Object to which the response should be delegated to.
 * @param dispatcher Boolean indicating if the response should be dispatched to
 *                   the main thread.
 * @since 1.0.0.0
 */
- (id) initWithSelector:(SEL) selector
             withObject:(id) object
         withDispatcher:(BOOL) dispatcher;


/**
 * Creates a responder that will delagete a result to the result block given.
 *
 * @param resultBlock Block that will be called on result.
 * @since 3.0.0.0
 */
+ (id) responderWithBlock:(ResultBlock) resultBlock;


/**
 * Initialize the responder with a block given. The result will be delageted to the block.
 *
 * @param resultBlock Block that will be called on result.
 * @since 3.0.0.0
 */
- (id) initWithResultBlock:(ResultBlock) resultBlock;

// To be used by platform
- (void) result:(id) result;
- (void) result;
- (void) error: (ALError*) error;
- (void) setConverter: (DataConverter) converter;

@end // @interface ALResponder

// =============================================================================

/**
 * AddLive service interface.
 *
 * The ALService interface provides an access to all core functionality of the
 * AddLive SDK. It allows developers to:
 *
 * - initialize the SDK
 * - configure ALServiceListener to receive global notifications
 * - control video and audio devices
 * - start local video preview
 * - connect to the AddLive media scopes and exchange media streams with other
 *   peers
 * - send messages between peers connected to the same media scope
 *
 * ### Platform initialization
 *
 * The method initPlatform should be used to perform the complete AddLive
 * Service initialization. Following snipped provides a quick example of how
 * this can be achieved:
 *
 * <div class="hlcode">
 * <div class="syntax"><pre><span class="n">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">initAddLive</span>
 * <span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Prepare the platform options</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="nc">ALInitOptions</span><span class="o">*</span> <span class="n">options</span> <span class="o">=</span> <span class="p">[[[</span><span class="nc">ALInitOptions</span> <span class="nm">alloc</span><span class="p">]</span> <span class="n">init</span><span class="p">]</span> <span class="n">autorelease</span><span class="p">];</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="n">options</span><span class="p">.</span><span class="n">applicationId</span> <span class="o">=</span> <span class="p">[</span><span class="nc">NSNumber</span> <span class="nm">numberWithInt</span><span class="o">:</span><span class="mi">123</span><span class="p">];</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="n">options</span><span class="p">.</span><span class="n">apiKey</span> <span class="o">=</span> <span class="s">@"API Key as given during registration"</span><span class="p">;</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="n">options</span><span class="p">.</span><span class="n">cameraFollowsOrientation</span> <span class="o">=</span> <span class="kt">YES</span><span class="p">;</span><br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Prepare the responder that will delegate to [self onPlatformReady]</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="nc">ALResponder</span><span class="o">*</span> <span class="n">responder</span> <span class="o">=</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">[[[</span><span class="nc">ALResponder</span> <span class="nm">alloc</span><span class="p">]</span> <span class="nm">initWithSelector</span><span class="o">:</span><span class="k">@selector</span><span class="p">(</span><span class="n">onPlatformReady</span><span class="o">:</span><span class="p">)</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="nm">withObject</span><span class="o">:</span><span class="kt">self</span><span class="p">]</span> <span class="n">autorelease</span><span class="p">];</span><br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Instantiate ALService</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="ncv">_service</span><span class="o">=</span> <span class="p">[</span><span class="nc">ALService</span> <span class="nm">alloc</span><span class="p">];</span><br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// And finally request the initialization</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">[</span><span class="ncv">_service</span> <span class="nm">initPlatform</span><span class="o">:</span><span class="n">options</span> <span class="n">responder</span><span class="o">:</span><span class="n">responder</span><span class="p">];</span><br/>
 * <span class="p">}</span><br/>
 * <span class="n">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">onPlatformReady:</span><span class="p">(</span><span class="nc">ALError</span><span class="o">*</span><span class="p">)</span> <span class="n">err</span>
 * <span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Check whether the initialization was successful</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="k">if</span> <span class="p">(</span><span class="n">err</span><span class="p">)</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p">[</span><span class="kt">self</span> <span class="nm">showError</span><span class="o">:</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p">[</span><span class="nc">NSString</span> <span class="nm">stringWithFormat</span><span class="o">:</span><span class="s">@"Failed to initialize the SDK. &lt;%@&gt;"</span><span class="p">,</span> <span class="n">err</span><span class="p">]];</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="k">return</span><span class="p">;</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">}</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="ng">NSLog</span><span class="p">(</span><span class="s">@"AddLive platform is now initialised and functional"</span><span class="p">);</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// More initialisation code goes here.</span>
 * <span class="p">}</span>
 * </pre></div>
 * </div>
 *
 * ### Calling service methods
 *
 * It is important to note that all the functionality provided by the ALService
 * listener uses asynchronous interface, where the actual result of method call
 * is passed to an instance of the ALResponder interface passed as the last
 * parameter to every method. See example below on how to make a calls to
 * ALService methods:
 *
 * <div class="hlcode">
 * <div class="syntax"><pre><span class="n">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">getVersion</span>
 * <span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Prepare the responder</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="nc">ALResponder</span><span class="o">*</span> <span class="n">responder</span> <span class="o">=</span> <span class="p">[[[</span><span class="nc">ALResponder</span> <span class="nm">alloc</span><span class="p">]</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="nl">initWithSelector:</span><span class="k">@selector</span><span class="p">(</span><span class="n">onGetVersion</span><span class="o">:</span><span class="n">version</span><span class="o">:</span><span class="p">)</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="nl">withObject:</span><span class="kt">self</span><span class="p">]</span> <span class="n">autorelease</span><span class="p">];</span><br/>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Call the service method</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">[</span><span class="ncv">_service</span> <span class="nm">getVersion</span><span class="o">:</span><span class="n">responder</span><span class="p">];</span>
 * <span class="p">}</span><br/>
 * <span class="n">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">onGetVersion:</span><span class="p">(</span><span class="nc">ALError</span><span class="o">*</span><span class="p">)</span> <span class="n">err</span> <span class="n">version</span><span class="o">:</span><span class="p">(</span><span class="nc">NSString</span><span class="o">*</span><span class="p">)</span> <span class="n">version</span>
 * <span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="c1">// Check whether it was an error or success result</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="k">if</span> <span class="p">(</span><span class="n">err</span><span class="p">)</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="ng">NSLog</span><span class="p">(</span><span class="s">@"Got error result of getVersion call: %@"</span><span class="p">,</span> <span class="n">err</span><span class="p">);</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">}</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="k">else</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">{</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="ng">NSLog</span><span class="p">(</span><span class="s">@"Got service version: %@"</span><span class="p">,</span> <span class="n">version</span><span class="p">);</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="p">[</span><span class="ncv">_version</span> <span class="nm">release</span><span class="p">];</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="ncv">_version</span> <span class="o">=</span> <span class="p">[</span><span class="n">version</span> <span class="nm">copy</span><span class="p">];</span>
 * &nbsp;&nbsp;&nbsp;&nbsp;<span class="p">}</span>
 * <span class="p">}</span>
 * </pre></div>
 *
 * </div>
 */
@interface ALService : NSObject

/**
 * A boolean flag defining whether the SDK is ready or not.
 *
 * @since 3.0.1.70
 */
@property (nonatomic, assign) BOOL ready;

/** @name Initialization & disposal */

/**
 * Intializes the ALService object with the application ID. Using this method
 * to initialize the AddLive service requires the application to set the
 * authentication signature explicitly.
 *
 * #### Deprecated
 * Since 2.0.3.10 Use just the initPlatform and new `ALInitOptions` properties:
 * `[ALInitOptions applicationId]` and `[ALInitOptions apiKey]`.
 *
 * @param aId An integer identifying the application.
 */
- (id) initWithAppId:(NSNumber*) aId;

/**
 * Intializes the ALService object with tje application ID and the application's
 * secret key.
 *
 * #### Deprecated
 * Since 2.0.3.10 Use just the initPlatform and new `ALInitOptions` properties:
 * `[ALInitOptions applicationId]` and `[ALInitOptions apiKey]`.
 *
 * @param aId An integer identifying the application.
 * @param aKey A secret key used for signing the authentication token.
 */
- (id) initWithAppId:(NSNumber*) aId appKey:(NSString*) aKey;

/** @name SDK initialization & disposal */

/**
 * Get a singleton instance of ALService - [ALService sharedInstance]
 *
 * When using it, all the ALService methods must be call as the following example:
 *
 * `[[ALService sharedInstance] getVersion:responder]`
 *
 * @since 3.0.1.70
 */
+ (instancetype) sharedInstance;

/**
 * Initializes the AddLive SDK using options provided.
 *
 * The initPlatform method needs to be called before accessing any other
 * ALService methods.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   In case of invalid options given.
 *
 * @param options Initialization options.
 * @param responder Responder that will handle platform initialization status.
 *
 *     `(void) response:(ALError*) err;`
 *
 * @sa ALInitOptions
 * @since 1.0.0.0
 */
- (void) initPlatform:(ALInitOptions*) options
            responder:(ALResponder*) responder;

/**
 * Initializes the the AddLive Service singleton and SDK using options provided
 * via class method. `[ALService initPlatform:options responder:responder]`
 *
 * The initPlatform method needs to be called before accessing any other
 * ALService methods.
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   In case of invalid options given.
 *
 * @param options Initialization options.
 * @param responder Responder that will handle platform initialization status.
 *
 *     `(void) response:(ALError*) err;`
 *
 * @sa ALInitOptions
 * @since 3.0.1.70
 */
+ (void) initPlatform:(ALInitOptions*) options
            responder:(ALResponder*) responder;

/**
 * Releases the AddLive SDK.
 *
 * All the resources used by the platform will be freed and it won't be possible
 * to perform any SDK operations until the service will be initialized again.
 *
 * ### Important note
 *
 * Please note that the releasePlatform method __CANNOT__ be called from within
 * AddLive result handler or event handler. E.g.:
 *
 * <div class="hlcode">
 * <div class="syntax"><pre><span class="k">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">getVersionBad</span> <span class="p">{</span>
 * &nbsp;&nbsp;<span class="p">[</span><span class="n">_alService</span> <span class="nm">getVersion</span><span class="o">:</span><span class="p">[[</span><span class="nc">ALResponder</span> <span class="nm">alloc</span><span class="p">]</span> <span class="nm">initWithSelector</span><span class="o">:</span><span class="k">@selector</span><span class="p">(</span><span class="n">onVersionBad</span><span class="o">:</span><span class="n">v</span><span class="o">:</span><span class="p">)</span> <span class="n">withObject</span><span class="o">:</span> <span class="kt">self</span><span class="p">]];</span>
 * <span class="p">}</span><br/>
 * <span class="k">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">onVersionBad:</span> <span class="p">(</span><span class="nc">ALError</span><span class="o">*</span><span class="p">)</span><span class="nv">err</span> <span class="nf">v:</span><span class="p">(</span><span class="nc">NSString</span><span class="o">*</span><span class="p">)</span> <span class="n">version</span> <span class="p">{</span>
 * &nbsp;&nbsp;<span class="c1">// !!!! Bad things will happen</span>
 * &nbsp;&nbsp;<span class="p">[</span><span class="n">_alService</span> <span class="nm">releasePlatform</span><span class="p">];</span>
 * <span class="p">}</span>
 * </pre></div>
 * </div>
 *
 * The above example will cause a deadlock, as the releasePlatform tries to
 * stop and join thread processing the result handler. The best way to overcome
 * this limitation is to delay the processing:
 *
 * <div class="hlcode">
 * <div class="syntax"><pre><span class="k">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="nf">onVersionOK:</span> <span class="p">(</span><span class="n">ALError</span><span class="o">*</span><span class="p">)</span><span class="nv">err</span> <span class="nf">v:</span><span class="p">(</span><span class="n">NSString</span><span class="o">*</span><span class="p">)</span> <span class="n">version</span> <span class="p">{</span>
 * &nbsp;&nbsp;<span class="c1">// All will be fine - release platform will be done on main thread</span>
 * &nbsp;&nbsp;<span class="p">[</span><span class="kt">self</span> <span class="nm">performSelector</span><span class="o">:</span> <span class="k">@selector</span><span class="p">(</span><span class="n">disposePlatform</span><span class="p">)</span> <span class="n">withObject</span><span class="o">:</span><span class="kt">self</span> <span class="n">afterDelay</span><span class="o">:</span><span class="mf">0.1</span><span class="p">]</span> <span class="p">;</span>
 * <span class="p">}</span><br/>
 * <span class="o">-</span> <span class="p">(</span><span class="kt">void</span><span class="p">)</span> <span class="n">disposePlatform</span> <span class="p">{</span>
 * &nbsp;&nbsp;<span class="p">[</span><span class="n">_alService</span> <span class="nm">releasePlatform</span><span class="p">];</span>
 * <span class="p">}</span>
 * </pre></div>
 * </div>
 *
 * @since 1.0.0.0
 */
- (void) releasePlatform;

/** @name Misc operations */

/**
 * Retrieves the version of the SDK.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err version:(NSString*) version);`
 * @since 1.0.0.0
 */
- (void) getVersion:(ALResponder*) responder;


/**
 * Registers a listener object for global SDK events (e.g. user joined/left
 * scope, user published/unpublished stream, ...).
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   In case the listener given does not conform to the ALServiceListener
 *   protocol.
 *
 * @param listener Object implementing the ALServiceListener protocol.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 * @see ALServiceListener
 */
- (void) addServiceListener:(id<ALServiceListener>) listener
                  responder:(ALResponder*) responder;

/**
 * Removes the previously registered listener object for global SDK events (e.g. user joined/left
 * scope, user published/unpublished stream, ...).
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   In case the listener given does not conform to the ALServiceListener
 *   protocol.
 *
 * @param listener Object implementing the ALServiceListener protocol.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.0.23
 * @see ALServiceListener
 */
- (void) removeServiceListener:(id<ALServiceListener>) listener
                  responder:(ALResponder*) responder;

/**
 * Retrieves the ALMediaConnection instance of a given scope id.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * @param scopeId ID of the capture device to be set.
 * @since 3.0.1.70
 */
- (id) getConnectionByScope:(NSString *) scopeId;

/** @name Hardware devices configuration */

/**
 * Retrieves the list of currently available video capture devices.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err devices:(NSArray*) devices;`
 *
 * Parameter `devices` contains an array of ALDevice.
 * @since 1.0.0.0
 */
- (void) getVideoCaptureDeviceNames:(ALResponder*) responder;

/**
 * Sets the video capture device to be used by platform.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working)
 *
 * @param deviceId ID of the capture device to be set.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) setVideoCaptureDevice:(NSString*) deviceId
         responder:(ALResponder*) responder;

/**
 * Gets the video capture device currently used by the platform.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSString*) device;`
 * @since 1.0.0.0
 */
- (void) getVideoCaptureDevice:(ALResponder*) responder;

/**
 * Retrieves the list of currently available audio capture devices (microphones).
 *
 * #### Availability:
 *
 * - iOS: NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err devices:(NSArray*) devices;`
 *
 * Parameter `devices` contains an array of ALDevice.
 * @since 1.0.0.0
 */
- (void) getAudioCaptureDeviceNames:(ALResponder*) responder;

/**
 * Sets the audio capture device (microphone) to be used by platform.
 *
 * #### Availability:
 *
 * - iOS: NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working)
 *
 * @param deviceId ID of the capture device to be set.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) setAudioCaptureDevice:(NSString*) deviceId
                     responder:(ALResponder*) responder;

/**
 * Gets the audio capture device (microphone) currently used by the platform.
 *
 * #### Availability:
 *
 * - iOS: NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSString*) device;`
 * @since 1.0.0.0
 */
- (void) getAudioCaptureDevice:(ALResponder*) responder;

/**
 * Retrieves the list of currently available audio output devices (speakers).
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err devices:(NSArray*) devices;`
 *
 * Parameter `devices` contains an array of ALDevice.
 * @since 1.0.0.0
 */
- (void) getAudioOutputDeviceNames:(ALResponder*) responder;

/**
 * Sets the audio output device (speakers) to be used by platform.
 *
 * Please note that on iOS 7 and above, calling this method has a side effect of modifing the configuration of the
 * `AVAudioSession`. Changing the audio output device to the loud speaker will change the `AVAudioSession` mode to 
 * `AVAudioSessionModeVideoChat`. On the other hand changing it to frontSpeaker will change the mode to 
 * `AVAudioSessionModeVoiceChat`.
 *
 * The frontSpeaker requires mode `AVAudioSessionModeVoiceChat` as the front speaker does not work at all when in
 * the `AVAudioSessionModeVideoChat`. On the other hand, loud speaker works best in the `AVAudioSessionModeVideoChat` 
 * mode as in the `AVAudioSessionModeVoiceChat` the AirPlay mirroring does not work.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working)
 *
 * @param deviceId ID of the capture device to be set.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) setAudioOutputDevice:(NSString*) deviceId
                     responder:(ALResponder*) responder;

/**
 * Gets the audio output device (speakers) currently used by the platform.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSString*) device;`
 * @since 1.0.0.0
 */
- (void) getAudioOutputDevice:(ALResponder*) responder;


/**
 * Gets the list of all available screen sharing soures. Screen sharing source can be either
 * an application window or a complete desktop.
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param thumbWidth width of the screen shot thumbnail
 * @param responder  Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSArray*) sources;`
 * @since 3.0.0.0
 * @see ALScreenCaptureSource
 * @see `[ALService publish:what:options:responder:]`
 */
- (void) getScreenCaptureSources: (NSNumber*) thumbWidth responder:(ALResponder*) responder;


/**
 * Returns the volume of the audio speakers. The volume is a normalised value in range 0-255.
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSNumber*) volume;`
 * @since 3.0.0.0
 */
- (void) getSpeakersVolume: (ALResponder*) responder;

/**
 * Sets the volume of the audio speakers. The volume is a normalised value in range 0-255.
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * 
 * @param volume    the new volume value to be set
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.0.0
 */
- (void) setSpeakersVolume: (NSNumber*) volume responder:(ALResponder*) responder;

/**
 * Returns the microphone gain level. The volume is a normalised value in range 0-255.
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSNumber*) volume;`
 * @since 3.0.0.0
 */
- (void) getMicrophoneVolume: (ALResponder*) responder;

/**
 * Sets the microphone gain level. The volume is a normalised value in range 0-255.
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param volume    the new gain value to be set
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSNumber*) volume;`
 * @since 3.0.0.0
 */
- (void) setMicrophoneVolume: (NSNumber*) volume responder:(ALResponder*) responder;


/**
 * Starts monitoring microphone activity, the speech level of local user.
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param enable    boolean flag defining whether the monitoring should be started (YES) or 
 *                  stopped (NO)
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSNumber*) volume;`
 * @since 3.0.0.0
 */
- (void) monitorMicActivity: (BOOL) enable responder:(ALResponder*) responder;

/**
 * Controls monitoring of speech activity within given scope.
 *
 * The monitorSpeechActivity allows application to enable or disable monitoring of the speech. Once the
 * monitoring is enabled, every registered `ALServiceListener` instance will receive speech activity events via
 * `[ALServiceListener onSpeechActivity:]` method. The speech activity monitoring provides information about
 * speech level of every user in session (including local user) and also a list of active speakers.
 *
 * #### Availability:
 *
 * - iOS:  YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * @param scopeId   Scope ID to control the speech activity monitoring of.
 * @param enable    boolean flag defining whether the monitoring should be started (YES) or
 *                  stopped (NO)
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.0.14
 */
- (void) monitorSpeechActivity:(NSString*) scopeId
                        enable:(BOOL) enable
                     responder:(ALResponder*) responder;

/**
 * Returns a dictionary containing details about the host computer CPU. It contains following keys:
 *
 * brand_string: CPU label, e.g. 'Intel(R) Core(TM) i5 CPU M 430 @ 2.27GHz'
 * clock: CPU clock speed, in MHz. e.g. 2261
 * cores: the amount of processing cores
 * extfamily:0,
 * extmodel:2,
 * family:6,
 * model:5,
 * stepping:2,
 * vendor:'GenuineIntel'
 *
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSNumber*) volume;`
 * @since 3.0.0.0
 */
- (void) getHostCpuDetails: (ALResponder*) responder;


/**
 * Plays sample sound. Useful when testing speakers.
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *
 * #### Availability:
 *
 * - iOS:  NO
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err device:(NSNumber*) volume;`
 * @since 3.0.0.0
 */
- (void) playTestSound: (ALResponder*) responder;

/**
 * Sets the noise suppression mode.
 *
 * @param mode Noise suppression mode NSMode.
 * @param responder Responder object that will receive asynchronous call result.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 *     `(void) response:(ALError*) err;`
 */
- (void) setNSMode:(NSInteger) mode
         responder:(ALResponder*) responder;


/** @name Local video preview */


/**
 * Starts local video preview from camera device.
 *
 * Internally, this method:
 *
 * - checks whether selected video capture device is enabled and captures
 *   frames. If not, enables it.
 * - checks whether local preview video sink is created or not. If not, creates
 *   one and links it to the video capture device
 * - returns the sink id.
 *
 * The video sink id should be used to render the video sink. To render it,
 * application needs to be attach it to the `ALVideoView` responsible for
 * rendering the local preview video feed. This can be done using the
 * `[ALVideoView setupWithService:withSink:]`.
 *
 * To stop the rendering, the stopLocalVideo method should be used.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working)
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err videoSinkId:(NSString*) videoSinkId;`
 * @since 1.0.0.0
 * @see ALVideoView
 * @see [ALVideoView setupWithService:withSink:]
 * @see [ALService stopLocalVideo:]
 * @see [ALService setVideoCaptureDevice:responder:]
 */
- (void) startLocalVideo:(ALResponder*) responder;

/**
 * Stops local video preview from camera device.
 *
 * Please note that after calling this method, all the `ALVideoView` attached
 * to the local video sink will be simply frozen.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 * @see [ALService startLocalVideo:]
 */
- (void) stopLocalVideo:(ALResponder*) responder;


/** @name Connectivity & Networking */

/**
 * Establishes a connection to the streaming server using given description.
 * This is the most important method of all provided by the AddLive Service API,
 * as it allows the application to start video conference with other
 * participants.
 *
 * #### Scopes and Sessions
 *
 * The AddLive Platform for media streaming uses two important concepts:
 * __session__ and __scope__. The concept of __scope__ can be explained simply
 * as a virtual chat room. To have a video conference with other peers, all the
 * peers involved shoud be connecte to the same scope - should join the same
 * virtual meeting room.
 *
 * On the other hand, the __session__ can be seen as an active conference with
 * in particular __scope__.
 *
 * #### Connection descriptor
 *
 * The only one input parameter, connectionDescriptor completely
 * describes client requirements on the connection to be established. For more
 * details, please refer to the documentation of the `ALConnectionDescriptor`.
 *
 * ####  Video streams configuration
 *
 * During the connection setup, the client application can configure the quality
 * of the video stream published within the session. The connection
 * establishment is the only point where the video stream configuration is
 * possible. Once the connection is setup, there is no way to reconfigure the
 * video streams.
 *
 * For more details on how to configure video stream, please
 * refer to the documentation of the `ALVideoStreamDescriptor` interface.
 *
 * #### Authentication
 *
 * Within the AddLive platform, every connection attempt needs to be
 * authenticated. The authentication scheme employed allows the application to
 * build virtually any Access Control mechanism, without the need to communicate
 * between the application infrastructure and the AddLive Streaming Server.
 * Instead, to authenticate the connection, the application should provide the
 * authentication signature, which is calculated using all the details of
 * connection to be made and a shared secret - API key given during application
 * creation.
 *
 * For more details on how to prepare the authentication signature, please
 * refer to the documentation of the `ALAuthDetails` interface.
 *
 * #### Notifications
 *
 * The `ALService` interface, uses all registered `ALServiceListener` listeners
 * to notify the application about any change in remote participants
 * configuration. This includes events related to:
 *
 * - remote peer joining the session (reported using
 *   `[ALServiceListener onUserEvent:]`, with
 *   `[ALUserStateChangedEvent isConnected]` set to `YES`),
 * - remote peer leaving the session (reported using
 *   `[ALServiceListener onUserEvent:]`, with
 *   `[ALUserStateChangedEvent isConnected]` set to `NO`),
 * - remote peer publishing a media stream within session (reported using
 *   `[ALServiceListener onMediaStreamEvent:]`),
 * - remote peer stopping publishing a media stream within the session
 *   (reported using `[ALServiceListener onMediaStreamEvent:]`),
 *
 * #### Connection lost
 *
 * Please note that it is possible to lose a connection to the Streamer. This
 * may be caused either by device losing Internet connectivity or other
 * network equipment (pccess point, router) error. In this case the application
 * will be notified using the `[ALServiceListener onConnectionLost:]`
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working)
 *
 * - `ALErrorCodes` `kCommInvalidHost`<br/>
 *   Indicates failure in DNS lookup of host specified in the url or streamer
 *   box being off-line
 *
 * - `ALErrorCodes` `kCommInvalidPort`<br/>
 *   Indicates that service failed to connect to the streaming server. Either
 *   the traffic gets blocked by the firewall or streaming server is down
 *
 * - `ALErrorCodes` `kCommBadAuth`<br/>
 *   Indicates authentication error. There might be 4 reasons for rejected
 *   authentication signature: no authentication signature was provided,
 *   the application with given id is unknown, the signature calculated was
 *   invalid and finally, the authentication signature was expired. The actual
 *   cause of the authentication rejection will be provided using the
 *   <strong>errMessage</strong>.
 *
 * - `ALErrorCodes` `kCommMediaLinkFailure`<br/>
 *   Indicates failure in establishing media connection. It means that the
 *   media streams are blocked somewhere on the path between the user and
 *   the streaming server. Most likely, it's due to a firewall blocking media
 *   traffic.
 *
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   Invalid connection descriptor given.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param descriptor Connection descriptor.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 * @see [ALService disconnect:responder:]
 * @see [ALService publish:what:options:responder:]
 * @see [ALService unpublish:what:responder:]
 * @see [ALService sendMessage:message:recipientId:responder:]
 * @see [ALService setAllowedSenders:mediaType:userIds:responder:]
 * @see [ALServiceListener onUserEvent:]
 * @see [ALServiceListener onMediaStreamEvent:]
 * @see [ALServiceListener onConnectionLost:]
 */
- (void) connect:(ALConnectionDescriptor*) descriptor
       responder:(ALResponder*) responder;

/**
 * Disconnects previously established connection to the streaming server.
 *
 * All the resources used by the active session are release. This includes also
 * video sinks associated to the remote peers' video streams.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId ID of scope identifing the connection to be terminated.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) disconnect:(NSString*) scopeId
          responder:(ALResponder*) responder;

/**
 * Disconnects previously established connection to the streaming server once
 * the timeout is reached.
 *
 * All the resources used by the active session are release. This includes also
 * video sinks associated to the remote peers' video streams.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId ID of scope identifing the connection to be terminated.
 * @param timeout Time in milliseconds to perform the disconnection.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) deferredDisconnect:(NSString*) scopeId
               milliseconds:(NSNumber*) timeout
                  responder:(ALResponder*) responder;

/**
 * Cancels the deferred disconnection if the timeout hasn't been reached.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId ID of scope identifing the connection to be terminated.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.70
 */
- (void) cancelDeferredDisconnect:(NSString*) scopeId
                        responder:(ALResponder*) responder;

/** @name Publishing & unpublishing media streams */

/**
 * Starts publishing media of a particular type.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * - `ALErrorCodes` `kMediaInvalidVideoDev` <br/>
 *   In case there was an error using currently selected video capture device
 *   (e.g. device in use by different application or just stopped working).
 *   May be returned when publishing a video feed.
 *
 * @param scopeId ID of scope to which media stream should be published.
 * @param what Type of media stream to be published.
 * @param options Publishing options. **Not supported.** Set to `nil`.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) publish:(NSString*) scopeId
            what:(NSString*) what
         options:(ALMediaPublishOptions*) options
       responder:(ALResponder*) responder;

/**
 * Stops publishing a media stream.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId ID of scope to which media stream should be unpublished.
 * @param what Type of media stream to be unpublished.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) unpublish:(NSString*) scopeId
        what:(NSString*) what
   responder:(ALResponder*) responder;

/**
 * Updates configuration of the published video stream.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId    ID of scope to which media stream should be unpublished.
 * @param descriptor New configuration of the video stream
 * @param responder  Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) reconfigureVideo: (NSString*) scopeId
              videoStream: (ALVideoStreamDescriptor*) descriptor
                responder: (ALResponder*) responder;


/**
 * Sends a custom message to other users connected to the same scope.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId ID of scope to which message should be broadcasted.
 * @param message Raw byte buffer object containing the message.
 * @param recipientId Optional id of recipient. Set to `nil` if message should
 *                    be broadcasted to all participants.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) sendMessage:(NSString*) scopeId
             message:(NSData*) message
         recipientId:(NSNumber*) recipientId
           responder:(ALResponder*) responder;

/**
 * Sets proxy server settings for the networking operations.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param proxyType Type of proxy ("https" or "socks")
 * @param host      IP address string of proxy endpoint.
 * @param port      Proxy server listening port.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) setProxyServer:(NSString*) proxyType
                   host:(NSString*) host
                   port:(NSNumber*) port
              responder:(ALResponder*) responder;


/**
 * Sets proxy server credentials for the networking operations.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param userName user name part of the credentials
 * @param password password part of the credentials
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.1.19
 */- (void) setProxyCredentials:(NSString*) userName
                    password:(NSString*) password
                   responder:(ALResponder*) responder;
/**
 * Sets the list of users that are allowed to send video streams to local
 * client.
 *
 * Default is to allow all users to send video streams. This method should be
 * used when the application needs to render only subset of the video feeds
 * available within a particular scope. Remote video feeds that are disallowed
 * will not be processed at all vastly reducing the CPU and network utilisation.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId Scope ID for which this restriction will be applied.
 * @param mediaType type of media affected (audio or video)
 * @param userIds Array of user IDs which are allowed so send video.
 * @param responder Responder object that will receive asynchronous call result
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) setAllowedSenders:(NSString*) scopeId
                 mediaType:(NSString*) mediaType
                   userIds:(NSArray*) userIds
                 responder:(ALResponder*) responder;

/**
 * Enables media statistics reporting.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId Scope ID to enable stats reporting on.
 * @param interval Time interval in seconds of how often stats should be
 *                 reported.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) startMeasuringStats:(NSString*) scopeId
                    interval:(NSNumber*) interval
                   responder:(ALResponder*) responder;

/**
 * Enables media statistics reporting.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId Scope ID to enable stats reporting on.
 * @param interval Time interval in seconds of how often stats should be
 *                 reported.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 3.0.0.0
 */
- (void) startMeasuringStatsistics:(NSString*) scopeId
                          interval:(NSNumber*) interval
                         responder:(ALResponder*) responder;

/**
 * Disables media statistics reporting.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidScope`<br/>
 *   The ALService is not connected to scope with given id.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param scopeId Scope ID to disable stats reporting on.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) stopMeasuringStats:(NSString*) scopeId
                  responder:(ALResponder*) responder;

/** @name Network quality test */

/**
 * Runs a network quality test to the AddLive media streamer.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kCommInvalidHost`<br/>
 *   Indicates failure in DNS lookup of host specified in the url or streamer
 *   box being off-line
 *
 * - `ALErrorCodes` `kCommInvalidPort`<br/>
 *   Indicates that service failed to connect to the streaming server. Either
 *   the traffic gets blocked by the firewall or streaming server is down
 *
 * - `ALErrorCodes` `kCommBadAuth`<br/>
 *   Indicates authentication error. There might be 4 reasons for rejected
 *   authentication signature: no authentication signature was provided,
 *   the application with given id is unknown, the signature calculated was
 *   invalid and finally, the authentication signature was expired. The actual
 *   cause of the authentication rejection will be provided using the
 *   <strong>errMessage</strong>.
 *
 * - `ALErrorCodes` `kCommMediaLinkFailure`<br/>
 *   Indicates failure in establishing media connection. It means that the
 *   media streams are blocked somewhere on the path between the user and
 *   the streaming server. Most likely, it's due to a firewall blocking media
 *   traffic.
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param bitrateInKbps The test sends packets up to the specified rate.
 * @param authDetails Authentication details to connect to the media streamer.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err quality:(NSNumber*) quality;`
 * @since 2.0.2.0
 */
- (void) networkTest:(NSNumber*) bitrateInKbps
         authDetails:(ALAuthDetails*) authDetails
           responder:(ALResponder*) responder;


/** @name Setting & getting custom platform properties */

/**
 * Sets custom platform property, allowing platform fine tune configuration.
 *
 * For example the speaker can be switched on and off using the property key
 * `global.dev.audio.enableSpeaker` with value set to 1 or 0.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   Indicates an unknown or not supported key
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param key Key of the property.
 * @param val New value of the property.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) setProperty:(NSString*) key
               value:(NSString*) val
           responder:(ALResponder*) responder;

/**
 * Gets value of a custom platform property.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * #### Possible errors:
 *
 * - `ALErrorCodes` `kLogicInvalidArgument`<br/>
 *   Indicates an unknown or not supported key
 *
 * - `ALErrorCodes` `kUnknownError`<br/>
 *   If an unexpected, internal error occurs
 *
 * @param key Key of the property to get.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err value:(NSString*) value;`
 * @since 1.0.0.0
 */
- (void) getProperty:(NSString*) key
           responder:(ALResponder*) responder;

/** @name Rendering video feeds */

/**
 * Starts rendering a video sink.
 *
 * The SDK returns a renderer ID with the response. The renderer ID is needed
 * when drawing the video feed to a texture. See also ALDrawRequest and method
 * draw:.
 *
 * __Note__
 *
 * This method is for advanced use only. In most of the cases, the ALVideoView
 * class should be used instead.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * @param request Rendering request.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err rendererId:(NSNumber*) rendererId;`
 *
 * @sa ALRenderRequest
 * @since 1.0.0.0
 */
- (void) renderSink:(ALRenderRequest*) request
          responder:(ALResponder*) responder;

/**
 * Stops rendering a video sink.
 *
 * __Note__
 *
 * This method is for advanced use only. In most of the cases, the ALVideoView
 * class should be used instead.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * @param rendererId ID of renderer to be stopped.
 * @param responder Responder object that will receive asynchronous call result.
 *
 *     `(void) response:(ALError*) err;`
 * @since 1.0.0.0
 */
- (void) stopRender:(NSNumber*) rendererId
          responder:(ALResponder*) responder;

/**
 * Requests the platform to redraw the renderer.
 *
 * __Note__
 *
 * This method is for advanced use only. In most of the cases, the ALVideoView
 * class should be used instead.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: YES
 *
 * @param request Draw request.
 *
 * @sa ALDrawRequest
 * @since 1.0.0.0
 */
- (void) draw:(ALDrawRequest*) request;

/** @name External video input */

/**
 * Inject an external video frame into the SDK. This only works if
 * ALInitOptions::externalVideoInput was enabled. The SDK expects a
 * 420YpCbCr8BiPlanarFullRange. The frame is timestamped inside the SDK.
 *
 * #### Availability:
 *
 * - iOS: YES
 * - OS X: NO
 *
 * @param frame Image data.
 *
 * @since 3.0.0.27
 */
- (void) injectFrame:(ALVideoFrame*) frame;


- (void) sendReportWithCredentials:(NSString*)credentials andCause:(NSString*) cause responder:(ALResponder*) resp;

- (void) startEventsTracking:(NSString*) fileName
            responder:(ALResponder*) responder;

- (void) getEventsChecksum:(ALResponder*) responder;

- (void) flushEvents:(NSString*) signature
            expiryTimestamp:(NSNumber*) expiryTimestamp
            responder:(ALResponder*) responder;

/** @name Audio control */

/**
 * Acoustic echo cancellation modes.
 *
 * @return A NSString* array of available acoustic echo cancellation (AEC) modes.
 */
+ (NSArray*) getAECModes;

/**
 * Noise suppression modes.
 *
 * @return A NSString* array of available noise suppression (NS) modes.
 */
+ (NSArray*) getNSModes;

/**
 * Automatic gain control modes.
 *
 * @return A NSString* array of available automatic gain control (AGC) modes.
 */
+ (NSArray*) getAGCModes;



@end // @interface ALService
