require_relative 'android'

ANDROID = Android.instance unless defined?(ANDROID)

class Balance_Functional

  ############################################################################################################
  @@paypal_balance_id = "paypal_balance"
  @@available_balance_id = "available_balance"
  @@refresh_menu_id = "menu_refresh"
  @@addto_button_id = "add_money_button"
  @@withdraw_button_id =  "withdraw_money_button"
  @@scancheck_button_id = "scan_check_button"
  @@balancedetailstxt_id = "pending_balance_disclosure"
  @@currency_title_id = "currency_section_title"
  @@available_currency_id = "currency_name"
  @@pending_currency_id = "currency_name2"
  @@amount_currency_id = "currency_amount"
  @@amount2_currency_id = "currency_amount2"
  @@view_all_activty = "viewAllActivities"
  @@activity_balance_id = "balance_section"
  
  @@paypal_logo_id="home"
  if ANDROID.is_gingerbread_device?
    @@paypal_logo_id="abs__home"
  end
  @@login_button_phone_id = "login_widget_login_button_phone"
  @@login_button_email_id = "login_widget_login_button_email"
  @@start_page_dialog_id = "alertTitle"
  @@no_btn_start_page_dialog_id = "button2"
  @@activity_refresh_id = "history_tabs"
  ############################################################################################################
  @@no_btn_start_page_dialog_text = "No"

  ############################################################################################################

  ###########################################################################################################
  # Method Name: balance details page
  # Parameters :
  # Description: Method to view balance details on Balance details page
  #############################################################################################################

  def verifyBalanceDetails

    ANDROID.assert_id_visible(@@paypal_balance_id)
    ANDROID.assert_id_visible(@@available_balance_id)
    ANDROID.assert_id_visible(@@balancedetailstxt_id)
    ANDROID.assert_id_visible(@@currency_title_id)
    ANDROID.assert_id_visible(@@available_currency_id)
    ANDROID.assert_id_visible(@@pending_currency_id)
    ANDROID.assert_id_visible(@@amount_currency_id)
    ANDROID.assert_id_visible(@@amount2_currency_id)

  end

###########################################################################################################
# Method Name: Balance in wallet page
# Parameters :
# Description: Method to verify balance in wallet page
#############################################################################################################

    def verifyWalletBalance

      ANDROID.assert_id_visible(@@paypal_balance_id)
      ANDROID.assert_id_visible(@@available_balance_id)

    end

###########################################################################################################
# Method Name: Balance in Activity page
# Parameters :
# Description: Method to verify balance in wallet page
#############################################################################################################

  def verifyActivityBalance

    ANDROID.assert_id_visible(@@activity_balance_id)
    ANDROID.assert_id_visible(@@paypal_balance_id)
    ANDROID.assert_id_visible(@@available_balance_id)
    ANDROID.assert_id_visible(@@view_all_activty)

  end

  def waitForHistory
    ANDROID.wait_till_id_visible(@@activity_refresh_id)
  end

  def waitForHistoryBusinessUser
    sleep 1.5
    if ANDROID.check_id(@@start_page_dialog_id)
      puts "In the If loop"
      ANDROID.wait_till_text_visible(@@no_btn_start_page_dialog_text)
      ANDROID.tap(@@no_btn_start_page_dialog_text, "text")
    end
    ANDROID.wait_till_id_visible(@@activity_refresh_id)
  end

  def goToWalletFromAddOrWithdraw()
    ANDROID.hardware_back
  end

end