class SendMoneyInitUI

  ID_SEND_MONEY_PAGE_VIEW = 'money_send'
  TEXT_SEND_MONEY_PAGE = 'Send'
  TEXT_FRIENDS_FAMILY = 'Friends or Family'
  TEXT_GOODS_SERVICES = 'Goods or Services'

  def self.verify_send_money_page
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_PAGE_VIEW)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_SEND_MONEY_PAGE}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_FRIENDS_FAMILY}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_GOODS_SERVICES}'}")
  end

end
class SendMoneyReviewUI

  ID_SEND_MONEY_REVIEW_PAGE = 'secondary_fragment_title'
  TEXT_REVIEW_SEND_MONEY_PAGE = 'Send Money'
  TEXT_REVIEW_SEND_MONEY_BUTTON = 'Send Money'
  TEXT_PAYMENT_METHOD = 'PAYMENT METHOD'
  TEXT_TOTAL = 'Total'
  TEXT_AMOUNT = 'Amount'
  TEXT_FEE = 'Fee:'


  def self.verify_sendmoney_review_page
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_REVIEW_PAGE)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_REVIEW_SEND_MONEY_PAGE}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_PAYMENT_METHOD}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_AMOUNT}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_FEE}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_TOTAL}'}")
  end

  def self.send_money_button
    ANDROID.tap2("* text:'#{TEXT_REVIEW_SEND_MONEY_BUTTON}'")
  end

end

class SendMoneyFinalUI

  ID_GREEN_CHECKMARK = 'green_checkmark'
  TEXT_SUCCESS_MESSAGE = "You sent $1.00 USD to \narun-us-p12@paypal.com."
  TEXT_DONE_BUTTON = 'Done'

  def self.verify_successful_transfer
    ANDROID.wait_till_id_visible(ID_GREEN_CHECKMARK)
    ANDROID.check_text_exists(TEXT_SUCCESS_MESSAGE)
    ANDROID.tap2("* text:'#{TEXT_DONE_BUTTON}'")
  end
end

