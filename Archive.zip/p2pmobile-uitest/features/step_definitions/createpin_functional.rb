class CreatePinFunctional


ID_PHONE_PIN =  'spinnerTextView'
ID_CREATE_PIN = 'changePINChooseEditText'
ID_CREATE_PIN2 = 'changePINChooseEditText2'
ID_CREATE_PIN_BUTTON = 'changePINButton'
ID_CHANGE_PIN_TAP= 'changePINEnterText'
ID_ENTER_PHONE_NUMBER = 'changePINEnterText'
ID_LOGOUT_BUTTON = 'button_logout'
ID_YES_BUTTON = "button1"



def self.create_pin(pin, phone)

    ANDROID.tap2("* id:'#{ID_PHONE_PIN}'")
    ANDROID.tap2("* id:'#{ID_PHONE_PIN}' index:2")
    ANDROID.enter_text(phone, 1)

   ANDROID.enter_text_by_id(pin, ID_CREATE_PIN)
   ANDROID.enter_text_by_id(pin, ID_CREATE_PIN2)
   ANDROID.tap2("* id:'#{ID_CREATE_PIN_BUTTON}'")

  end

def self.logout_tabbar
  sleep 1
  ANDROID.hardware_back
  ANDROID.swipe_left
  CreatePinFunctional.logout
  ANDROID.tap2("* id:'#{ID_YES_BUTTON}'")

end

def self.change_pin(pin)
  ANDROID.enter_text_by_id(pin, ID_CREATE_PIN)
  ANDROID.enter_text_by_id(pin, ID_CREATE_PIN2)
  ANDROID.tap2("* id:'#{ID_CREATE_PIN_BUTTON}'")
end

def self.create_differentpin(pin1, pin2)
  ANDROID.enter_text_by_id(pin1, ID_CREATE_PIN)
  ANDROID.enter_text_by_id(pin2, ID_CREATE_PIN2)
  ANDROID.tap2("* id:'#{ID_CREATE_PIN_BUTTON}'")
end

  def self.logout
    ANDROID.tap2("* id:'#{ID_LOGOUT_BUTTON}'")
  end
end
