class ActionSheet_Functional

  ############################################################################################################
  module Constants
    ID_DEBIT_CARD = 'menu_add_debit_card'
    ID_CREDIT_CARD = 'menu_add_credit_card'
    ID_BANK_ACCOUNT = 'menu_add_bank_account'
    ID_LOYALTY_CARD = 'menu_add_loyalty_card'
    ID_GIFT_CARD = 'menu_add_gift_card'
  end

  ############################################################################################################
  # Method Name: verifyActionSheet
  # Parameters
  # Description: This method verifies the elements in Action sheet
  #############################################################################################################

  def self.verifyActionSheet
    ANDROID.wait_till_element_visible("* id:'#{Constants::ID_DEBIT_CARD}'")
    Constants.constants.each do |c|
      ANDROID.check_id_exists("#{Constants.const_get(c)}")
    end
  end

  # user verifies the gift card options in Action sheet
  def self.verify_giftcard
    ANDROID.check_an_element_exists("* {text CONTAINS '#{'Gift Card'}'}")
  end

  # user verifies no gift card in Action sheet
  def self.verify_no_giftcard
    ANDROID.check_an_element_does_not_exist("* id:'#{'menu_add_gift_card'}'")
  end

end
