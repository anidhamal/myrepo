#!/bin/sh

if [ "$1" == "" ]; then
	echo Enter the stage name  Eg: stage2qa028.ca1.paypal.com
	read stagename
else
	stagename=$1
fi


# Cleanup just in case
if [ -f ~/.ssh/passwordless_key ]; then
	rm ~/.ssh/passwordless_key
fi

# Check if the key already exists
# If so copy it to passwordless_key
if [ -f ~/.ssh/id_dsa.pub ]; then
	cp ~/.ssh/id_dsa.pub ~/.ssh/passwordless_key
elif [ -f ~/.ssh/id_rsa.pub ]; then
	cp ~/.ssh/id_rsa.pub ~/.ssh/passwordless_key
elif [ -f ~/.ssh/identity.pub ]; then
	cp ~/.ssh/identity.pub ~/.ssh/passwordless_key
fi

# If not, create it
if [ ! -f ~/.ssh/passwordless_key ]; then
	echo Generating key
	ssh-keygen -t dsa -f ~/.ssh/id_dsa -N ''
	cp ~/.ssh/id_dsa.pub ~/.ssh/passwordless_key
fi

# Copy the public key to the stage
#scp ~/.ssh/passwordless_key $stagename:~/.ssh/authorized_keys
cat ~/.ssh/passwordless_key | ssh $stagename "mkdir -m 0700 -p .ssh && cat - >> .ssh/authorized_keys && chmod 0600 .ssh/authorized_keys"

# Cleanup
rm ~/.ssh/passwordless_key
#regenerating the passwd file, so that it contains the current user's updated home directory
if [ -e $HOME/dontDeleteMe.lock ]; then
		echo
else
	rm -rf /etc/passwd
	mkpasswd -c > /etc/passwd
    touch $HOME/dontDeleteMe.lock
fi