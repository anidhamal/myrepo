class LoginUI

  LOGIN_TEXT = 'Log In'
  PLUS_TEXT = '+'
  SIGN_UP_TEXT = 'New to PayPal? Sign Up'
  EMAIL_TAB_ID = 'etEmail'
  SIGN_UP_ID = 'authSignup'

  def self.verify_login_view
    ANDROID.wait_till_id_visible(SIGN_UP_ID)
    if ANDROID.check_id(EMAIL_TAB_ID)
      verify_login_email_view
    else
      verify_login_phone_view
    end
  end

  def self.verify_login_email_view
    ANDROID.check_text_exists(LOGIN_TEXT)
    ANDROID.check_text_exists(SIGN_UP_TEXT)
  end

  # all the phone pin labels could not be automated as there is description missing
  def self.verify_login_phone_view
    ANDROID.check_text_exists(PLUS_TEXT)
    ANDROID.check_text_exists(SIGN_UP_TEXT)
  end

  def self.verify_phone_num(phone)
    ANDROID.check_text_exists(phone)
  end

  def self.verify_email_address(email)
    ANDROID.check_text_exists(email)
  end

  def self.verify_LWL
    ANDROID.check_text_exists('username')
  end
end

class LoginOptionsUI

  HELP_TEXT = 'Other'
  PHONE_TEXT = 'Mobile phone and PIN'
  EMAIL_PWD_TEXT = 'Email and password'
  FORGOT_PASSWORD = 'Forgot my password'
  OPTIONS_TEXT = 'Login Options'
  SWITCH_USER_TEXT = 'Switch User'

  def self.verify_login_options_ui
    ANDROID.check_text_exists(OPTIONS_TEXT)
    ANDROID.check_text_exists(EMAIL_PWD_TEXT)
    ANDROID.check_text_exists(PHONE_TEXT)
    ANDROID.check_text_exists(HELP_TEXT)
  end

  def self.verify_switch_user
    ANDROID.check_text_exists(SWITCH_USER_TEXT)
  end
end