class RequestMoney_Functional

  ############################################################################################################

  @@transfer_button_id = "Transfer"
  @@request_tab_id = "money_request"
  @@request_button_text = "Request"
  @@request_button_id = "request_button"
  @@done_button_id = "done_button"
  @@greencheckmark_id = "green_checkmark"
  @@successmessage_id = "success_message"
  @@select_currency_id = "choose_currency"
  @@request_button_disabled_element = "com.paypal.android.choreographer.widgets.RobotoButton enabled:false"

  ############################################################################################################
  # Method Name: fillUpRequest
  # Parameters : amount, email_id and message for note field
  # Description: This method will enter email, amount, and message for note field and initiate request
  #############################################################################################################


  def fillUpRequestForm(recipient, amt, currency, msg)
    ANDROID.enter_text(recipient, 1)
    ANDROID.enter_text(amt, 2)
    if msg != nil
      ANDROID.enter_text(msg, 3)
    end
    changeCurrency(currency)
  end

  def fillUpRequestFormMultipleUsers(amt, currency, recipient1, recipient2, msg)
    ANDROID.enter_text(recipient1, 1)
    ANDROID.enter_text(amt, 2)
    ANDROID.enter_text(msg, 3)
    changeCurrency(currency)
    ANDROID.enter_text(recipient2, 1)
  end

  ############################################################################################################
  # Method Name: changeCurrency
  # Parameters : currency
  # Description: This method will tap on choose currency button in request screen
  #              then scrolls all the way up in change currency screen and selects specified currency
  #############################################################################################################
  #TODO: Needs to be in a separate class file for easier reference by other features?
  def changeCurrency(currency)
    if !ANDROID.check_text(currency)
      ANDROID.tap(@@select_currency_id, "id")
      ANDROID.scroll_up(5)
      for i in 1..5
        if !ANDROID.check_text(currency)
          ANDROID.scroll_down(1)
          next
        end
      end
      ANDROID.assert_text_visible(currency)
      ANDROID.tap(currency, "text")
    end
  end

  #
  #def changeCurrency(currency)
  #  if !ANDROID.check_text(currency)
  #    ANDROID.tap(@@select_currency_id, "id")
  #    ANDROID.scroll_up(4)
  #    ANDROID.assert_text_visible(currency)
  #    ANDROID.tap(currency, "text")
  #  end
  #end


  ############################################################################################################
  # Method Name: tapOnRequestBtn
  # Parameters : none
  # Description: This method will tap on Request button on request screen
  #############################################################################################################

  def tapOnRequestBtn

    ANDROID.tap(@@request_button_id, "id")
    #ANDROID.tap(@@request_button_text, "button")

  end

  #############################################################################################################
  # Method Name: verifySuccessMsg
  # Parameters : email, amt
  # Description: This method will verify message for successful request
  #############################################################################################################

  def verifySuccessMsg

    ANDROID.wait_till_id_visible(@@greencheckmark_id)
    ANDROID.assert_id_visible(@@greencheckmark_id)
    ANDROID.assert_id_visible(@@successmessage_id)

  end


  #############################################################################################################
  # Method Name: verifySuccessMsg
  # Parameters : email, amt
  # Description: This method will verify message for successful request
  #############################################################################################################

  def tapDoneBtn

    ANDROID.assert_id_visible(@@done_button_id)
    ANDROID.tap(@@done_button_id, "id")

  end

  def verifyRequestBtnIsDisabled
    fail 'Request button is enabled' if [true, nil].include? ANDROID.element_enabled?(@@request_button_id)
  end

end