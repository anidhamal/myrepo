require_relative 'add_card_functional'

###
#Authors:
# Sahil Ohri
###

addcard_functional = AddCard_Functional.new

##################################################################
# User tries to add a credit card with the given details
##################################################################
Then /^user tries to add "([^"]*)" card of type "([^"]*)" with expiration date "([^"]*)" and CSC number "([^"]*)"$/ do |type, card_type, exp_date, csc|
  NAV.goToAddCard
  addcard_functional.selectCardType(type)
  addcard_functional.verifyAddCardFields
  addcard_functional.enterCardDetails(card_type, exp_date, csc)
end

Then(/^user select "(.*?)" Card and fill out the card form with number "(.*?)",  expiration date "(.*?)" and CSC number "(.*?)"$/) do |type,number, expiration, csc|
  addcard_functional.selectCardType(type)
  addcard_functional.verifyAddCardFields
  addcard_functional.enterGivenCardDetails(number,type, expiration, csc)
end

##################################################################
# User Navigates to the Add Card Screen for Credit
##################################################################
When(/^user click and open Add actions overlay$/) do
  # assume in wallet already
  ANDROID.wait_for_actionbar_progress
  NAV.goToAddCardAtWallet
end

##################################################################
# User can successfully add the card and see it on the
# Wallet page
##################################################################
Then /^user can add card successfully from wallet screen$/ do
  addcard_functional.tapAddCard
  addcard_functional.verifyAddedCard
end

##################################################################
# User tries to add a duplicate credit card
##################################################################
When /^user tries to add "([^"]*)" card with same details$/ do |type|
  NAV.goToAddCard
  addcard_functional.selectCardType(type)
  addcard_functional.verifyAddCardFields
  addcard_functional.enterDuplicateCardDetails
end

##################################################################
# User can see an error
##################################################################
Then /^user will see an error message "([^"]*)"$/ do |text|
  addcard_functional.tapAddCard
  addcard_functional.verifyMsg(text)
  addcard_functional.tapOK
end

##################################################################
# User should not be able to add the incomplete address
##################################################################
Then /^user cannot add address$/ do
  addcard_functional.verifyAddAddressFields
end

##################################################################
# User leaves the credit card number empty
##################################################################
And /^user leaves the credit card number field empty$/ do
  addcard_functional.clearCardNumber
end

##################################################################
# User should not be able to add the card due to
# incomplete fields
##################################################################
Then /^user cannot add card$/ do
  addcard_functional.verifyAddCardButtonDisabled
end

##################################################################
# User adds a new billing address
##################################################################
And /^user adds a new billing address "([^"]*)", state "([^"]*)", city "([^"]*)", zip "([^"]*)"$/ do |address,state,city,zip|
  addcard_functional.tapAddress
  addcard_functional.tapAddAddress
  addcard_functional.verifyAddAddressFields
  address_state = state
  if address_state == "California"
    address_state = "CA"
  end
  addcard_functional.addAddress(address,address_state,city,zip)
  addcard_functional.tapContinue
end

##################################################################
# User should not see add card option
##################################################################
Then /^user should not see add card option$/ do
  NAV.goToAddCard
  addcard_functional.verifyNoAddCard
end

##################################################################
# User cannot set invalid expiration date
##################################################################
Then /^user cannot set invalid expiration date$/ do
  addcard_functional.verifyExpirationDateDialogOkButtonOff
end