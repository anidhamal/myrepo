require_relative 'settings_ui'

settings_ui = Settings_UI.new

And /^the user goes to the settings page$/ do
  NAV.goToSettings
end

When /^the user goes to the Navigation Drawer$/ do
  NAV.goToNavigationDrawer
end

Then /^user can see the name "([^"]*)"$/ do |name|
  settings_ui.verify_name(name)
end