# user taps agree terms and conditions
And(/^user accepts terms and conditions$/) do
  Launch_Page_Functional.taps_agree_terms_conditions
end

# user verifies 1st launch page
Then(/^user is on 1st Launch Screen$/) do
  Launch_Page_Functional.verify_launch_page
end

# user taps on signup button in launch page
Then(/^user taps on Sign Up Button$/) do
  Launch_Page_Functional.taps_signup_button
end

# user verifies create account page
And(/^user is in Create Account Page$/) do
  Create_Account_UI.verify_create_account_page
end

# user taps on lets go button in launch page
Then(/^user taps on Let's Go Button$/) do
  Launch_Page_Functional.taps_letsgo_button
end

# user veifies 1st launch page title (ID)
And(/^user views Title 1st Page Title$/) do
  Launch_Page_Functional.verify_launchpage_title
end

# user verifies launch page content (text)
Then(/^user views content "([^"]*)"$/) do |content|
  Launch_Page_UI.verify_launch_page_content(content)
end

# user verifies lets go and sign up button in launch pages - lets go and signup
And(/^user views button (\d+) buttons$/) do |arg|
  Launch_Page_Functional.verify_launch_page_buttons
end

# user verifies for 3 dots in launch Pages
Then(/^user views three indication dot images$/) do
  Launch_Page_Functional.verify_action_overflow
end

# This method will go to the second page of launch page
Then(/^user navigates to 2nd page$/) do
  Launch_Page_Functional.go_to_Launch_2nd_Page
end

# user verifies launch page title (text)
Then(/^user views Title "([^"]*)"$/) do |title|
  Launch_Page_UI.verify_launch_page_title(title)
end

# user verifies 2nd launch page
And(/^user is on 2nd Launch Page$/) do
  Launch_Page_Functional.verify_launch_page
end

# This method will go to the third page of launch page
Then(/^user navigates to 3rd page$/) do
  Launch_Page_Functional.go_to_Launch_3rd_Page
end

# user verifies 3rd launch page
And(/^user is on 3rd Launch Page$/) do
  Launch_Page_Functional.verify_launch_page
end