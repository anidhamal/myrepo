# Author
# Steve Shenouda

Given(/^user taps on Accept and Send button$/) do
  SendMoneyReviewFunctional.tap_send_money
end

Then(/^user sees the KYC send money success screen$/) do
  SendMoneyFinalFunctional.verify_successful_transfer
end

Then(/^user can request money KYC successfully$/) do
  KycFunctional.verify_confirmation_message
  step 'user can request money successfully'
end

Then(/^user gets a KYC error message "([^"]*)"$/) do |message|
  KycFunctional.verify_sending_limit_message(message)
end
