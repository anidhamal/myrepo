# Author
# Steve Shenouda

Given(/^user is on the shop screen$/) do
  NAV.goToShopPage
  ShopFunctional.verify_on_shop_page
end

Given(/^user can see the merchant list$/) do
  ShopFunctional.verify_merchant_list
end

When(/^user taps on the first merchant$/) do
  ShopFunctional.tap_merchant_in_list_view
end

Then(/^user sees the merchant details page$/) do
  ShopFunctional.verify_merchant_details
end

When(/^user taps on merchant name in merchant details$/) do
  ShopFunctional.tap_merchant_on_details_page
end

Then(/^user sees store details more info page$/) do
  ShopFunctional.verify_store_details
end

Then(/^user goes back to the merchant details$/) do
  ANDROID.hardware_back
  ShopFunctional.verify_merchant_details
end

Then(/^the user goes back to the merchant list$/) do
  ANDROID.hardware_back
  ShopFunctional.verify_on_shop_page
  ShopFunctional.verify_merchant_list
end

Then(/^user tries to check\-in to merchant$/) do
  ShopFunctional.swipe_slider(true)
end

Then(/^user can check\-out from merchant$/) do
  ShopFunctional.swipe_slider(false)
end

Then(/^user can see the first merchant has an image, has name "(.*?)" and address "(.*?)"$/) do |name, address|
  ShopFunctional.verify_search_result(name, address)
end

Then(/^user sees the generated pay code$/) do
  ShopFunctional.verify_pay_code
end

And /^user goes to shop view$/ do
  NAV.goToShopPage
end