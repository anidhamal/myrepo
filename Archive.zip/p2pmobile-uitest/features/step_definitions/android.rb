require 'rubygems'
require 'calabash-android'
require 'singleton'

##################################################
# It retrieves UI element definitions and stores in static variable
# getter and setter
##########################################################################
class Android
  include Singleton
  include Calabash::Android::Operations

##########################################################################
# Checks if it is a Gingerbread device or not.
# Similar implementations can be put in for other OS specific things
##########################################################################
  def is_gingerbread_device?
    `#{default_device.adb_command} shell getprop ro.build.version.release` =~ /^2.3/
  end

  ##TAP METHOD IS DEPRECATED - USE TAP2 METHOD
  ############################################################################################################
  # Method Name: tap
  # Parameters : text::Name of the Text, type:: text, id
  # Description: The method taps on the "text" with "type"
  #############################################################################################################
  def tap(text, type)
    case type
      when "id"
        performAction('click_on_view_by_id', text)
      when "text"
        performAction("click_on_text", text)
      when "button"
        performAction("press_button_with_text", text)
      when "tab"
        performAction("press_abs_tab", text)
      when "element"
        touch(query(text))
      else
        puts "This type::  #{type} is not available in the current version of Calabash"
    end

    sleep 0.5
    take_screenshot("tap", type)
  end

  ##############################################################################
  # * *Description:* This waits and taps on an element based on the query
  # * *Parameters:* query used to tap on the ui element
  # Usage: tap2("* id:' '"), tap2("* text:' '"), tap2("* marked:' '"),
  # tap2("* {id CONTAINS ' '") etc..
  ##############################################################################
  def tap2(query)
    wait_till_element_visible(query)
    touch(query)

    if SCREENSHOTS
      take_screenshot
    end
  end

  ############################################################################################################
  # Method Name: tap_xy
  # Parameters : x:: X- Co-ordinate, y = Y co-ordinate
  # Description: The method taps on XY co-ordinate
  #############################################################################################################
  def tap_xy(x, y)
    performAction("click_long_on_screen", x, y)
  end

  ############################################################################################################
  # Method Name: scroll_up
  # Parameters : numberOfScrolls= Number of times scrolls
  # Description: The method scrolls up with Number of scrolls, By default is 1.
  #############################################################################################################
  def scroll_up(numberOfScrolls="")
    if numberOfScrolls == ""
      performAction("scroll_up")
    else
      for i in 1..numberOfScrolls
        performAction("scroll_up")
      end
    end
  end

  ############################################################################################################
  # Method Name: scroll_down
  # Parameters : numberOfScrolls= Number of times scrolls
  # Description: The method scrolls down with Number of scrolls, By default is 1.
  #############################################################################################################
  def scroll_down(numberOfScrolls="")
    if numberOfScrolls == ""
      performAction("scroll_down")
    else
      for i in 1..numberOfScrolls
        performAction("scroll_down")
      end
    end
  end

  ############################################################################################################
  # Method Name: enter_text_by_index
  # Parameters : text = Text to be Entered, index = Number of the textbox
  # Description: The method enters text in the given textbox.
  #############################################################################################################
  def enter_text(text, index) #TODO: need to change this to enter_text by index
    performAction('enter_text_into_numbered_field', text, index)

    if SCREENSHOTS
      take_screenshot
    end

  end

  ############################################################################################################
  # Parameters : text = Text to be Entered, id = id of the view
  # Description: The method enters text in the given textbox.
  #############################################################################################################
  def enter_text_by_id(text, id)
    performAction('enter_text_into_id_field', text, id)
  end


  ############################################################################################################
  # Method Name: scroll_to_bottom
  # Parameters : numberOfScrolls= Number of times scrolls
  # Description: The method scrolls down with Number of scrolls, By default is 10.
  #############################################################################################################
  def scroll_to_bottom(numberOfScrolls="")
    if numberOfScrolls == ""
      numberOfScrolls = 10
    end
    for i in 1..numberOfScrolls
      performAction("scroll_down")
    end
  end

  ############################################################################################################
  # Method Name: scroll_to_top
  # Parameters : numberOfScrolls= Number of times scrolls
  # Description: The method scrolls up with Number of scrolls, By default is 10.
  #############################################################################################################
  def scroll_to_top(numberOfScrolls="")
    if numberOfScrolls == ""
      numberOfScrolls = 10
    end
    for i in 1..numberOfScrolls
      performAction("scroll_up")
    end
  end

  ############################################################################################################
  # Method Name: swipe_left
  # Parameters : none
  # Description: The method swipes from left to right
  #############################################################################################################
  def swipe_left
    performAction('swipe', 'left')
    if SCREENSHOTS
      take_screenshot
    end
  end

  ############################################################################################################
  # Method Name: swipe_right
  # Parameters : none
  # Description: The method swipes from right to left
  #############################################################################################################
  def swipe_right
    performAction('swipe', 'right')
  end


  ############################################################################################################
  # Method Name: wait_till_visible
  # Parameters : text = Text to be seen, type = Id or Text
  # Description: The method waits till "text" with "type" visible
  #############################################################################################################
  def wait_till_text_visible(text)
    debug = "Tried waiting for text:#{text} for #{TIMEOUT} and was not able to find it."
    n = TIMEOUT
    for i in 1 .. n
      if check_text(text)
        break
      end
      sleep 1
    end
    if i==n
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: wail_till_invisible
  # Parameters : text = Text to be seen, type = Id or Text
  # Description: The method waits till "text" with "type" invisible
  #############################################################################################################

  def wail_till_text_invisible(text)
    debug = "Tried waiting for ID:#{text} for #{TIMEOUT} and was not able to find it."
    n = TIMEOUT.to_i*4
    for i in 1 .. n
      x = check_text(text)
      if x==false
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
    if i==n
      raise debug

    end
  end

  ############################################################################################################
  # Method Name: assert_visible
  # Parameters : view = Text to be seen, type = Id or Text
  # Description: The method validates "text" with "type" visible on screen.
  #############################################################################################################
  def assert_text_visible(text)
    performAction('assert_text', text, true)
  end



  ############################################################################################################
  # Method Name: assert_invisible
  # Parameters : view = Text to be not seen, type = Id or Text
  # Description: The method validates "text" with "type" invisible on screen.
  # comments: the function is causing for the test case to pass when it should fail
  #############################################################################################################
  def assert_text_invisible(view)
    performAction('assert_text', view, false)
    #should be ANDROID.check_an_element_does_not_exist("* id:'#{ID_SENDER_FEES}'")
  end

  ############################################################################################################
  # Method Name: drag_xy_to_xy
  # Parameters : x1 = X1 co-ordinates,y1 = Y1 Co-ordinates, x2 = X2 co-ordinates, y2 = Y2 co-ordinates, s = No. of steps
  # Description: The method drags from x1y1 to x2y2.
  #############################################################################################################
  def drag_xy_to_xy(fromX,toX,fromY,toY,steps)
    performAction('drag',fromX,toX,fromY,toY,steps)
  end

  ############################################################################################################
  # Method Name: long_tap
  # Parameters : text = Text to be long pressed, type = id or text
  # Description: The method long presses on text with type.
  #############################################################################################################
  def long_tap(text, type)
    case type
      when "id"
        performAction('long_press_on_view_by_id', text)
      else
        puts "This type::  #{type} is not available in the current version of Calabash"
    end
  end

  ############################################################################################################
  # Method Name: hardware_menu
  # Parameters :
  # Description: The method presses hardware menu button.
  #############################################################################################################
  def hardware_menu
    performAction('press_menu')
  end

  ############################################################################################################
  # Method Name: hardware_back
  # Parameters :
  # Description: The method presses hardware back button.
  #############################################################################################################
  def hardware_back
    performAction('go_back')
  end
  
  ############################################################################################################
  # Method Name: hardware_down
  # Parameters :
  # Description: The method presses hardware down button.
  #############################################################################################################
  def hardware_down
    performAction('send_key_down')
  end
  
  ############################################################################################################
  # Method Name: hardware_right
  # Parameters :
  # Description: The method presses hardware right button.
  #############################################################################################################
  def hardware_right
    performAction('send_key_right')
  end
  
  ############################################################################################################
  # Method Name: hardware_enter
  # Parameters :
  # Description: The method presses hardware enter button.
  #############################################################################################################
  def hardware_enter
    performAction('send_key_enter')
  end
  
  ############################################################################################################
  # Method Name: clear_text
  # Parameters : id = textbox number
  # Description: The method clears text on Id.
  #############################################################################################################
  def clear_text(id)
    performAction("clear_numbered_field", id)
  end

  def clear_input_field_with_id(id)
    performAction('clear_id_field', id)
  end

  ############################################################################################################
  # Method Name: Waits for a ID to become invisible
  # Parameters :
  # Description:
  #############################################################################################################
  def wait_till_id_invisible (id)
    debug = "Tried waiting for ID:#{id} for #{TIMEOUT} and it did not disappear."
    n = TIMEOUT.to_i*4
    for i in 1 .. n
      x = element_exists("* id:'#{id}'")
      if x==false
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
    if i==n
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: TOTALLY HACKY METHOD TO RETRY LOGIN
  # Parameters :
  # Description: DO NOT REUSE ANYWHERE
  #############################################################################################################
  #TODO: check that wait doesnt take too long
  def login_retry(id)
    n = TIMEOUT.to_i*4
    for i in 1 .. n
      x = element_exists("* id:'#{id}'")
      y = element_exists("* id:'message'")
      if  y == true
        break
      end
      if x == true
       return
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
    if does_element_exist?(" * id:'message'")
      puts "DEBUG: Retry login started."
      if SCREENSHOTS
        take_screenshot
      end
      tap2("* id:'button1'")
      sleep 0.5
      ANDROID.tap2("* id:'bttnLogin'")
      ANDROID.wait_for_progressbar
      wait_till_id_visible("#{id}")
    end
  end


  ############################################################################################################
  # Method Name: Waits for an ID to become visible
  # Parameters :
  # Description:
  #############################################################################################################
  #TODO: check that wait doesnt take too long
  def wait_till_id_visible (id)
    debug = "Tried waiting for ID:#{id} for #{TIMEOUT} and was not able to find it."
    n = TIMEOUT.to_i*4
    for i in 1 .. n
      x = element_exists("* id:'#{id}'")
      if x==true
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
    if i==n
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: Checks for an id and returns true or false
  # Parameters :
  # Description: Returns true or false based on id
  #############################################################################################################
  def check_id(id)
    returnedBoolean = element_exists("* id:'#{id}'")
    return returnedBoolean
  end

  ############################################################################################################
  # Method Name: waits for the progress bar to disappear
  # Parameters :
  # Description:
  #############################################################################################################
  def wait_for_progressbar
    id="progress"
    debug = "Tried waiting for the progress bar to disappear for #{TIMEOUT} but it did not."
    for i in 1 .. TIMEOUT
      x = element_exists("* id:'#{id}'")
      if x==false
        sleep 1
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 1
      end
    end
    if i==TIMEOUT
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: assert_visible
  # Parameters : view = Text to be seen, type = Id or Text
  # Description: The method validates "text" with "type" visible on screen.
  #############################################################################################################
  def assert_id_visible(view)
    performAction('wait_for_view_by_id', view)
  end

  ############################################################################################################
  # Method Name: assert_invisible
  # Parameters : view = Text to be not seen, type = Id or Text
  # Description: The method validates "text" with "type" invisible on screen.
  #############################################################################################################
  #TODO: Get rid of the unused parameters and make changes in all places used
  def assert_id_invisible(view, type, flag)
    val = true
    begin
      performAction('wait_for_view_by_id', view)
      val = false
    rescue Exception => e
    end
    if val == false
      raise "Id \"#{view}\" was found."
    end
  end

  ############################################################################################################
  # Method Name: Checks for an id and returns true or false
  # Parameters :
  # Description: Returns true or false based on id assert
  #############################################################################################################
  def check_text(text)
    return !query("* {text CONTAINS '#{text}'}").empty?
  end

  ############################################################################################################
  # Method Name: Checks for checkbox and returns true or false
  # Parameters :
  # Description: Returns true or false based on id assert
  #############################################################################################################
  def check_checkbox(id)
    value = query("CheckBox id:'#{id}'", :checked)
    return value[0]
  end

  ############################################################################################################
  # Method Name: asserts for Class with index
  # Parameters :   Class and Index
  # Description:
  #############################################################################################################
  def assert_element_exist(element)
    debug = "Tried to assert for element:#{element} for #{TIMEOUT} and was not able to find it."
    if !element_exists(element)
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: Waits for class to become visible
  # Parameters :
  # Description:
  #############################################################################################################

  def wait_till_element_visible (element)
    debug = "Tried waiting for element:#{element} for #{TIMEOUT} and was not able to find it."
    n = TIMEOUT.to_i*4
    for i in 1 .. n
      if element_exists(element)
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
    if i==n
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: Waits for class to become invisible
  # Parameters :
  # Description:
  #############################################################################################################

  def wait_till_element_invisible (element)
    debug = "Tried waiting for element to be invisible:#{element} for #{TIMEOUT}."
    n = TIMEOUT.to_i*4
    for i in 1 .. n
      if element_does_not_exist(element)
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
    if i==n
      raise debug
    end
  end

  ############################################################################################################
  # Method Name: change_locale
  # Parameters: locale
  # Description: Changes the locale to the given value
  #############################################################################################################

  def change_locale(locale)
    Kernel.puts "Changing Locale to:"+ locale
    debug = "Change Locale: Supported Locales are - AU,BR,CA,CN,DE,FR,GB,HK,IT,JP,MY,US"

    case locale
      when "en_AU"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'en' -e locale_country 'AU' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "pt_BR"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'pt' -e locale_country 'BR' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "en_CA"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'en' -e locale_country 'CA' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "zh_CN"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'zh' -e locale_country 'CN' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")
        # system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'zh_HANS' -e locale_country 'CN' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez remember_me false --ez haveShownOverlay true")
        
      when "de_DE"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'de' -e locale_country 'DE' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "fr_FR"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'fr' -e locale_country 'FR' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "en_GB"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'en' -e locale_country 'GB' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "ru_RU"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'ru' -e locale_country 'RU' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "zh_HK"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'zh' -e locale_country 'HK' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "it_IT"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'it' -e locale_country 'IT' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "ja_JP"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'ja' -e locale_country 'JP' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "es_MX"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'es' -e locale_country 'MX' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "ms_MY"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'ms' -e locale_country 'MY' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "es_ES"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'es' -e locale_country 'ES' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "nl_NL"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'nl' -e locale_country 'NL' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "en_SG"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'en' -e locale_country 'SG' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "en_US"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'en' -e locale_country 'US' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      # new added
      when "da_DK"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'da' -e locale_country 'DK' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")

      when "no_NO"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'nb' -e locale_country 'NO' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")
        
      when "pt_PT"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'pt' -e locale_country 'PT' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")
        
      when "sv_SE"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'sv' -e locale_country 'SE' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")
        
      when "tr_TR"
        system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --ez override_locale true -e locale_language 'tr' -e locale_country 'TR' --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true")
        
      else
        raise debug
      
    end

    $locale = locale

    kill_app_process
    sleep 1
    start_test_server_in_background
  end

  ############################################################################################################
  # Method Name: change_device_locale
  # Parameters: locale
  # Description: Changes the locale of the Device to the given value.
  # NOTE:  The Device should be Rooted.
  #############################################################################################################

  def change_device_locale(locale)

    #Get the current device locale
    _language =  `adb -s #{DEVICE} shell su -c getprop persist.sys.language`.strip
    _country  = `adb -s #{DEVICE} shell su -c getprop persist.sys.country`.strip
    sleep 1
    current_device_locale = _language + "_" +_country
    puts "Device Locale right now : #{current_device_locale}"

    # Verify if the current device locale is same as the expected locale.
    # If they are same, we do not have to change the device locale
    if current_device_locale === locale
      take_screenshot
      return
    end

    _language = locale.split("_")[0]
    _country = locale.split("_")[1]
    puts "Changing Device Locale to: "+ locale

    system ("adb -s #{DEVICE} shell su -c  setprop persist.sys.language #{_language}")
    system ("adb -s #{DEVICE} shell su -c setprop persist.sys.country #{_country}")
    system("adb -s #{DEVICE} shell su -c stop")
    system("adb -s #{DEVICE} shell su -c start")

    #sleep until the device switches on
    sleep 20

    kill_app_process
    sleep 3
    set_app_preferences
    sleep 2
    start_test_server_in_background

    take_screenshot

  end

  ############################################################################################################
  # Method Name: check_roboto_enabled
  # Parameters : id of the roboto button
  # Description: Returns true if the RobotoButton is enabled, false otherwise
  #############################################################################################################
  def check_roboto_button_enabled(id)
    value = query("RobotoButton id:'#{id}'",:enabled)
    return value[0]
  end

  ############################################################################################################
  # Method Name: check_button_enabled
  # Parameters : id of the button
  # Description: Returns true if the button is enabled, false otherwise
  #############################################################################################################
  def check_button_enabled(id)
    value = query("button id:'#{id}'",:enabled)
    return value[0]
  end

  ############################################################################################################
  # Method Name: check_button_enabled
  # Parameters : id of the button
  # Description: Returns true if the button is enabled, false otherwise
  #############################################################################################################
  def check_roboto_textview_enabled(id)
    value = query("RobotoTextView {id CONTAINS '#{id}'}",:enabled)
    return value[0]
  end

  ############################################################################################################
  # Method Name: element_enabled?
  # Parameters : id of the element
  # Description: Returns true if the element is enabled, false otherwise
  #############################################################################################################
  def element_enabled?(id)
    query("* id:'#{id}'",:enabled).first
  end

  ############################################################################################################
  # Method Name: get_text_from_id
  # Parameters : id of the view
  # Description: Returns the text of the given id
  #############################################################################################################
  def get_text_from_id(id)
    query("* id:'#{id}'", :text)
  end

  def get_content_description(id)
    query("* id:'#{id}'", :contentDescription)
  end

  #############################################################################################################
  # Method Name: waits for the action bar refresh to compelete
  # Parameters :
  # Description:
  #############################################################################################################
  def wait_for_actionbar_progress
    wait_till_element_invisible ("ProgressBar")
  end
  
  ##########################################################################
  # Method Name: take_screenshot
  # Description: Used to capture screenshots for localized tests
  ##########################################################################
  def take_screenshot(trigger="", type="")
    if SCREENSHOTS
      sleep 2
      timestamp = Time.now.strftime("%F-%H-%M-%S")
      filename="screenshots/P2P-Android-#{$locale}-#{$scenario_name}-#{timestamp.tr('-', '_')}.png"
      filename=screenshot(:name => filename)
      puts "taking a screenshot #{trigger} #{type} #{filename}"
      $snapshots_container << filename
    end
  end

  ##############################################################################
  # * *Description:* This asserts that the id exists
  # * *Parameters:* id of the element
  ##############################################################################
  def check_id_exists(id)
    check_element_exists("* id:'#{id}'")
  end

  ##############################################################################
  # * *Description:* This asserts that the text exists
  # * *Parameters:* text of the element
  ##############################################################################
  def check_text_exists(text)
    check_element_exists("* text:'#{text}'")
  end

  ##############################################################################
  # * *Description:* Asserts that the id, text, or content description exists
  # * *Parameters:* id, text, or content description of the element
  ##############################################################################
  def check_marked_element_exists(element)
    check_element_exists("* marked:'#{element}'")
  end

  ##############################################################################
  # * *Description:* Asserts that the id, text, or content description doesn't exist
  # * *Parameters:* id, text, or content description of the element
  ##############################################################################
  def check_marked_element_does_not_exist(element)
    check_element_does_not_exist("* marked:'#{element}'")
  end

  ##############################################################################
  # * *Description:* This returns true if the query returns an element
  # * *Parameters:* query to check for on the ui
  ##############################################################################
  def does_element_exist?(query)
    element_exists(query)
  end

  ##############################################################################
  # * *Description:* This returns true if the query does not return an element
  # * *Parameters:* query to check for on the ui
  ##############################################################################
  def does_element_not_exist?(query)
    element_does_not_exist(query)
  end

  ##############################################################################
  # * *Description:* This asserts that the query returns an element
  # * *Parameters:* query to check for on the ui
  ##############################################################################
  def check_an_element_exists(query)
    check_element_exists(query)
  end

  ##############################################################################
  # * *Description:* This asserts that the query does not return an element
  # * *Parameters:* query to check for on the ui
  ##############################################################################
  def check_an_element_does_not_exist(query)
    check_element_does_not_exist(query)
  end

  ##############################################################################
  # * *Description:* Placeholder method
  # * *Parameters:* arg1, arg2, arg3
  ##############################################################################
  def embed(_arg1, _arg2, _arg3)
    raise('Test Case failed')
  end

  def get_text_array(id)
    arr = query("#{id}", :text)
    return arr
  end
end
