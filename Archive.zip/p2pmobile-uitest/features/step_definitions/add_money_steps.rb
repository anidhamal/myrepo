require_relative 'add_money_functional'

addMoney_functional = Add_Money_Functional.new


#################################################
## Scenario 1: US user can add funds from bank
######################################################################

And /^user can go to add money on wallet screen$/ do
  NAV.goToAddFunds
end

When /^user selects bank, enters amount "(.*?)"$/ do |amount|
  addMoney_functional.verifyAddMoneyPage
  addMoney_functional.enterAmount(amount)
end

Then /^user is able to add money successfully$/ do
  addMoney_functional.verifyAddMoneySuccessful
  addMoney_functional.tapDone
end


When(/^user can switch bank to add money$/) do
  addMoney_functional.switchBankAcct
end
