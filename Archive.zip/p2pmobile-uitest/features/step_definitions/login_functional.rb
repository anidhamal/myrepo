class Login_functional
  require 'calabash-android'
  require 'rubygems'
  require 'calabash-android/management/adb'
  require 'calabash-android/operations'
  require_relative 'android'

#Core methods gets initialized here
#include 'Calabash.rb'
#require 'Calabash'

############################################################################################################

  @@email_tab_id = "etEmail"
  @@phone_tab_id = "etNumber"
  @@phone_country_code = "countryCode"
  @@login_button_id = "bttnLogin"
  @@login_options_id = "textView1"
  @@login_pin_id = "pin"
  @@login_button_phone_id = "text"
  @@lwl_email_id = "tvEmail"

  @@select_email_pwd = "com.paypal.android.lib.authenticator.widgets.RobotoTextView index:4"
  @@select_phone_pin = "com.paypal.android.lib.authenticator.widgets.RobotoTextView index:5"
  @@login_options_class = "com.paypal.android.lib.authenticator.widgets.RobotoTextView"

  # On LWL screen, indexes changed on Login options screen
  @@options_title_id = "titleLogin"

  @@login_menu_id = "button_help"
  @@logout_menu_id = "button_logout"
  @@settings_menu_id = "button_settings"
  @@wallet_menu_id = "button_wallet"
  @@transfer_menu_id = "button_transfer"
  @@activity_menu_id = "button_activity"
  @@shop_refresh_id = "menu_shop_refresh"
  @@login_LWLI_id = "ok_button"
  @@pin_LWLI_id = "pin_entry"
  @@password_LWLI_id = "password"
  @@yes_id = "button1"
  @@dialogBox_id="parentPanel"
  @@paypal_logo_id="home"
  if ANDROID.is_gingerbread_device?
    @@paypal_logo_id="abs__home"
  end
  @@yes_text = "button1"
  @@signup_button_id = "signup_button"
  @@error_message_element = "android.widget.TextView index:0"
  @@ok_btn_element = "android.widget.Button index:0"
  @@rememberme_checkbox_id = "remember_me_checkbox"
  @@addMoney_id = "add_money_button"
  @@withdrawMoney_id = "withdraw_money_button"
  @@viewallacitivity_id = "viewAllActivities"
  @@search_id = "menu_search"
  @@mapicon_id = "menu_map"
  @@refreshicon_id = "menu_map"
  @@email_pwd_field_id = "unknown_user_login_widget_password_field"
  @@pin_pwd_field_id = "unknown_user_login_widget_pin_field"
  @@refresh_menu_id = "menu_refresh"

  @@alert_message_id = "message"
  @@security_settings_id = "security_settings"
  @@settings_id = "settings_tabs"
  @@SIGNUP_button = "signup_button"
  @@Login_after_logout_button = 'button_logout'
  @@Phonepin_button = 'text'

  ############################################################################################################

  ############################################################################################################
  # Method Name: logInWithEmail
  # Parameters : emailID, default password
  # Description: The method Logs in with Email and default password "11111111"
  #############################################################################################################
  def logInWithEmail(email, pwd)
    # If the view is phone pin view, then change to email password view
    if ANDROID.element_does_not_exist("* id:'#{@@email_tab_id}'")
      ANDROID.tap2("* id:'#{@@login_options_id}'")
      ANDROID.wait_till_id_visible(@@options_title_id)
      ANDROID.tap2(@@select_email_pwd)
    end

    # Enter email and password
    ANDROID.tap2("* id:'#{@@email_tab_id}'")
    ANDROID.clear_text(1)
    ANDROID.enter_text(email, 1)
    ANDROID.clear_text(2)
    ANDROID.enter_text(pwd, 2)
  end

  ############################################################################################################
  # Method Name: logInWithPhone
  # Parameters : phone, pin
  # Description: The method Logs in with phone and pin
  #############################################################################################################
  def logInWithPhone(phone, pin)
    # If the view is email password view, then change to phone pin view
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    ANDROID.wait_till_id_visible(@@options_title_id)
    ANDROID.tap2(@@select_phone_pin)
    ANDROID.wait_till_id_visible(@@phone_tab_id)

    # Enter country code
    ANDROID.tap2("* id:'#{@@phone_country_code}'")
    ANDROID.clear_text(1)
    ANDROID.enter_text("1", 1)

    # Enter phone number and pin
    ANDROID.tap2("* id:'#{@@phone_tab_id}'")
    ANDROID.clear_text(2)
    ANDROID.enter_text(phone, 2)
    ANDROID.clear_text(3)
    ANDROID.enter_text(pin, 3)
  end

  ############################################################################################################
  # Method Name: loginWithCountryCode
  # Parameters : country code, phone, pin
  # Description: The method Logs in with Country Code, Phone and Pin
  #############################################################################################################
  def loginWithCountryCode(country_code, phone, pin)
    sleep 2
    if ANDROID.does_element_exist?(" * id:'tvNumber' {text CONTAINS 'XX'}")
      puts "DEBUG: PREVIOUSLY LOGGED IN USER FOUND"
      ANDROID.tap2(@@login_options)
      ANDROID.wait_till_id_visible(@@login_options_id)
      tap_on_switch_user
    end
    puts "NO PREVIOUSLY LOGGED IN USER"
    # If the view is email password view, then change to phone pin view
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    ANDROID.wait_till_id_visible(@@options_title_id)
    ANDROID.tap2(@@select_phone_pin)
    ANDROID.wait_till_id_visible(@@phone_tab_id)

    # Enter country code
    ANDROID.tap2("* id:'#{@@phone_country_code}'")
    ANDROID.clear_text(1)
    ANDROID.enter_text(country_code, 1)

    # Enter phone number and pin
    ANDROID.tap2("* id:'#{@@phone_tab_id}'")
    ANDROID.clear_text(2)
    ANDROID.enter_text(phone, 2)
    ANDROID.clear_text(3)
    ANDROID.enter_text(pin, 3)
  end

  ############################################################################################################
  # Method Name: verifyLoginSuccess
  # Parameters : none
  # Description: The method is for Validation of Successful Login
  #############################################################################################################
  def verifyLoginSuccess
    #Building a RETRY with login as the endpoint is not being set right at times.
    ANDROID.wait_for_progressbar
    ANDROID.login_retry(@@paypal_logo_id)
    ANDROID.wait_till_id_visible(@@paypal_logo_id)
  end

  ############################################################################################################
  # Method Name: goto_LWLI
  # Parameters : none
  # Description: The method takes user to LWLI from successfull Login
  #############################################################################################################
  def goToLWLI
    ANDROID.swipe_left
    ANDROID.tap2("* id:'#{@@logout_menu_id}'")
    ANDROID.wait_till_id_visible(@@login_button_id)
  end

  ############################################################################################################
  # Method Name: logOut
  # Parameters :
  # Description: The method is Logs out from the app
  #############################################################################################################
  def logOut
    ANDROID.swipe_left
    ANDROID.tap2("* id:'#{@@logout_menu_id}'")
    ANDROID.tap2("* id:'#{@@yes_text}'")
    ANDROID.wait_till_id_visible(@@paypal_logo_id)
  end

  ############################################################################################################
  # Method Name: enter_LWLI_pwd
  # Parameters :
  # Description: The method enters password and taps on Login button
  #############################################################################################################
  def enterPwdOnLWLI(pwd)
    ANDROID.wait_till_id_visible(@@password_LWLI_id)
    ANDROID.clear_text(1)
    ANDROID.enter_text(pwd, 1)
    ANDROID.tap2("* id:'#{@@login_button_id}'")
  end

  ############################################################################################################
  # Method Name: tapLWLICaret
  # Parameters :
  # Description: The method taps once the Caret on teh login dialog to go to full login
  #############################################################################################################
  def tapLWLICaret
    # tap back button to get rid of the soft keyboard
    # without which the tap on LWL caret is not working
    ANDROID.hardware_back
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    ANDROID.wait_till_id_visible(@@options_title_id)
  end

  ############################################################################################################
  # Method Name: tap_on_switch_user
  # Parameters :
  # Description: Tap on switch user button
  #############################################################################################################
  def tap_on_switch_user
    arr = ANDROID.get_text_array(@@login_options_class)
    ind = arr.count-1
    # Tap only on switch user button only when visible
    # else go back to login screen
    if arr.count > 8
      que = @@login_options_class + " index:#{ind}"
      ANDROID.tap2(que)
      puts "DEBUG: Tapped on switch user"
    else
      ANDROID.hardware_back
    end
  end

  ############################################################################################################
  # Method Name: Login with email and password
  # Parameters :
  # Description: The method selects email tab or phone tap based on the parameters
  #############################################################################################################

  def login(email, pwd)
    if email.include? "@"
      logInWithEmail(email, pwd)
    else
      logInWithPhone(email, pwd)
    end
  end

  def switch_user
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    ANDROID.wait_till_id_visible(@@options_title_id)
    tap_on_switch_user
  end


  ############################################################################################################
  # Method Name: tapLogin
  # Parameters :
  # Description: The method taps on the login button
  #############################################################################################################

  def tapLogin(email)
    ANDROID.tap2("* id:'#{@@login_button_id}'")
  end


  ############################################################################################################
  # Method Name: verifyLoginPage
  # Parameters :
  # Description: The method enters checks for ids on the login page
  #############################################################################################################

  def verifyEmailPhoneTab
    ANDROID.assert_id_visible(@@email_tab_id)
    #ANDROID.assert_id_visible(@@phone_tab_id)
  end

  ###########################################################################################################
  # Method Name: logoutFromSubmenu
  # Parameters :
  # Description: Method to Log out from sub menu
  #############################################################################################################

  def logoutFromSubmenu
    ANDROID.hardware_back
    logOut
  end

  ###########################################################################################################
  # Method Name: tapOkButton
  # Parameters :
  # Description: Method to tap on ok button
  #############################################################################################################

  def tapOkBtn
    ANDROID.tap(@@ok_btn_element, "element")
  end

  ###########################################################################################################
  # Method Name: verify error message
  # Parameters :
  # Description: Method to verify error message
  #############################################################################################################

  def verifyErrorMsg
    ANDROID.wait_for_progressbar
    ANDROID.wait_till_element_visible(@@error_message_element)
    ANDROID.assert_element_exist(@@error_message_element)
    ANDROID.assert_element_exist(@@ok_btn_element)
  end

  ###########################################################################################################
  # Method Name: turnRememberMeOn
  # Parameters :
  # Description: Method to Turn Remember ON for Settings Menu
  #############################################################################################################

  def turnRememberMeOn
    check = ANDROID.check_checkbox(@@rememberme_checkbox_id)
    if !check
      ANDROID.wait_till_id_visible(@@rememberme_checkbox_id)
      ANDROID.tap(@@rememberme_checkbox_id, "id")
    end
  end


  ###########################################################################################################
  # Method Name: tapAddToBtn
  # Parameters :
  # Description: Method to tap AddTO Btn on the wallet page
  #############################################################################################################

  def tapAddToBtn
    ANDROID.tap(@@addMoney_id, "id")
    ANDROID.wait_for_progressbar
  end


  ###########################################################################################################
  # Method Name:  tapWithdrawBtn
  # Parameters :
  # Description: Method to tap withdraw button on the wallet page
  #############################################################################################################

  def tapWithdrawBtn
    ANDROID.tap(@@withdrawMoney_id, "id")
    ANDROID.wait_for_progressbar
  end


  ###########################################################################################################
  # Method Name:  verifySessionTimeoutLogin
  # Parameters :
  # Description: Method to verify Login success after logging from session Timeout
  #############################################################################################################


  def verifySessionTimeoutLogin
    ANDROID.wait_for_progressbar
    ANDROID.hardware_back
    ANDROID.wait_for_progressbar
    ANDROID.hardware_back
    verifyLoginSuccess
  end


  ###########################################################################################################
  # Method Name: viewAllActivity
  # Parameters :
  # Description: Method to tap on viewAllActivity button from the Activity page
  #############################################################################################################

  def viewAllActivity
    ANDROID.tap(@@viewallacitivity_id, "id")
  end

  ###########################################################################################################
  # Method Name: verifyShoppageicons
  # Parameters :
  # Description: Method to assert for shop page icons
  #############################################################################################################

  def verifyShoppageicons
    ANDROID.wait_till_id_visible(@@search_id)
    ANDROID.assert_id_visible(@@refreshicon_id)
    ANDROID.assert_id_visible(@@mapicon_id)
  end


  ###########################################################################################################
  # Method Name: loginAfterLogout
  # Parameters :
  # Description: Method to login after a logout
  #############################################################################################################

  def loginAfterLogout
    ANDROID.swipe_left
    ANDROID.tap2(@@login_menu_id)
  end

  ############################################################################################################
  # Method Name: enterSecret
  # Parameters : secret
  # Description: The method enters the secret
  #############################################################################################################

  def enterSecret(secret)
    ANDROID.clear_text(2)
    ANDROID.enter_text(secret, 2)
  end

  ############################################################################################################
  # Method Name: taploginbutton
  # Parameters :
  # Description: The method taps the login button depending on the tab (email/phone)
  #############################################################################################################

  def tapLoginButton
    ANDROID.tap2("* id:'#{@@login_button_id}'")
  end

  ############################################################################################################
  # Method Name: logInWithPhonePin
  # Parameters : pin
  # Description: The method taps on the phone tab and enters the pin
  #############################################################################################################

  def logInWithPhonePin(pin)
    # Go to login options and change to phone pin option
    ANDROID.tap2("* id:'#{@@login_options_id}'")

    arr = ANDROID.get_text_array(@@login_options_class)
    ind = arr.count-4
    que = @@login_options_class + " index:#{ind}".to_s
    ANDROID.tap(que, "element")

    ANDROID.tap(@@login_pin_id, "id")
    ANDROID.clear_text(1)
    ANDROID.enter_text(pin, 1)
  end

  ############################################################################################################
  # Method Name: logInWithEmailPassword
  # Parameters : password
  # Description: The method taps on the email tab and enters the pin
  #############################################################################################################

  def logInWithEmailPassword(password)
    # Go to login options and change to email password option
    ANDROID.tap2("* id:'#{@@login_options_id}'")

    arr = ANDROID.get_text_array(@@login_options_class)
    ind = arr.count-5
    que = @@login_options_class + " index:#{ind}".to_s
    ANDROID.tap(que, "element")

    ANDROID.clear_text(1)
    ANDROID.enter_text(password, 1)
  end

  ############################################################################################################
  # Method Name: refreshWallet
  # Parameters :
  # Description: The method refreshes the wallet page
  #############################################################################################################

  def refreshWallet
    sleep 0.5
    ANDROID.assert_id_visible(@@refresh_menu_id)
    ANDROID.tap(@@refresh_menu_id, "id")
    ANDROID.wait_for_actionbar_progress
  end

  ############################################################################################################
  # Method Name: verifyDisabledLogin
  # Parameters :
  # Description: Check that the login button is disabled
  #############################################################################################################

  def verifyDisabledLogin
    enabled = ANDROID.check_roboto_button_enabled(@@login_button_id)
    if enabled
      raise "Error: Login button should be disabled"
    end
  end

  ############################################################################################################
  # Method Name: tapForgotPassword
  # Parameters :
  # Description: User taps on the forgot password button
  #############################################################################################################
  def tapForgotPassword
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    ANDROID.wait_till_id_visible(@@login_button_phone_id)

    arr = ANDROID.get_text_array(@@login_options_class)
    ind = arr.count-1
    que = @@login_options_class + " index:#{ind}".to_s
    ANDROID.tap2(que)
  end

  ############################################################################################################
  # Method Name: verifyForgotDialog
  # Parameters :
  # Description: Check that the dialog appears
  #############################################################################################################
  def verifyForgotDialog
    ANDROID.wait_till_id_visible(@@alert_message_id)
  end

  ############################################################################################################
  # Method Name: checkSecuritySetting
  # Parameters : isVisible
  # Description: Check that the security setting is visible or not
  #############################################################################################################
  def checkSecuritySetting(isVisible)
    ANDROID.wait_till_id_visible(@@settings_id)
    if isVisible != ANDROID.check_id(@@security_settings_id)
      raise "ERROR: Security settings should be #{isVisible}"
    end
  end

  def verifyLoginScreen
    ANDROID.check_id_exists(@@login_button_id)
  end

  def verifyShopScreen
    if !ANDROID.check_id(@@shop_refresh_id)
      raise "User should be on the Shop screen after launch"
    end
  end

  def verifyToastMsg(msg)
    ANDROID.assert_text_visible(msg)
  end

  def verify_no_phone_pin
    ANDROID.wait_till_id_visible(@@login_button_id)
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    arr = ANDROID.get_text_array(@@login_options_class)
    if(arr.count > 6)
      raise "Phone pin should not be available for non-mobile enabled countries"
    end
  end

  def tap_on_login_options
    ANDROID.tap2("* id:'#{@@login_options_id}'")
  end

  def verify_login_after_switch_account
    # verify phone number and pin
    if ANDROID.check_id(@@phone_tab_id)
      if ANDROID.get_text_from_id(@@phone_country_code) != ""
        raise "Phone number field is not empty after switch account"
      elsif ANDROID.get_text_from_id(@@login_pin_id) != ""
        raise "PIN field is not empty after switch account"
      end
       # verify email and password fields
    elsif ANDROID.get_text_from_id(@@email_tab_id) != ""
           raise "Phone number field is not empty after switch account"
         elsif ANDROID.get_text_from_id(@@email_pwd_field_id) != ""
                raise "PIN field is not empty after switch account"
    end
  end

  def login_after_logout(secret)
    ANDROID.tap2("* id:'#{@@paypal_logo_id}'")
    ANDROID.tap2("* id:'#{@@Login_after_logout_button}'")
    ANDROID.tap2("* id:'#{@@login_options_id}'")
    ANDROID.tap2("* id:'#{@@Phonepin_button}' index:1")
    ANDROID.enter_text_by_id(secret, @@login_pin_id)
    ANDROID.tap2("* id:'#{@@login_button_id}'")
  end
end
