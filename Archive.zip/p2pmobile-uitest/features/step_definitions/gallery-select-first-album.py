###
# Author
# Sarika Kamisetty
###

# This script is automate adding photo from gallery using Monkeyrunner tool
# as using Calabash we cannot touch the Gallery UI

from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice
device = MonkeyRunner.waitForConnection()
device.press('KEYCODE_DPAD_CENTER')
device.touch(525,750,"DOWN_AND_UP")
device.press('KEYCODE_DOWN_AND_UP')
device.touch(525,950,"DOWN_AND_UP")



