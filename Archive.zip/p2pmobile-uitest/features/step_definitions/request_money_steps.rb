require_relative 'request_money_functional'

requestmoney_functional = RequestMoney_Functional.new

######################################################################
## Scenario 1: Request money US account to US phone number, using currency picker
######################################################################


Then(/^user can request money to "(.*?)", "(.*?)", "(.*?)" and "(.*?)"$/) do |amt, recipient, currency, msg|
  NAV.goToRequestMoney
  requestmoney_functional.fillUpRequestForm(recipient, amt, msg, currency)
  requestmoney_functional.tapOnRequestBtn
end

Then(/^user can request money from "([^"]*)" with the amount "([^"]*)" in currency "([^"]*)" with message "([^"]*)"$/) do |sender, amount, currency, msg|
  NAV.goToRequestMoney
   requestmoney_functional.fillUpRequestForm(amount,sender,msg, currency)
    requestmoney_functional.tapOnRequestBtn
end

And(/^request money is successful$/) do
  requestmoney_functional.verifySuccessMsg
  requestmoney_functional.tapDoneBtn

end



And(/^user tries to request money to "(.*?)", "(.*?)", "(.*?)" and "(.*?)"$/) do |amt, recipient, currency, msg|
  NAV.goToRequestMoney
  requestmoney_functional.fillUpRequestForm(recipient, amt, msg, currency)

end

Then(/^request money button should be disabled$/) do

  requestmoney_functional.verifyRequestBtnIsDisabled

end

Then(/^user can request money again to "(.*?)", "(.*?)", "(.*?)" and "(.*?)"$/) do |amt, recipient, currency, msg|
  requestmoney_functional.fillUpRequestForm(recipient, amt, msg, currency)
  requestmoney_functional.tapOnRequestBtn
end

When(/^user tries to request money from "([^"]*)", amount "([^"]*)", currency "([^"]*)", message "([^"]*)"$/) do |recipient, amt, currency, msg|
  NAV.goToRequestMoney
  requestmoney_functional.fillUpRequestForm(recipient, amt, currency, msg)
  requestmoney_functional.tapOnRequestBtn

end

Then(/^user can request money successfully$/) do
  requestmoney_functional.verifySuccessMsg
  requestmoney_functional.tapDoneBtn
end


When(/^user tries to request amount of "([^"]*)", using currency "([^"]*)" from multiple users "([^"]*)", "([^"]*)", with "([^"]*)" message$/) do |amt, currency, recipient1, recipient2, msg|
  NAV.goToRequestMoney
  requestmoney_functional.fillUpRequestFormMultipleUsers( amt, currency, recipient1, recipient2, msg)
  requestmoney_functional.tapOnRequestBtn
end

When(/^user tries to request money from "([^"]*)", amount "([^"]*)", currency "([^"]*)", without message$/) do |recipient, amt, currency|
  NAV.goToRequestMoney
  #requestmoney_functional.fillUpRequestFormWithoutmsg(recipient, amt, currency)
  msg=nil
  requestmoney_functional.fillUpRequestForm(recipient,amt,currency,msg)
  requestmoney_functional.tapOnRequestBtn
end