class AddCard_Functional

  @type
  @month
  @year
  @csc
  @number

  ############################################################################################################
  @@bill_address_id = "bill_address"
  @@exp_date_id = "exp_date"
  @@csc_id = "csc"
  @@card_number_id = "card_number"
  @@exp_year_id = "timepicker_input"
  @@exp_month_id = "timepicker_input"
  @@ok_button_text = "OK"
  @@addcard_button_id = "card_add_button"
  @@add_address_button_id = "add_address_button"
  @@continue_button_id = "xcontinue"
  @@address_editText_id = "address1"
  @@city_editText_id = "city"
  @@state_spinner_id = "state_button"
  @@zip_editText_id = "zip"
  @@addcard_popup_ok_button_id = "button1"
  @@addcard_popup_message_id = "message"
  @@timepicker = "timepicker_input"
  @@expirydate_popup_ok_button_id = "popup_accept_button"
  ############################################################################################################

  def verifyAddCardFields
    # Check for card number
    ANDROID.assert_id_visible(@@card_number_id)
    # Check for exp date
    ANDROID.assert_id_visible(@@exp_date_id)
    # Check for CSC
    ANDROID.assert_id_visible(@@csc_id)
    # Check for address
    ANDROID.assert_id_visible(@@bill_address_id)
  end

  def selectCardType(type)
    if type == "Credit"
      ANDROID.tap("Credit Card", "text")
    elsif type == "Debit"
      ANDROID.tap("Debit Card", "text")
    end
  end

  def enterCardDetails(type, exp_date, csc)
    month, year = exp_date.split('/')
    @type = type
    @csc = csc
    @month = month
    @year = year
    if type == "Invalid"
      enterCardNumber("848484848484848")
    else
      if type == "American Express"
        digits = 15
      else
        digits = 16
      end
      generateCC(type, digits)
    end
    enterCsc(csc)
    if exp_date != ""
      enterDate(month, year)
    end
  end

  def enterGivenCardDetails(num,type, exp_date, csc)
    month, year = exp_date.split('/')
    @type = type
    @csc = csc
    @month = month
    @year = year
    @number = num
    enterCardNumber(@number)
    enterCsc(csc)
    if exp_date != ""
      enterDate(month, year)
    end
  end

  def enterDuplicateCardDetails
    enterCardNumber(@number)
    enterCsc(@csc)
    enterDate(@month, @year)
  end

  def enterCardNumber(number)
    ANDROID.clear_text(1)
    ANDROID.enter_text(number, 1)
  end

  def clearCardNumber
    ANDROID.clear_text(1)
  end

  def generateCC(cardType, digits)
    @number = NAV.generate_cc(cardType, digits)
    enterCardNumber(@number)
  end

  def enterDate(month, year)
    ANDROID.tap( @@exp_date_id, "id")
    ANDROID.clear_text(1)
    ANDROID.enter_text(month.to_i, 1)
    ANDROID.clear_text(2)
    ANDROID.enter_text(year.to_i, 2)
    ANDROID.tap(@@ok_button_text, "button")
  end

  def enterCsc(csc)
    ANDROID.enter_text(csc, 2)
  end

  def tapAddCard
    ANDROID.tap(@@addcard_button_id, "id")
    ANDROID.wait_for_progressbar
  end

  def tapContinue
    ANDROID.tap(@@continue_button_id, "id")
  end

  def tapOK
    ANDROID.wait_till_id_visible(@@addcard_popup_message_id)
    ANDROID.tap(@@ok_button_text, "button")
  end

  def tapAddress
    ANDROID.tap(@@bill_address_id, "id")
  end

  def tapAddAddress
    ANDROID.tap(@@add_address_button_id, "id")
  end

  def addAddress(address, state, city, zip)
    enterAddress(address)
    enterCity(city)
    if state != ""
      enterState(state)
    end
    enterZip(zip)
  end

  def enterAddress(address)
    ANDROID.enter_text(address, 1)
  end

  def enterCity(city)
    ANDROID.enter_text(city, 3)
  end

  def enterState(state)
    ANDROID.tap(@@state_spinner_id, "id")
    while !ANDROID.check_text(state) do
      ANDROID.scroll_down
    end
    ANDROID.tap(state, "text")
  end

  def enterZip(zip)
    ANDROID.enter_text(zip, 4)
  end

  def verifyAddAddressFields
    # Check for Address
    ANDROID.assert_id_visible(@@address_editText_id)
    # Check for City
    ANDROID.assert_id_visible(@@city_editText_id)
    # Check for State
    ANDROID.assert_id_visible(@@state_spinner_id)
    # Check for Zip
     ANDROID.assert_id_visible(@@zip_editText_id)
  end

  def verifyNoAddCard
    if ANDROID.check_text("Credit Card") or ANDROID.check_text("Debit Card")
      raise "There should not be an option to add credit or debit card"
    end
  end

  def verifyAddedCard
    ANDROID.wait_for_progressbar
    last_four_digits = @number[-4..-1]
    ANDROID.wait_till_text_visible(last_four_digits)
  end

  # Check that the expiration date dialog's ok button is disabled
  def verifyExpirationDateDialogOkButtonOff
    ANDROID.assert_id_visible(@@timepicker)
    if ANDROID.check_button_enabled(@@expirydate_popup_ok_button_id)
      raise "OK button should be disabled."
    end
  end

  def verifyMsg(text)
    ANDROID.assert_text_visible(text)
  end

  def verifyAddCardButtonDisabled
    if ANDROID.check_roboto_button_enabled(@@addcard_button_id)
      raise "Add card button should be disabled."
    end
  end

  def delete_added_creditcard
    ANDROID.tap2("* id:'#{'item_title'}'")
    ANDROID.tap2("* id:'#{'edit_button'}'")
    ANDROID.tap2("* id:'#{'remove_button'}'")
    ANDROID.tap2("* id:'#{'button1'}'")

  end

end
