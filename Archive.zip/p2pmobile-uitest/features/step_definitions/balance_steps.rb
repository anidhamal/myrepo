require_relative 'balance_functional'
require_relative 'balance_ui'

balance_functional = Balance_Functional.new
balance_ui = Balance_UI.new

######################################################################
## Scenario 1: View balance on Wallet page
######################################################################
Then(/^user can see balance on Wallet page$/) do

  NAV.goToWallet
  balance_functional.verifyWalletBalance

end

And(/^user can see balances on balance details page$/) do

  NAV.goToBalanceDetailsPg
  balance_functional.verifyBalanceDetails

end

######################################################################
## Scenario 2: View balance on Activity Page
######################################################################
Then(/^user can see balances on Activity page$/) do
  NAV.goToActivity
  balance_functional.verifyActivityBalance

end



#TODO: Remove these

When /^user can see balance in currency "([^"]*)" on Activity Page$/ do |currency|
  NAV.goToActivity
  balance_functional.waitForHistoryBusinessUser
  balance_ui.verifyActivityBalanceCurrency(currency)
end

When /^business user can see balance in currency "([^"]*)" on Activity Page$/ do |currency| #TODO: This needs to go away when we get QADevConfig working for launch page
  ANDROID.swipe_left
  ANDROID.wait_till_id_visible("button_activity")
  ANDROID.tap("button_activity", "id")
  ANDROID.wait_till_text_visible("Yes")
  ANDROID.tap("Yes", "text")
end

Then /^user can see balance in currency "([^"]*)" on Wallet page$/ do |currency|
  NAV.goToWallet
  balance_ui.verifyWalletBalanceCurrency(currency)
end
When /^user can see balance details with available "([^"]*)" and pending "([^"]*)"$/ do |availableBalance, pendingBalance|
  NAV.goToBalanceDetailsPg
  balance_ui.verifyBalanceDetails(availableBalance, pendingBalance)
  balance_ui.verifyWalletCurrencyDetails(availableBalance)
end
Then /^user checks available balance "([^"]*)" on Add To page$/ do |balance|
  NAV.goToAddFunds
  balance_ui.verifyBalance(balance)
end
Then /^user goes back to wallet page$/ do
  balance_functional.goToWalletFromAddOrWithdraw()
end
Then /^user checks available balance "([^"]*)" on Withdraw page$/ do |balance|
  NAV.goToWithdraw
  balance_ui.verifyBalance(balance)
end
Then /^user checks available balance "([^"]*)" on Wallet page$/ do |balance|
  NAV.goToWallet
  balance_ui.verifyBalance(balance)
end
Then /^user checks available balance "([^"]*)" on Activity page$/ do |balance|
  NAV.goToActivity
  balance_ui.verifyBalance(balance)
end

########################################
#  User refreshes the wallet page
########################################
And /^user refreshes Activity Page$/ do
  NAV.goToActivity
  ActivityFunctional.refreshActivity
end