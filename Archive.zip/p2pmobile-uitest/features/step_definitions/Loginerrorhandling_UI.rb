class LoginerrorHandling_UI

  def verify_error_message(error)
    ANDROID.wait_for_progressbar
    ANDROID.wait_till_id_visible ('message')
    ANDROID.take_screenshot
    actual_error = ANDROID.get_text_from_id('message').first.strip
    actual_error=actual_error.gsub("???", "\u2019").strip
    if actual_error != error.strip
      raise "Error did not match. Got: #{actual_error} Expected: #{error}"
    end
  end
end