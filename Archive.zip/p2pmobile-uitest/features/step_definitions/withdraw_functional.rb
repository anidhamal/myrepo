class WithdrawInitFunctional

  AMOUNT_EDIT_ID = 'amount_edit'
  WITHDRAW_BUTTON_ID = 'withdraw_funds_button'
  BALANCE_ID = 'text'
  SELECT_BALANCE_ELEMENT = 'android.widget.TextView index:2'
  SELECT_BANK_ELEMENT = 'android.widget.TextView index:1'
  BANK_TEXT = 'Bank'
  OK_BTN_ELEMENT = 'android.widget.Button index:1'
  OK_WITHDRAW_FEES = 'button1'
  TAP_CONTINUE_BUTTON = 'continue_withdrawal_button'
############################################################################################################
# Method Name: enterAmount
# Parameters :
# Description: This method will enter amount in the text field
#############################################################################################################
  def self.enterAmount(amount)
    ANDROID.tap2("* id:'#{AMOUNT_EDIT_ID}'")
    ANDROID.enter_text(amount, 1)
  end

############################################################################################################
# Method Name: tapWithdrawBtn
# Parameters :
# Description: This method will tap on withdraw button
#############################################################################################################
  def self.tapWithdrawBtn
    ANDROID.wait_till_id_visible(WITHDRAW_BUTTON_ID)
    ANDROID.tap(WITHDRAW_BUTTON_ID, 'id')
  end

############################################################################################################
# Method Name: SwitchBalance
# Parameters :
# Description: This method will change from one balance to another
#############################################################################################################

  def self.switchBalance
    ANDROID.wait_till_id_visible(BALANCE_ID)
    ANDROID.tap(BALANCE_ID, 'id')
    ANDROID.wait_till_element_visible(SELECT_BALANCE_ELEMENT)
    ANDROID.tap(SELECT_BALANCE_ELEMENT, 'element')
  end

############################################################################################################
# Method Name: SwitchBankAcct
# Parameters :
# Description: This method will change from one bank to another bank
#############################################################################################################

  def self.switchBankAcct
    ANDROID.wait_till_text_visible(BANK_TEXT)
    ANDROID.tap(BANK_TEXT, 'text')
    ANDROID.wait_till_element_visible(SELECT_BANK_ELEMENT)
    ANDROID.tap(SELECT_BANK_ELEMENT, 'element')
  end

############################################################################################################
# Method Name: tapokBtn
# Parameters :
# Description: This method will tap on ok button
#############################################################################################################

  def self.tapOkBtn
    ANDROID.tap2("* id:'#{OK_WITHDRAW_FEES}'")
    ANDROID.tap2("* id:'#{WITHDRAW_BUTTON_ID}'")
  end

############################################################################################################
# Method Name: verifyWithdrawButtonDisabled
# Parameters :
# Description: This method will check whether the withdraw button is disabled
#############################################################################################################

  def self.verifyWithdrawButtonDisabled
    if ANDROID.check_roboto_button_enabled(WITHDRAW_BUTTON_ID)
      raise 'Withdraw card button should be disabled.'
    end
  end

  def self.confirmwithFees
    ANDROID.tap2("* id:'#{OK_WITHDRAW_FEES}'")
  end

  def self.tapConfirm
    ANDROID.tap2("* id:'#{TAP_CONTINUE_BUTTON}'")
  end
end

class WithdrawFinalPageFunctional

  COMPLETION_STATUS_ID = 'completion_status'
  SUCCESS_SUMMARY_ID = 'success_summary'
  SUCCESS_DETAILS_ID = 'success_details'
  DONE_BUTTON_ID = 'done_button'

  ############################################################################################################
  # Method Name: verifyWithdrawSuccess
  # Parameters :
  # Description: This method will verify success message screen after withdraw money
  #############################################################################################################

  def self.verifyWithdrawSuccess
    ANDROID.wait_till_id_visible(COMPLETION_STATUS_ID)
    ANDROID.assert_id_visible(SUCCESS_SUMMARY_ID)
    ANDROID.assert_id_visible(SUCCESS_DETAILS_ID)
    ANDROID.assert_id_visible(DONE_BUTTON_ID)
  end

  ############################################################################################################
  # Method Name: tapDone
  # Parameters :
  # Description: This method will tap on done button
  #############################################################################################################

  def self.tapDone
    ANDROID.tap2("* id:'#{DONE_BUTTON_ID}'")
  end
end

