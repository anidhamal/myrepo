###
# Author
# Indumathy Kesavan
#
###
class RecentActivityUI

  ID_TITLE = 'title'
  ID_AMOUNT = 'amount'
  # user verifies for business name in activity page
  def self.verify_business_name(name)
    ANDROID.wait_till_id_visible(ID_TITLE)
    ANDROID.check_an_element_exists("* id:'#{ID_TITLE}' * {text CONTAINS '#{name}'}")
  end

  # user verifies for phone number in activity page
  def self.verify_phone_number(phone)
    ANDROID.wait_till_id_visible(ID_TITLE)
    ANDROID.check_an_element_exists("* id:'#{ID_TITLE}' * {text CONTAINS '#{phone}'}")
  end

  # user verifies email id in activity page
  def self.verify_email(email)
    ANDROID.wait_till_id_visible(ID_TITLE)
    ANDROID.check_an_element_exists("* id:'#{ID_TITLE}' * {text CONTAINS '#{email}'}")
  end

  # user verifies for currency in activity page
  def self.verify_currency_type(currencytype)
    ANDROID.wait_till_id_visible(ID_AMOUNT)
    ANDROID.check_an_element_exists("* id:'#{ID_AMOUNT}' * {text CONTAINS '#{currencytype}'}")
  end
end

class ActivityDetailsUI
  ID_HISTORY_TAB = 'history_tabs'
  ID_AMOUNT_VALUE = 'dcPPHistoryDetailsAmountValue'
  ID_TRANSACTION_TYPE = 'dcPPHistoryDetailsTypeValue'
  ID_ACTIVITY_DETAILS_TITLE = 'dcPPHistoryDetailsTitle'
ID_STATUS = 'dcPPHistoryDetailsStatusValue'

  # user verifies withdraw transaction in activity details page
  def self.verify_amount_type(amt, type)
    ANDROID.wait_till_id_visible(ID_HISTORY_TAB)
    ANDROID.check_an_element_exists("* id:'#{ID_AMOUNT_VALUE}' * {text CONTAINS '#{amt}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_TRANSACTION_TYPE}' * {text CONTAINS '#{type}'}")
  end

  # user looks for amount, status and name text
  def self.verify_transaction_details(amount, status, name)
    ANDROID.wait_till_id_visible(ID_ACTIVITY_DETAILS_TITLE)
    ANDROID.check_an_element_exists("* id:'#{ID_AMOUNT_VALUE}' * {text CONTAINS '#{amount}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_STATUS}' * {text CONTAINS '#{status}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_HISTORY_TAB}' * {text CONTAINS '#{name}'}")


  end
end

