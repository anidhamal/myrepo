####################################################
# User verifies for gift card option in wallet page
####################################################
Then(/^user should see gift card option$/) do
  ActionSheet_Functional.verify_giftcard
end
####################################################
# User taps on gift acrd option in wallet page
####################################################
Then(/^user taps on gift card option$/) do
  NAV.goToGiftCard
end
####################################################
# User taps on gift card merchant
####################################################
When(/^user taps on first merchant in gift card merchant list view$/) do
  GiftCardInitFunctional.tap_giftcard_mercant
end
###############################################################
# User enters the gift card numbers in gift card info page
################################################################
Then(/^user enters gift card number "([^"]*)" and pin "([^"]*)" that has existing balance$/) do |cardnumber, pin|
  GiftCardInfoFunctional.enter_giftcard_details(cardnumber, pin)
end
####################################################
# User taps on link a gift card in gift card info page
####################################################
Then(/^user taps Add card button on Add Gift Card page$/) do
  GiftCardInfoFunctional.tap_add_giftcard
end
####################################################
# User verifies added gift card
####################################################
And(/^user sees the added gift card on the wallet$/) do
  GiftCardInitFunctional.verify_added_giftcard
end
##########################################################################
# User taps on "where can I find this information" in gift card info page
##########################################################################
Then(/^user taps on where can I find this information\? link$/) do
  GiftCardInfoFunctional.tap_info_finder
end
####################################################
# User verifies the back of the card information and closes out the page
####################################################
Then(/^user verifies the back of the card information and closes out of the view$/) do
  GiftCardInfoFunctional.tap_info_finder
  GiftCardInfoFunctional.tap_anywhere_back_image
end
####################################################
# User verifies card info page
####################################################
Then(/^user sees the Add Gift Card screen$/) do
  GiftCardInfoUI.verify_giftcard_info_page
end
############################################################
# User taps on terms and conditions on gift card info page
#############################################################
Then(/^user taps on Terms and Conditions link$/) do
  GiftCardInfoFunctional.taps_terms_conditions
end
####################################################
# User verifies terms and condition page
####################################################
Then(/^user verifies the terms and conditions information and taps back out of the view$/) do
  GiftCardInfoUI.verify_terms_conditions
end
####################################################
# User enters the card details
####################################################
Then(/^user enters gift card number "([^"]*)" and pin "([^"]*)" that has zero balance$/) do |cardnumber, pin|
  GiftCardInfoFunctional.enter_giftcard_details(cardnumber, pin)
end
####################################################
# User search for the merchant in search page
####################################################
And(/^user searches for merchant "([^"]*)" in gift card search$/) do |merchant|
  GiftCardInfoFunctional.search_giftcard_merchant(merchant)
end
####################################################
# User taps on the merchant after searching
####################################################
When(/^user taps on the merchant from the results$/) do
  GiftCardInfoFunctional.tap_giftcard_merchant_in_search_list
end
####################################################
# User verifies the card info page
####################################################
Then(/^user goes to add gift card view$/) do
  GiftCardInfoUI.verify_giftcard_info_page
end
#####################################################################
# After verifying the gift card info page , user taps on back button
######################################################################
When(/^user taps back button on add gift card view$/) do
  GiftCardInfoFunctional.tap_back
end
#######################################################################################
# After verifying the gift card info page , user navigates back to merchant search page
#######################################################################################
Then(/^user should see the gift search results view for merchant "([^"]*)"$/) do |arg|
  GiftCardInitFunctional.merchant_search_page
end
##############################################
# user verifies for gift card category
##############################################
Then(/^user should see Gift Cards Category$/) do
  GiftCardInitUI.verify_giftcard_category
end
####################################################
# user taps on cancel button when link a balance message pops up
#########################################################
Then(/^user verifies the options and taps on cancel button$/) do
  GiftCardInfoFunctional.tap_cancel_message
end
####################################################
# user taps on link button when link a balance message pops up
#########################################################
Then(/^user verifies the options and taps on link$/) do
  GiftCardInfoFunctional.tap_link_message
end
###################################################
# user should see that the link does not exist
#########################################################
Then(/^user should not see gift card option$/) do
  ActionSheet_Functional.verify_no_giftcard
end
########################################################
# user searches for the merchant in gift card search page
#########################################################
When(/^user search for merchant "([^"]*)"$/) do |merchant|
  GiftCardInfoFunctional.search_giftcard_merchant(merchant)
  GiftCardInfoFunctional.tap_giftcard_merchant_in_search_list
end
##############################################
# user enters the gift card number and pin
##############################################
Then(/^user adds a gift card with card number "([^"]*)" and pin "([^"]*)"$/) do |cardnumber, pin|
  GiftCardInfoFunctional.enter_giftcard_details(cardnumber, pin)
end
####################################################
# user taps on added gift card
#########################################################
Given(/^I am on Gift Card Details page$/) do
  GiftCardInitFunctional.tap_wallet_giftcard
end
####################################################
# user verifies gift card detail page
#########################################################
And(/^user sees the edit gift card details page$/) do
  GiftcardDetailUI.verify_giftcard_detail_page
end
####################################################
# user verifies gift card edit page
#########################################################
And(/^user sees the balance information in edit gift card page$/) do
  GiftCardEditUI.verify_giftcard_editpage
end
####################################################
# user taps on remove card in edit gift card page
#########################################################
And(/^user taps on the Remove Card$/) do
  GiftCardEditFunctional.tap_removecard_button
end
####################################################
# user verifies remove card confirmation page pop up
#########################################################
And(/^user sees the confirmation message$/) do
  GiftCardEditUI.verify_removecard_confirmation
end
####################################################
# user taps on yes to remove card
#########################################################
Then(/^user taps on yes$/) do
  GiftCardEditFunctional.tap_yes_removecard
end
####################################################
# user enters balance manually in gift card edit page
#########################################################
When(/^user add balance "([^"]*)" manually and click Done button$/) do |balance|
  GiftCardEditFunctional.enter_giftcard_balance(balance)
end
##################################################################
# user comfirms there is no gift cards in wallet page after deleting
###################################################################
And(/^user confirms the removed card$/) do
  GiftCardInitUI.verify_no_giftcard_category
end
##############################################
# user verifies gift card logo on gift card info screen
##############################################
Then /^user sees that the merchant logo is displayed on the add gift card screen$/ do
  GiftCardInfoUI.verify_giftcard_logo
end
##############################################
# user verifies for gift card text
##############################################
Then /^user sees that the merchant name text is displayed on the add gift card screen$/ do
  GiftCardInfoUI.verify_giftcard_text
end
##############################################
# user verifies back image on the gift card info page
##############################################
When /^user verifies the back of the card information$/ do
  GiftCardInfoUI.verify_back_image
end
##############################################
# user taps on the back card image page to dismiss back image
##############################################
When /^user can taps anywhere to close out of the back of the card view$/ do
  GiftCardInfoFunctional.tap_anywhere_back_image
end
##############################################
# user taps on Info link
##############################################
When /^user taps on where to find this info\? link$/ do
  GiftCardInfoFunctional.tap_info_finder
end
##############################################
# user scrolls up and down on gift list view
##############################################
Then /^user should be able to scroll "([^"]*)" the gift list view$/ do |direction|
  if (direction == 'up')
    ANDROID.scroll_up
    ANDROID.scroll_up
    ANDROID.scroll_up
  else
    ANDROID.scroll_down
    ANDROID.scroll_down
    ANDROID.scroll_down
  end
end

##################################################################
# Go to Gift list view from wallet view
##################################################################
Then /^user goes to gift list view$/ do
  NAV.goToWallet
  NAV.goToAddCard
  NAV.goToGiftCard
end
##############################################
# user adds the merchant in the wallet
##############################################
When /^the gift card "([^"]*)" is added already$/ do |merchant|
  NAV.goToWallet
  NAV.goToAddCard
  NAV.goToGiftCard
  GiftCardInfoFunctional.search_giftcard_merchant(merchant)
  GiftCardInfoFunctional.tap_giftcard_merchant_in_search_list
  GiftCardInfoFunctional.enter_giftcard_details(cardnumber, pin)
  GiftCardInfoFunctional.tap_add_giftcard
  GiftCardInitUI.verify_giftcard_category
end
##############################################
# user adds merchant and cardNumber
##############################################
Then /^user goes to gift add card view of the "([^"]*)" with card "([^"]*)"$/ do |merchant, cardNumber|
  NAV.goToWallet
  NAV.goToAddCard
  NAV.goToGiftCard
  GiftCardInfoFunctional.search_giftcard_merchant(merchant)
  GiftCardInfoFunctional.tap_giftcard_merchant_in_search_list
  GiftCardInfoFunctional.enter_giftcard_number(cardNumber)
end
##############################################
# user enters pin on the add Gift card page
##############################################
When /^user does not enter anything in Pin field$/ do
  GiftCardInfoFunctional.enter_giftcard_pin("")
end
##############################################
# user verifies add gift card button disabled.
##############################################
Then /^user sees that the gift add card button is disabled$/ do
  GiftCardInfoFunctional.tap_add_giftcard
  GiftCardInfoUI.verify_giftcard_info_page
end
##############################################
# user verifies info button not available
##############################################
Then /^user should not see where can I find this information\? link$/ do
  GiftCardInfoUI.verify_giftcard_no_info_finder
end
##############################################
# user verifies gift card on the wallet page
##############################################
Then /^user should see gift card "([^"]*)" with merchant logo$/ do |merchant|
  GiftCardInfoUI.verify_giftcard_wallet(merchant)
end
##############################################
# user verifies different params on the gift card page
##############################################
Then /^user should see gift card with merchant name"([^"]*)", card number"([^"]*)", pin "([^"]*)", merchant logo "([^"]*)", card number value "([^"]*)", how to use"([^"]*)", terms link "([^"]*)", edit button "([^"]*)", back button "([^"]*)", and bar code "([^"]*)"$/ do |merchant_name, card_number,pin, merchant_logo, card_number_value, how_to_use, terms_link, edit_button, back_button,bar_code|
  GiftcardDetailUI.verify_view_giftcard(merchant_name, card_number,pin, merchant_logo, card_number_value, how_to_use, terms_link, edit_button, back_button,bar_code)
end
##############################################
# user taps on wallet gift card
##############################################
When /^user taps on the gift card "([^"]*)" on wallet screen$/ do |arg|
  GiftCardInitFunctional.tap_wallet_giftcard
end
##############################################
# user verifies pin on card details page
##############################################
Then /^user sees the "([^"]*)"$/ do |pin|
  GiftCardEditUI.verify_pin(pin)
end
##############################################
# user adds gift card, it takes merchant, cardNumber and pin
##############################################
When /^the gift card with merchant "([^"]*)", card number "([^"]*)" and pin "([^"]*)" is added already$/ do |merchant, cardnumber, pin|
  NAV.goToWallet
  NAV.goToAddCard
  NAV.goToGiftCard
  GiftCardInfoFunctional.search_giftcard_merchant(merchant)
  GiftCardInfoFunctional.tap_giftcard_merchant_in_search_list
  GiftCardInfoFunctional.enter_giftcard_details(cardnumber, pin)
  GiftCardInfoFunctional.tap_add_giftcard
  GiftCardInitUI.verify_giftcard_category
end
##############################################
# user verifies online, instore,and pin on card details page
##############################################
Then /^user should see how to use instructions for online "([^"]*)", instore "([^"]*)" or both "([^"]*)"$/ do |online, instore, both|
  GiftcardDetailUI.verify_how_to_use(online, instore, both)
end
##############################################
# user taps on cancel button on the dialog
##############################################
Then /^user taps on Cancel button$/ do
  GiftCardEditFunctional.tap_cancel_button
end
##############################################
# user verifies gift card details page
##############################################
When /^user sees Gift Card Details Page$/ do
  GiftcardDetailUI.verify_giftcard_detail_page
end
##############################################
# user verifies for gift card details page
##############################################
When /^user sees edit gift card page$/ do
  GiftCardEditUI.verify_giftcard_editpage
end
##############################################
# user taps on no button on the dialog
##############################################
Then /^user taps on No button$/ do
  GiftCardEditFunctional.tap_no_button
end
##############################################
# user verifies different params on edit page
##############################################
When /^user sees the following on edit gift card page "([^"]*)", "([^"]*)","([^"]*)", "([^"]*)", "([^"]*)" "([^"]*)", "([^"]*)" and "([^"]*)"$/ do |merchant_name, customer_service, delete_button, done_button, cancel_button, merchant_logo, card_number,bar_code|
  GiftCardEditUI.verify_giftcard_editpage_with_params(merchant_name, customer_service, delete_button, done_button, cancel_button, merchant_logo, card_number,bar_code)
end
##############################################
# user presses Hardware back
##############################################
When /^user taps on back button$/ do
  sleep 0.3
  ANDROID.hardware_back
end
##############################################
# user verifies for gift card category on wallet page
##############################################
When /^user sees the wallet screen$/ do
  GiftCardInitUI.verify_giftcard_category
end
##############################################
# user verifies terms and conditions link
##############################################
When /^user sees Terms and Conditions link$/ do
  GiftcardDetailUI.verify_terms_conditions_link
end
##############################################
# user verifies terms and conditions on the details page
##############################################
When /^user sees Terms and Conditions$/ do
  GiftcardDetailUI.verify_terms_conditions
end

############################################################
# User taps on terms and conditions on gift card info page
#############################################################
Then(/^user taps on Terms and Conditions link on Details page$/) do
  GiftCardEditFunctional.taps_terms_conditions_on_details_page
end
##############################################
# user verifies error message on search page
##############################################
Then /^user gets an error message on gift card search list "([^"]*)"$/ do |message|
  GiftCardInitUI.verify_error_message_on_search(message)
end
##############################################
# user verifies error message on info page
##############################################
When /^user gets an error message on Gift card info page "([^"]*)"$/ do |message|
  GiftcardDetailUI.verify_error_message_info_page(message)
end
##############################################
# user enters pin on the gift card page
##############################################
When /^user enters gift card pin "([^"]*)"$/ do |pin|
  GiftCardInfoFunctional.enter_giftcard_pin(pin)
end
##############################################
# user verifies gift details page
##############################################
Then /^user should see details on gift card page with current balance "([^"]*)", balance ref "([^"]*)", last update time "([^"]*)" and manual"([^"]*)"$/ do |curr_bal_val, bal_ref_btn,lst_upt_time,manual|
  GiftcardDetailUI.verify_giftcard_detail_page_text(curr_bal_val, bal_ref_btn,lst_upt_time,manual)
end
##############################################
# user verifies no gift card added on the wallet
##############################################
When /^user does not see the gift card on the wallet$/ do
  GiftCardInitUI.verify_no_giftcard_category
end