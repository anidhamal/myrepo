Then(/^user verifies that he did not receive security code "([^"]*)"$/) do |number|
  PPUSER.assert_security_code_not_sent(number)
end

# user verifies 2fa screen
Then(/^user sees security code screen$/) do
  TwoFactorAuthFunctional.verify_2fa_screen
end

# user gets the sms number
And(/^user receives security code via text$/) do
  number = TwoFactorAuthFunctional.get_sms_number
  @code = PPUSER.verification_code(number)
end

# user enters the code in 2fa screen
Then(/^user enters security code$/) do
  TwoFactorAuthFunctional.enter_security_code(@code)
end

# user taps on sumbit button after enetring the code
Then(/^user taps on submit button$/) do
  TwoFactorAuthFunctional.tap_continue_button
end

# user enters the code in 2fa screen
Then(/^user enters invalid security code$/) do
  TwoFactorAuthFunctional.enter_security_code('000000')
end

# user verifies error message after entering wrong code
Then(/^user sees error message "([^"]*)"$/) do |error|
  TwoFactorAuthUI.verify_error_message(error)
end

# user verifies multiple phone number page
And(/^user sees multiple phone numbers$/) do
  TwoFactorAuthUI.verify_multiple_phone_page
end

# user taps in second phone number
Then(/^user selects the mobile number$/) do
  TwoFactorAuthFunctional.tap_second_number
end

# user taps on send text button in phone number list page
Then(/^user taps on Send SMS Message$/) do
  TwoFactorAuthFunctional.tap_send_text_button
end

And(/^user enter wrong security code (\d+) times$/) do |arg|
  (0..5).each do
    TwoFactorAuthFunctional.enter_security_code('000000')
    TwoFactorAuthFunctional.tap_continue_button
  end
end

# user verifies locked screen after entering the wrong code more than 6 times
Then(/^user sees security locked screen$/) do
  TwoFactorAuthFunctional.verify_locked_screen
end
