###
# Author
# Sarika Kamisetty
###

class ShopReadinessBannerFunctional

  ID_SET_UP_BUTTON = 'btnsetUpPhotoCard'
  ID_PHOTO_SET_UP_BUTTON = 'btnsetUpPhoto'
  ID_CARD_SET_UP_BUTTON = 'btnsetUpCard'
  CLASS_BANNER_VIEW = 'com.paypal.android.choreographer.views.BannerView'
  STRING_ADD_CARD_PHOTO_TITLE = "Pay with your phone at some of your favorite local places"
  STRING_ADD_CARD_PHOTO_BUTTON = "Get Set Up"
  TEXT_NO_BANNER_VIEW1 = 'PayPal. Now Accepted at a Store Near You.'
  TEXT_NO_BANNER_VIEW2 = 'Now Accepting PayPal'

  # verify the readiness banner in merchant listing banners view
  # As there are 3 different types of banner id's
  # using the class view to verify that readiness banner exists
  def self.verify_readiness_banner
    ANDROID.wait_till_element_visible(CLASS_BANNER_VIEW)
  end

  # Tap on readiness banner
  def self.tap_on_banner(banner_type)
    if banner_type == "Add Photo"
      tap_add_photo_button
    elsif banner_type == "Add Card"
      tap_add_card_button
    else
      tap_add_card_photo_button
    end
  end

  # Tap on add photo button on the readiness banner
  def self.tap_add_photo_button
    ANDROID.tap2("* id:'#{ID_PHOTO_SET_UP_BUTTON}'")
  end

  # Tap add card button in the readiness banner
  def self.tap_add_card_button
    ANDROID.tap2("* id:'#{ID_CARD_SET_UP_BUTTON}'")
  end

  # Tap add photo and card button in the readiness banner
  def self.tap_add_card_photo_button
    ANDROID.tap2("* id:'#{ID_SET_UP_BUTTON}'")
  end

  # Verify that shop readiness banner is not displayed
  def self.verify_no_banner
    ANDROID.check_text_exists(TEXT_NO_BANNER_VIEW1)
    ANDROID.check_text_exists(TEXT_NO_BANNER_VIEW2)
  end
end

class ShopReadinessLandingViewFunctional

  ID_LANDING_SET_UP_BUTTON = 'button_done'
  ID_SET_UP_CANCEL_BUTTON = 'cancel_button'
  ID_LANDING_VIEW_TITLE = 'top_message'
  ID_COMPLETE_TITLE = 'title'
  TEXT_TITLE2 = "Ordering for pickup or delivery"
  TEXT_TITLE1 = "Paying in stores"
  ID_ADD_GALLERY_PHOTO = 'addPGalleryButton'
  ID_SUCCESS_CHECK_MARK_IMAGE = 'green_checkmark'


  # verify the readiness landing view
  def self.verify_landing_view
    ANDROID.wait_till_id_visible(ID_LANDING_VIEW_TITLE)
    ANDROID.assert_id_visible(ID_LANDING_SET_UP_BUTTON)
    ANDROID.assert_id_visible(ID_SET_UP_CANCEL_BUTTON)
  end

  # Tap on set up button on readiness landing view
  # to add photo or add card
  def self.tap_setup_button
    ANDROID.tap2("* id:'#{ID_LANDING_SET_UP_BUTTON}'")
  end

  # Tap on DONE button on readiness landing view
  def self.tap_done_button
    ANDROID.tap2("* id:'#{ID_LANDING_SET_UP_BUTTON}'")
  end

  # verify landing view after card and photo added
    def self.verify_shopreadiness_success_view
    ANDROID.wait_till_id_visible(ID_SUCCESS_CHECK_MARK_IMAGE)
    ANDROID.assert_id_visible(ID_LANDING_SET_UP_BUTTON)
    ANDROID.assert_id_visible(ID_LANDING_VIEW_TITLE)
    ANDROID.assert_element_exist("* id:'#{ID_COMPLETE_TITLE}' * text:'#{TEXT_TITLE1}'")
    ANDROID.assert_element_exist("* id:'#{ID_COMPLETE_TITLE}' * text:'#{TEXT_TITLE2}'")
  end

  # Tap on cancel button to go back to merchant listing screen
  def self.tap_cancel_button
    ANDROID.tap2("* id:'#{ID_SET_UP_CANCEL_BUTTON}'")
  end
end