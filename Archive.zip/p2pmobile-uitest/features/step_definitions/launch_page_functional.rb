class Launch_Page_Functional

  ID_TERMS_CONDITIONS_MESSAGE = 'message'
  ID_AGREE_BUTTON = 'button1'
  ID_SIGNUP_BUTTON = 'sign_up_button'
  ID_LAUNCH_PAGE_TITLE = 'title'
  ID_LETS_GO_BUTTON = 'start'
  ID_LAUNCH_PAGE_CONTENT = 'message'
  ID_ACTION_OVERFLOW = 'footer'

  # user taps agree terms and conditions
  def self.taps_agree_terms_conditions
    ANDROID.wait_till_id_visible(ID_TERMS_CONDITIONS_MESSAGE)
    ANDROID.tap2("* id:'#{ID_AGREE_BUTTON}'")
  end

# user taps on signup button in launch page
  def self.taps_signup_button
    ANDROID.tap2("* id:'#{ID_SIGNUP_BUTTON}'")
  end

# user taps on lets go button in launch page
  def self.taps_letsgo_button
    ANDROID.tap2("* id:'#{ID_LETS_GO_BUTTON}'")
  end

# user verifies launch page
  def self.verify_launch_page
    ANDROID.wait_till_id_visible(ID_LAUNCH_PAGE_TITLE)
    ANDROID.check_an_element_exists("* id:'#{ID_LETS_GO_BUTTON}'")
    ANDROID.check_an_element_exists("* id:'#{ID_SIGNUP_BUTTON}'")
    ANDROID.check_an_element_exists("* id:'#{ID_LAUNCH_PAGE_CONTENT}'")
    ANDROID.check_an_element_exists("* id:'#{ID_LAUNCH_PAGE_TITLE}'")
  end

  # user veifies launch page title (ID)
  def self.verify_launchpage_title
    ANDROID.check_an_element_exists("* id:'#{ID_LAUNCH_PAGE_TITLE}'")
  end

  # user verifies lets go and sign up button in launch pages
  def self.verify_launch_page_buttons
    ANDROID.check_an_element_exists("* id:'#{ID_LETS_GO_BUTTON}'")
    ANDROID.check_an_element_exists("* id:'#{ID_SIGNUP_BUTTON}'")
  end

  # user verifies for 3 dots in launch Pages
  def self.verify_action_overflow
    ANDROID.check_an_element_exists("* id:'#{ID_ACTION_OVERFLOW}'")
  end

  # This method will go to the second page of launch page
  def self.go_to_Launch_2nd_Page
    ANDROID.swipe_right
  end

  # This method will go to the third page of launch page
  def self.go_to_Launch_3rd_Page
    ANDROID.swipe_right
    ANDROID.swipe_right
  end
end