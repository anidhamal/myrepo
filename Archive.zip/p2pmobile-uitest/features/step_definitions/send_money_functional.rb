###
# Author
# Steve Shenouda
# Indumathy kesavan
###

class SendMoneyInitFunctional

  ID_MAIN_RECIPIENT_EDITTEXT = 'recipient'
  ID_MAIN_AMOUNT_EDITTEXT = 'amount_edit'
  ID_MAIN_MESSAGE_EDITTEXT = 'payment_message_editable'
  ID_MAIN_REVIEW_BUTTON = 'review_button'
  ID_MAIN_RADIO_BUTTON_FRAME = 'payment_type_radio_frame'
  ID_MAIN_PERSONAL_RADIO_BUTTON = 'radio_button_personal'
  ID_MAIN_GOODS_RADIO_BUTTON = 'radio_button_goods'
  ID_REVIEW_PAYMENT_METHOD_SPINNER = 'payment_method_selector'
  ID_REVIEW_CHECKBOX = 'checkbox'
  ID_MAIN_CURRENCY_SPINNER = 'choose_currency'
  ID_MAIN_CURRENCY_LIST_ITEM = 'generic_list_item'
  ID_WALLET_BALANCE = 'paypal_balance'
  ID_REVIEW_SEND_MONEY_BUTTON = 'send_button'
  ID_SEND_MONEY_BUTTON = 'ctn_button'

  #Generic method to send money
  def self.send_money(recipient, amount, currency, type, message)
    ANDROID.wait_till_id_visible(ID_MAIN_RECIPIENT_EDITTEXT)
    #enter email address
    ANDROID.enter_text_by_id(recipient, ID_MAIN_RECIPIENT_EDITTEXT)
    #enter amount
    ANDROID.enter_text_by_id(amount, ID_MAIN_AMOUNT_EDITTEXT)
    #enter currency
    change_currency(currency)
    #enter message
    ANDROID.enter_text_by_id(message, ID_MAIN_MESSAGE_EDITTEXT)
    # select Transaction type
    select_payment_type(type)
    #taps on review button
    ANDROID.tap2("* id:'#{ID_MAIN_REVIEW_BUTTON}'")
  end

  #enter currency
  def self.change_currency(currency)
    if ANDROID.does_element_not_exist?("* text:'#{currency}'")
      ANDROID.tap2("* id:'#{ID_MAIN_CURRENCY_SPINNER}'")
      scroll_to(currency)
      ANDROID.tap2("* {text CONTAINS '#{currency}'}")
    end
  end

  #select Transaction type
  def self.select_payment_type(type)
    if type == 'Commercial'
      ANDROID.tap2("* id:'#{ID_MAIN_GOODS_RADIO_BUTTON}'")
    else
      ANDROID.tap2("* id:'#{ID_MAIN_PERSONAL_RADIO_BUTTON}'")
    end
  end


  def self.verify_payment_for_choice
    #looks for payment choices
    ANDROID.wait_till_id_visible(ID_MAIN_RADIO_BUTTON_FRAME)
    # clicks on friends and family
    ANDROID.check_id_exists(ID_MAIN_PERSONAL_RADIO_BUTTON)
    #clicks on goods and services
    ANDROID.check_id_exists(ID_MAIN_GOODS_RADIO_BUTTON)
  end

  #taps on payment method
  def self.change_funding_source(fund)

    ANDROID.tap2("* id:'#{ID_REVIEW_PAYMENT_METHOD_SPINNER}'")
    if fund.nil?
      ANDROID.tap2("* id:'#{ID_REVIEW_CHECKBOX}' parent LinearLayout sibling *")
    else
      ANDROID.tap2("* {text CONTAINS '#{fund}'}")
    end
  end

  def self.verify_review_button_disabled
    if ANDROID.check_roboto_button_enabled(ID_MAIN_REVIEW_BUTTON)
      raise 'Review button should be disabled.'
    end
  end

  def self.verify_funding_method(fund)
    sleep 1 # TODO: Find better way
    ANDROID.wait_till_id_visible(ID_REVIEW_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{fund}'}")
  end

  def self.scroll_to(text)
    ANDROID.wait_till_id_visible(ID_MAIN_CURRENCY_LIST_ITEM)
    # TODO : These while loops might hang if text doesn't exist.
    while ANDROID.does_element_not_exist?("* text:'USD – U.S. Dollar'")
      ANDROID.scroll_down
    end
    while ANDROID.does_element_not_exist?("* {text CONTAINS '#{text}'}")
      ANDROID.scroll_up
    end
  end

  def self.retrieve_balance
    NAV.goToWallet
    ANDROID.wail_till_text_invisible('Currently unavailable')
    ANDROID.wait_for_actionbar_progress
    balance = ANDROID.get_text_from_id(ID_WALLET_BALANCE).join
    balance.match(/[0-9|\.]+/)[0].to_i
  end

  def self.tap_sendmoney
    ANDROID.tap2("* id:'#{ID_SEND_MONEY_BUTTON}'")

  end
end

class SendMoneyReviewFunctional

  ID_REVIEW_SEND_MONEY_BUTTON = 'send_button'
  ID_REVIEW_SENDING_AMOUNT = 'sending_amount'
  ID_REVIEW_SENDING_FEES = 'sending_fees'
  ID_REVIEW_SENDING_TOTAL = 'sending_total'
  ID_REVIEW_PAYMENT_METHOD_SPINNER = 'payment_method_selector'
  ID_REVIEW_CHECKBOX = 'checkbox'
  ID_CARD = 'text'

  def self.verify_send_money_review_page(_recipient, amount, fees, total_amount)
    sleep 1 # TODO : Find better way
    ANDROID.wait_till_id_visible(ID_REVIEW_SEND_MONEY_BUTTON)
    # TODO: ANDROID.check_text_exists(recipient)
    ANDROID.check_an_element_exists("* id:'#{ID_REVIEW_SENDING_AMOUNT}' * {text CONTAINS '#{amount}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_REVIEW_SENDING_FEES}' * {text CONTAINS '#{fees}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_REVIEW_SENDING_TOTAL}' * {text CONTAINS '#{total_amount}'}")
  end

  def self.tap_send_money
    ANDROID.wait_till_id_visible(ID_REVIEW_SEND_MONEY_BUTTON)
    ANDROID.tap2("* id:'#{ID_REVIEW_SEND_MONEY_BUTTON}'")
  end

  def self.change_funding_type
    ppuser = PPUSER.getPPUserInfo
    card_last4 = 'x-' + ppuser['card_last4']
    ANDROID.tap2("* id:'#{ID_REVIEW_PAYMENT_METHOD_SPINNER}'")
    ANDROID.tap2("* id:'#{ID_CARD}' * {text CONTAINS '#{card_last4}'}")
  end
end

class SendMoneyFinalFunctional

  ID_GREEN_CHECKMARK = 'green_checkmark'
  ID_SUCCESS_MESSAGE = 'success_message'
  ID_DONE_BUTTON = 'done_button'

  def self.verify_successful_transfer
    ANDROID.wait_till_id_visible(ID_GREEN_CHECKMARK)
    ANDROID.check_id_exists(ID_SUCCESS_MESSAGE)
    ANDROID.tap2("* id:'#{ID_DONE_BUTTON}'")
  end
end

