# Author
# Steve Shenouda
# Indumathy Kesavan

#################################################################
## Review: verify funding type in review screen
#################################################################
Then(/^user sees that payment method as "(.*?)"$/) do |funding|
  RtrReviewFunctional.verify_payment_method(funding)
end

################################################################
# Initial screen: Fill up all the details
################################################################
Then(/^user sees the amount "(.*?)", fees "(.*?)" and total "(.*?)" on sender side, amount "(.*?)", fees "(.*?)" and total "(.*?)" on recipient side$/) do |sender_amount, sender_fees, sender_total, recipient_amount, _recipient_fees, recipient_total|
  if _recipient_fees == " "
    RtrReviewFunctional.verify_transaction_details_1(sender_amount, sender_fees, sender_total, recipient_amount, recipient_total)
  elsif sender_fees == " "
    RtrReviewFunctional.verify_transaction_details_2(sender_amount, sender_total, recipient_amount, _recipient_fees, recipient_total)
  end
end

################################################################
# User sends money successfully
################################################################
Then(/^user is able to send money RTR successfully$/) do
  RtrReviewFunctional.tap_send_money
  SendMoneyFinalFunctional.verify_successful_transfer
end

#############################################################################
# Unilateral screen: User is asked to enter country, first and last name
#############################################################################
Given(/^user enters Recipient country as "(.*?)", first name as "(.*?)", last name as "(.*?)"$/) do |country, fname, lname|
  RtrAdditionalInfoFunctional.enter_recipient_info(country, fname, lname)
end

#################################################################
## Activity: verify the transaction details
#################################################################
Then(/^user should see in activity view payment amount "(.*?)" as "(.*?)" for account "(.*?)"$/) do |amount, status, recipient|
  NAV.goToActivity
  RtrActivityFunctional.verify_activity_transaction_details(amount, status, recipient)
end

#############################################################################
# Review screen: Verify the conversion rate
#############################################################################
And(/^user sees conversion rate "([^"]*)"$/) do |rate|
  RtrReviewFunctional.verify_conversion_rate(rate)
end

#############################################################
# user taps on start up page
###########################################################
Then(/^user taps on my start page$/) do
  RtrActivityFunctional.taps_set_start_page
end

#############################################################
# user verifies additional information page
###########################################################
And(/^user sees the user additional information page$/) do
  RtrAdditionalInfoUI.verify_additional_info_page
end

#############################################################
# user verifies rtr review page
###########################################################
Then(/^user sees send money RTR review screen$/) do
  RtrSMReviewPageUI.verify_rtr_review_page
end

#############################################################
# user verifies successful transfer
###########################################################
Then(/^user sees send money success screen$/) do
  RtrFinalUI.verify_successful_transfer
end

#############################################################
# user verifies card number
###########################################################
Then(/^user sees that payment method as Card$/) do
  RtrReviewFunctional.verify_card_number
end

#############################################################
# user changes the funding type
###########################################################
And(/^user can change funding method from Bank to Card$/) do
  RtrReviewFunctional.change_funding_type
end

#############################################################
# user verifies no rtr page is displayed
###########################################################
Then(/^user should not see RTR page$/) do
  RtrSMReviewPageUI.verify_no_rtr_page
end