###
# Author
# Indumathy Kesavan
#
###
class RecentActivityFunctional
  ID_ACTIVITY_REFRESH = 'menu_history_refresh'
  ID_TRANSACTION = 'title'
  ID_ACTIVITY = 'button_activity'

  def self.refreshActivity
    ANDROID.tap(ID_ACTIVITY_REFRESH, 'id')
  end

  #user taps on recent transaction
  def self.tap_recent_transaction
    ANDROID.tap2("* id:'#{ID_TRANSACTION}'")
  end

  #user looks for recent transaction
  def self.transaction_recent_activity
    ANDROID.wait_till_id_visible(ID_ACTIVITY)
  end

  # user taps on transaction on name basics
  def self.tap_transaction_name(transaction)
    ANDROID.tap2("* text:'#{transaction}'")
  end

end

class ActivityDetailsFunctional

  ID_TRANSACTION = 'recent_history_row'
  ID_VIEW_ALL_ACTIVITY = 'viewAllActivities'
  ID_ERECEIPT_BUTTON = 'details_receipt_button'

  #user looks for transaction details
  def self.transaction_details
    ANDROID.wait_till_id_visible(ID_TRANSACTION)
  end

  #user taps on view all button
  def self.tap_view_all_button
    ANDROID.tap2("* id:'#{ID_VIEW_ALL_ACTIVITY}'")
  end

  # user verifies ereceipt does not display in details page
  def self.verify_no_ereceipt_button
    ANDROID.check_an_element_does_not_exist(ID_ERECEIPT_BUTTON)
  end

end

class SearchActivityFunctional

  ID_TRANSACTION = 'recent_history_row'
  ID_TRANSACTION_TITLE = 'title'
  ID_E_RECEIPT_BUTTON = 'details_receipt_button'

  #user taps on first transaction
  def self.taps_first_transaction
    ANDROID.tap2("* id:'#{ID_TRANSACTION}'")
  end

  #user taps on transaction e receipt
  def self.taps_transaction_ereceipt
    ANDROID.tap2("* id:'#{ID_TRANSACTION_TITLE}' index:3")
  end

  #user taps on e receipt
  def self.taps_ereceipt
    ANDROID.tap2("* id:'#{ID_E_RECEIPT_BUTTON}'")
  end

end

class ActivityTransactionDetails

  ID_ACTIVITY_DETAILS_TITLE = 'dcPPHistoryDetailsTitle'
  ID_ACTIVITY_DETAILS_DATE = 'dcPPHistoryDetailsDate'
  ID_ACTIVITY_DETAILS_STATUS = 'dcPPHistoryDetailsStatusValue'
  ID_ACTIVITY_DETAILS_AMOUNT = 'dcPPHistoryDetailsAmountValue'
  ID_ACTIVITY_DETAILS_TYPE = 'dcPPHistoryDetailsType'
  ID_ACTIVITY_DETAILS_TRANSACTION = 'dcPPHistoryDetailsTxn'

  def self.verify_transaction_details

    ANDROID.wait_till_id_visible(ID_ACTIVITY_DETAILS_TITLE)
    sleep 1 # TODO : Find better way
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_DATE}'")
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_STATUS}'")
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_AMOUNT}'")
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_TYPE}'")
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_TRANSACTION}'")
  end
end
