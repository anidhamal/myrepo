###
# Author
# Sarika Kamisetty
###

class ShopSearchUI

  STRING_PLACE_WITH_OFFERS = "Places with Offers"
  STRING_PAY_BY_PHONE = "Pay by Phone"
  STRING_SEARCH_BY_ORDER = "Order"
  STRING_SEARCH_FIND = "Find"
  STRING_SEARCH_NEAR = "Near"

  # Verify search view
  def self.verify_search_view
    ANDROID.wait_till_text_visible(STRING_SEARCH_FIND)
    ANDROID.check_text_exists(STRING_SEARCH_NEAR)
    verify_offers_text
    verify_order_text
    verify_pay_by_text
  end

  # Verify offers text in search view
  def self.verify_offers_text
    ANDROID.check_text_exists(STRING_PLACE_WITH_OFFERS)
  end

  # Verify order text in search view
  def self.verify_order_text
    ANDROID.check_text_exists(STRING_SEARCH_BY_ORDER)
  end

  # Verify pay by phone text in search view
  def self.verify_pay_by_text
    ANDROID.check_text_exists(STRING_PAY_BY_PHONE)
  end

end