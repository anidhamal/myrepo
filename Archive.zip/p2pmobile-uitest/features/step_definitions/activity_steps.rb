###
# Author
# Indumathy Kesavan
#
###
###############################################################
#user looks for recent transaction
###############################################################
Then(/^user sees transaction in recent activity$/) do
  RecentActivityFunctional.transaction_recent_activity
end

###############################################################
#user taps on recent transaction
################################################################
When(/^user taps on transaction$/) do
  RecentActivityFunctional.tap_recent_transaction
end

################################################################
#user looks for transaction details
##############################################################
Then(/^user sees transaction details$/) do
  ActivityTransactionDetails.verify_transaction_details
end

##############################################################
#user taps on view all button
###############################################################
When(/^user taps on View All button$/) do
  ActivityDetailsFunctional.tap_view_all_button
end

###############################################################
##user looks for transaction details
###############################################################
Then(/^user sees first transactions in Activity view$/) do
  ActivityDetailsFunctional.transaction_details
end

###############################################################
#user taps on first transaction
################################################################
When(/^user taps on first transaction$/) do
  SearchActivityFunctional.taps_first_transaction

end

###############################################################
#user can navigate pages
################################################################
Then(/^user can navigate pages$/) do
  ANDROID.swipe_right
end

###############################################################
#user taps on transaction e receipt
################################################################
Then(/^user taps on a POS transaction with eReceipt$/) do
  SearchActivityFunctional.taps_transaction_ereceipt

end

###############################################################
#user taps on e receipt
################################################################
Then(/^user taps on the Receipt icon on the bottom right of the transaction detail page$/) do
  SearchActivityFunctional.taps_ereceipt
end

###############################################################
##user looks for transaction details
###############################################################
Then(/^the eReceipt should display successfully$/) do
  ActivityDetailsFunctional.transaction_details
end

###############################################################
##user looks for transaction details
###############################################################
Then(/^user sees three transactions in Activity view$/) do
  ActivityDetailsFunctional.transaction_details
end

###############################################################
# user verifies for business name in activity page
###############################################################
Then(/^I should be able to see business name "([^"]*)"$/) do |name|
  RecentActivityUI.verify_business_name(name)
end

###############################################################
# user swipes left and right in activity details page
###############################################################
Then(/^user can swipe left and swipe right$/) do
  ANDROID.swipe_left
  ANDROID.swipe_right
end

###############################################################
# user verifies withdraw transaction in activity details page
###############################################################
And(/^user can verify the withdraw transaction amount "([^"]*)" and transaction type "([^"]*)"$/) do |amt, type|
  ActivityDetailsUI.verify_amount_type(amt, type)
end

###############################################################
# user verifies for phone number in activity page
###############################################################
And(/^user should see phone number in activity view "([^"]*)"$/) do |phone|
  RecentActivityUI.verify_phone_number(phone)
end

###############################################################
# user verifies email id in activity page
###############################################################
Then(/^I should be able to see email "([^"]*)"$/) do |email|
  RecentActivityUI.verify_email(email)
end

###############################################################
# user verifies ereceipt does not display in details page
###############################################################
Then(/^I validate Tranasction Details Page does not display eReceipt button$/) do
  ActivityDetailsFunctional.verify_no_ereceipt_button
end

###############################################################
# user verifies for currency in activity page
###############################################################
Then(/^I should be able to see currency "([^"]*)" in activity page$/) do |currencytype|
  RecentActivityUI.verify_currency_type(currencytype)
end

###############################################################
# user taps on transaction on name basics
###############################################################
And(/^user taps on transaction "([^"]*)"$/) do |transaction|
  RecentActivityFunctional.tap_transaction_name(transaction)
end
