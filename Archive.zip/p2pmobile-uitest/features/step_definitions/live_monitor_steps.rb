require_relative 'login_functional'


########################################
# Prod steps requiring real account info
########################################
def prod(data)
  if LIVE_DATA_MAP[data].nil?
    puts "Warning: Unmapped data: #{data}"
    return data
  else
    return LIVE_DATA_MAP[data]
  end
end

########################################
# User can login with the given details
########################################

Then /^user can login to prod with "([^"]*)", "([^"]*)"$/ do |id, secret|
  steps %Q{
    Then user can login with "#{prod(id)}", "#{prod(secret)}"
  }
end



Then(/^user select "(.*?)" Card and fill out the prod card form with number "(.*?)",  expiration date "(.*?)" and CSC number "(.*?)"$/) do |type,number, expiration, csc|
  steps %Q{
    Then user select "#{type}" Card and fill out the card form with number "#{prod(number)}",  expiration date "#{expiration}" and CSC number "#{csc}"
  }
end
