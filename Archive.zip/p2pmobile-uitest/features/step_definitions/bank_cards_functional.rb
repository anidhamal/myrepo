class Bank_Cards_Functional

  @@bank_accounts_section_id = "bank_accounts_section"
  @@bank_accounts_grid_view_id = "bank_accounts_grid_view"
  @@bank_accounts_section_title_id = "bank_accounts_section_title"
  @@payment_cards_section_id = "payment_cards_section"
  @@payment_cards_section_title_id = "payment_cards_section_title"
  @@payment_cards_grid_view_id = "payment_cards_grid_view"
  @@payment_card_logo = "payment_provider_network_logo"
  @@tap_bottom_text_id = "bottom_text"
  @@bank_account_type_id = "bank_type"
  @@status_label_id = "status_label"
  @@status_id = "status"
  @@card_type_id = "card_type"
  @@card_type_id = "card_type"
  @@card_billing_addr_title_id = "card_billing_addr_title"
  @@card_billing_addr_id = "bill_address"
  @@card_exp_date_title_id = "card_exp_date_title"
  @@card_exp_date_id = "exp_date"
  @@checking_account_text = "CHECKING"
  @@savings_account_text = "SAVINGS"
  @@remove_button_id = "remove_button"
  @@edit_button_id = "edit_button"
  @@expired_card_label = "expired_banner"
  @@remove_button_popup_id = "button index:1"

  def validate_banks_cards
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_visible(@@bank_accounts_section_id)
    ANDROID.assert_id_visible(@@bank_accounts_section_title_id)
    ANDROID.assert_id_visible(@@bank_accounts_grid_view_id)
    ANDROID.assert_id_visible(@@payment_cards_section_title_id)
    ANDROID.assert_id_visible(@@payment_cards_section_id)
    ANDROID.assert_id_visible(@@payment_cards_grid_view_id)
  end

  def validate_banks_invisible
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_invisible(@@bank_account_type_id, 'id', true)
    ANDROID.assert_id_invisible(@@status_label_id, 'id', true)
    ANDROID.assert_id_invisible(@@status_id, 'id', true)
    ANDROID.assert_id_invisible(@@expired_card_label, 'id', true)
    ANDROID.assert_id_invisible(@@card_type_id, 'id', true)
    ANDROID.assert_id_invisible(@@card_billing_addr_title_id, 'id', true)
    ANDROID.assert_id_invisible(@@card_billing_addr_id, 'id', true)
  end

  def verify_bank
    ppuser = PPUSER.getPPUserInfo
    ANDROID.wait_for_actionbar_progress
    # Number
    ANDROID.assert_text_visible("x-" + ppuser["bank_last4"])
    # Account Type
    ANDROID.assert_text_visible(ppuser["bank_account_type"].upcase)
    # Layout
    ANDROID.assert_id_visible(@@bank_accounts_section_id)
    ANDROID.assert_id_visible(@@bank_accounts_section_title_id)
    ANDROID.assert_id_visible(@@bank_accounts_grid_view_id)
  end

  def verify_bank_details
    ppuser = PPUSER.getPPUserInfo
    # Account Number
    ANDROID.assert_text_visible("x-" + ppuser["bank_last4"])
    # Account Type
    ANDROID.assert_id_visible(@@bank_account_type_id)
    ANDROID.assert_text_visible(ppuser["bank_account_type"].upcase)
    # Status
    ANDROID.assert_id_visible(@@status_label_id)
    ANDROID.assert_id_visible(@@status_id)
    ANDROID.assert_text_visible(ppuser["bank_account_status"])
  end

  def verify_card
    ANDROID.wait_for_actionbar_progress
    check_card_ui_details
    # Layout
    ANDROID.assert_id_visible(@@payment_cards_section_title_id)
    ANDROID.assert_id_visible(@@payment_cards_section_id)
    ANDROID.assert_id_visible(@@payment_cards_grid_view_id)
  end
  def verify_given_card(type,last4)
    ANDROID.wait_for_actionbar_progress
    check_given_card_ui_details(type,last4)
    # Layout
    ANDROID.assert_id_visible(@@payment_cards_section_title_id)
    ANDROID.assert_id_visible(@@payment_cards_section_id)
    ANDROID.assert_id_visible(@@payment_cards_grid_view_id)
  end
  def verify_card_absent
    ppuser = PPUSER.getPPUserInfo
    ANDROID.wait_for_actionbar_progress
    # Number
    ANDROID.assert_text_invisible("x-" + ppuser["card_last4"])
    # Card Type
    if ppuser["card_type"].capitalize == "Amex"
      card_type = "American Express"
    elsif ANDROID.check_text("Other")
      card_type = "Other"
      # This check is for a Maestro or Other Card
    else
      card_type = ppuser["card_type"].capitalize
    end
    ANDROID.assert_text_invisible(card_type)
  end

  def verify_given_card_absent(last4)
    ANDROID.wait_for_actionbar_progress
    # Number
    ANDROID.assert_text_invisible("x-" + last4)
  end
  def verify_expired_card
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_visible(@@payment_card_logo)
    ANDROID.assert_id_visible(@@expired_card_label)
    ANDROID.assert_id_visible(@@payment_cards_section_title_id)
    ANDROID.assert_id_visible(@@payment_cards_section_id)
    ANDROID.assert_id_visible(@@payment_cards_grid_view_id)
  end

  def verify_card_details
    check_card_ui_details
    # Card Billing Address
    ANDROID.assert_id_visible(@@card_billing_addr_title_id)
    ANDROID.assert_id_visible(@@card_billing_addr_id)

    # Card Expiration Date
    ANDROID.assert_id_visible(@@card_exp_date_title_id)
    ANDROID.assert_id_visible(@@card_exp_date_id)
  end
  def verify_given_card_details(type,last4)
    check_given_card_ui_details(type,last4)
    # Card Billing Address
    ANDROID.assert_id_visible(@@card_billing_addr_title_id)
    ANDROID.assert_id_visible(@@card_billing_addr_id)

    # Card Expiration Date
    ANDROID.assert_id_visible(@@card_exp_date_title_id)
    ANDROID.assert_id_visible(@@card_exp_date_id)
  end
  def check_card_ui_details
    ppuser = PPUSER.getPPUserInfo
    # Card Number
    ANDROID.assert_text_visible("x-" + ppuser["card_last4"])
    # Card type
    if ppuser["card_type"].capitalize == "Amex"
      card_type = "American Express"
    elsif ANDROID.check_text("Other")
      card_type = "Other"
      # This check is for a Maestro or Other Card
    else
      card_type = ppuser["card_type"].capitalize
    end
    ANDROID.assert_text_visible(card_type)
  end
  ##Directly checks the provided card details
  def check_given_card_ui_details(type,last4)
    # Card Number
    ANDROID.assert_text_visible("x-" + last4)
    # Card type
    type=type.capitalize
    if type == "Amex"
      type = "American Express"
    end
    ANDROID.assert_text_visible(type)
  end

  def verify_expired_card_details
    ANDROID.assert_id_visible(@@expired_card_label)
    ANDROID.assert_id_visible(@@bank_account_type_id)
    ANDROID.assert_id_visible(@@card_billing_addr_title_id)
    ANDROID.assert_id_visible(@@card_billing_addr_id)
    ANDROID.assert_id_visible(@@card_exp_date_title_id)
    ANDROID.assert_id_visible(@@card_exp_date_id)
  end

  def tap_bank
    ANDROID.tap(@@tap_bottom_text_id, 'id')
  end

  def tap_card
    ANDROID.tap(@@tap_bottom_text_id, 'id')
  end
  def tap_given_card(last4)
    ANDROID.tap("x-" + last4, 'text')
  end
  def verify_bank_confirmed(status)
    ANDROID.assert_text_visible(status)
  end

  def tap_on_remove_button
    ANDROID.tap(@@remove_button_id, 'id')
  end

  def tap_on_remove_popup
    ANDROID.tap(@@remove_button_popup_id, 'element')
  end

  def tap_on_edit
    ANDROID.tap(@@edit_button_id, 'id')
  end

  def verify_bank_absent
    ppuser = PPUSER.getPPUserInfo
    ANDROID.wait_for_actionbar_progress
    # Number
    ANDROID.assert_text_invisible("x-" + ppuser["bank_last4"])
    ANDROID.assert_text_invisible(ppuser["bank_account_type"].upcase)
  end

end