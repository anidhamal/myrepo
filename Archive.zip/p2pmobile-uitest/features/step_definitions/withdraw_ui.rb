class WithdrawInitUI

  ID_WITHDRAW_MONEY_PAGE = 'wallet_tabs'
  TEXT_AVAILABLE_BALANCE = 'Available Balance'
  TEXT_RECEIVER = 'FROM'
  TEXT_TO = 'TO'
  TEXT_AMOUNT = 'Amount:'

  def self.verify_withdraw_money_page
    ANDROID.wait_till_id_visible(ID_WITHDRAW_MONEY_PAGE)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_AVAILABLE_BALANCE}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_RECEIVER}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_TO}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_AMOUNT}'}")
  end
end

class WithdrawSuccessfulPage

  ID_COMPLETION_STATUS = 'completion_status'
  TEXT_WITHDRAWN_SUCCESSFUL = 'Money Withdrawn'
  TEXT_DONE_BUTTON = 'Done'

  def self.verify_withdraw_successful_page
    ANDROID.wait_till_id_visible(ID_COMPLETION_STATUS)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_WITHDRAWN_SUCCESSFUL}'}")
    ANDROID.tap2("* text:'#{TEXT_DONE_BUTTON}'")
  end
end
