###
# Author
# Sarika Kamisetty
###

# Tap on merchant from search results
When /^user taps on merchant "(.*?)" from search results$/ do |merchant|
  ShopSearchFunctional.tap_on_merchant(merchant)
end

# Verify merchant details
Then(/^user sees merchant details view for merchant "(.*?)"$/) do |merchant|
  ShopSearchFunctional.verify_merchant_details(merchant)
end

# User searches with merchant name
Given(/^user searches for "(.*?)"$/) do |merchant|
  ShopSearchFunctional.tap_on_search_button
  ShopSearchFunctional.verify_search_view
  ShopSearchFunctional.search_merchant(merchant)
  step 'I press the enter button'
end

# User searches for merchant by address
Given(/^user searches for merchant by address "(.*?)" in "(.*?)" search bar$/) do |address, option|
  ShopSearchFunctional.tap_on_search_button
  ShopSearchFunctional.verify_search_view
  ShopSearchFunctional.search_merchant(address, option)
  step 'I press the enter button'
end

# User verifies address in the merchant details screen
Then /^user sees merchant details view for merchant with address "(.*?)"$/ do |address|
  ShopSearchFunctional.verify_address(address)
end

# Tap on search button in merchant listing
When(/^user taps on search button in merchant listing$/) do
  ShopSearchFunctional.tap_on_search_button
end

# User selects either offers/pay by phone/order filter in the search view
When(/^user selects "(.*?)" filter$/) do |search_filter|
  ShopSearchFunctional.select_search_filter(search_filter)
  step 'I press the enter button'
end

# verify the search list view displayed merchant with offers
Then /^user sees the merchant list with offers$/ do
  ShopSearchFunctional.verify_list_with_offers
end