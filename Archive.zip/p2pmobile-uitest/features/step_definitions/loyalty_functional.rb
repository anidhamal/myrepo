###
# Author
# Steve Shenouda
#
###

ID_TYPE_IN_NUMBER_BUTTON = 'type_number_btn'
ID_LOYALTY_CARD_VALUE_EDITTEXT = 'loyalty_card_value'
ID_ADD_CARD_BUTTON = 'action_add'
ID_WALLET_LOYALTY_CARD = 'item_background'
ID_LOYALTY_MERCHANT_NAME = 'loyalty_merchant_name'
ID_LOYALTY_MERCHANT_LOGO = 'loyalty_merchant_logo'
PARTIAL_ID_LOYALTY_MERCHANT = 'loyalty_merchant'
ID_SEARCH = 'search_src_text'
ID_DETAILS_TERMS_LINK = 'terms_text'
ID_TERMS_WEB_PROGRESS_BAR = 'webProgressBar'
ID_TERMS_WEB_VIEW = 'terms_frame'
ID_DETAILS_EDIT_BUTTON = 'edit_button'
ID_REMOVE_BUTTON = 'remove_card_button'
ID_WALLET_PAGE_BALANCE_LAYOUT = 'available_balance_layout'
ID_EDIT_PAGE_DONE_BUTTON = 'done_button'
ID_EDIT_PAGE_SCAN_BARCODE_BUTTON = 'scan'
ID_EDIT_PAGE_AUTO_REDEEM_DESCRIPTION = 'auto_redeem_message'
ID_PAYMENT_PREFS_CARDS_GALLERY = 'ppPPrefsCardsGallery'
ID_LOYALTY_MERCHANT_CHECK_MARK = 'check_mark'
ID_LOYALTY_MERCHANT_DISABLED_OVERLAY = 'disabled_overlay'
STRING_NO_PAYMENT_PREFERENCE_MESSAGE = 'Boost your purchasing power. Go to your wallet to link a debit or credit card and use it as your preferred payment method.'

class LoyaltyFunctional
  def self.wait_for_merchant_list
    ANDROID.wait_till_id_visible(ID_LOYALTY_MERCHANT_NAME)
  end

  def self.search_for_merchant(merchant)
    ANDROID.clear_input_field_with_id(ID_SEARCH)
    ANDROID.enter_text_by_id(merchant, ID_SEARCH) unless merchant.nil?
  end

  def self.dismiss_barcode
    sleep 4 # TODO: Think of a better way
    if ANDROID.does_element_exist?("* id:'#{ID_TYPE_IN_NUMBER_BUTTON}'")
      ANDROID.tap2("* id:'#{ID_TYPE_IN_NUMBER_BUTTON}'")
    end
  end

  def self.enter_loyalty_card_number(loyalty_card_number)
    card = loyalty_card_number
    ANDROID.clear_input_field_with_id(ID_LOYALTY_CARD_VALUE_EDITTEXT)
    if !card.nil?
      ANDROID.enter_text_by_id(card.to_s, ID_LOYALTY_CARD_VALUE_EDITTEXT)
    else
      card = (Time.now.to_i).to_s
      ANDROID.enter_text_by_id(card, ID_LOYALTY_CARD_VALUE_EDITTEXT)
    end
    card
  end

  def self.add_card_with_length(length)
    len = length.to_i
    card = rand(10**len).to_s.rjust(len, '0')
    enter_loyalty_card_number(card)
  end

  def self.edit_card(merchant)
    verify_loyalty_edit_card_page(merchant, nil)
    enter_loyalty_card_number(nil)
    ANDROID.tap2("* id:'#{ID_EDIT_PAGE_DONE_BUTTON}'")
    ANDROID.wait_till_element_visible("*id:'#{ID_WALLET_PAGE_BALANCE_LAYOUT}'")
  end

  def self.remove_card(merchant)
    verify_loyalty_edit_card_page(merchant, nil)
    ANDROID.tap2("* id:'#{ID_REMOVE_BUTTON}'")
    ANDROID.tap2("* text:'Yes'")
  end

  def self.tap_merchant_in_list_view
    ANDROID.wait_till_element_visible("* {id CONTAINS '#{PARTIAL_ID_LOYALTY_MERCHANT}'}")
    if ANDROID.does_element_exist?("* id:'#{ID_LOYALTY_MERCHANT_NAME}'")
      merchant = ANDROID.get_text_from_id(ID_LOYALTY_MERCHANT_NAME)
    else
      merchant = ANDROID.get_content_description(ID_LOYALTY_MERCHANT_LOGO)
    end
    ANDROID.tap2("* {id CONTAINS '#{PARTIAL_ID_LOYALTY_MERCHANT}'}")
    merchant[0]
  end

  def self.tap_add_loyalty_card_button
    ANDROID.tap(ID_ADD_CARD_BUTTON, 'id')
  end

  def self.tap_merchant_on_wallet_page(merchant)
    verify_card_on_wallet_page(merchant)
    ANDROID.tap2("* marked:'#{merchant}'")
  end

  def self.tap_on_terms_link
    ANDROID.tap2("* id:'#{ID_DETAILS_TERMS_LINK}'")
  end

  def self.tap_edit_card_button
    ANDROID.tap2("* id:'#{ID_DETAILS_EDIT_BUTTON}'")
  end

  def self.verify_add_card_view(_merchant)
    # check_marked_element_exists - Doesn't work because keyboard hides merchant
    ANDROID.assert_id_visible(ID_LOYALTY_CARD_VALUE_EDITTEXT)
  end

  def self.verify_card_on_wallet_page(merchant)
    ANDROID.wait_till_id_visible(ID_WALLET_LOYALTY_CARD)
    ANDROID.check_marked_element_exists(merchant)
  end

  def self.verify_no_loyalty
    ANDROID.assert_text_invisible('Loyalty')
  end

  def self.verify_no_barcode
    ANDROID.assert_id_invisible(ID_TYPE_IN_NUMBER_BUTTON, 'id', true)
  end

  def self.verify_add_card_disabled
    if ANDROID.check_roboto_button_enabled(ID_ADD_CARD_BUTTON)
      fail 'Add Card Button should be disabled'
    end
  end

  def self.verify_merchant_disabled
    ANDROID.check_id_exists(ID_LOYALTY_MERCHANT_CHECK_MARK)
    ANDROID.check_id_exists(ID_LOYALTY_MERCHANT_DISABLED_OVERLAY)
  end

  def self.verify_merchant_in_list_view(merchant)
    ANDROID.wait_till_id_visible(ID_SEARCH)
    ANDROID.check_an_element_exists("RelativeLayout id:'frame' * marked:'#{merchant}'")
  end

  def self.verify_loyalty_card_details_page(merchant, card)
    sleep 1
    ANDROID.check_marked_element_exists(merchant)
    ANDROID.check_text_exists(card)
  end

  def self.verify_terms_load
    ANDROID.wait_till_element_visible("* id:'#{ID_TERMS_WEB_VIEW}'")
    ANDROID.wait_till_element_invisible("* id:'#{ID_TERMS_WEB_PROGRESS_BAR}'")
  end

  def self.verify_card_deleted(merchant)
    ANDROID.wait_till_element_visible("*id:'#{ID_WALLET_PAGE_BALANCE_LAYOUT}'")
    ANDROID.check_marked_element_does_not_exist(merchant)
  end

  def self.verify_loyalty_edit_card_page(merchant, _card)
    ANDROID.wait_till_id_visible(ID_REMOVE_BUTTON)
    ANDROID.check_marked_element_exists(merchant)
    ANDROID.check_id_exists(ID_EDIT_PAGE_AUTO_REDEEM_DESCRIPTION)
    # ANDROID.check_text_exists(card) - because edit card option is gone
    # ANDROID.check_id_exists(ID_EDIT_PAGE_SCAN_BARCODE_BUTTON)
  end

  def self.verify_loyalty_card_not_in_payment_prefs(_merchant)
    ANDROID.wait_till_element_visible("*id:'#{ID_PAYMENT_PREFS_CARDS_GALLERY}'")
    ANDROID.check_text_exists(STRING_NO_PAYMENT_PREFERENCE_MESSAGE)
  end
end
