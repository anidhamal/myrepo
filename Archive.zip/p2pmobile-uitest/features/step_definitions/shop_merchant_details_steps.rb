Given(/^"(.*?)" user is on the shop screen$/) do |_arg1|
  step 'user is on the shop screen'
end

Then(/^user should see Merchant Logo, "(.*?)", Merchant Address$/) do |name|
  ShopMerchantDetailsFunctional.verify_merchant_details(name)
end

Then(/^user should see "(.*?)"$/) do |text|
  ShopMerchantDetailsFunctional.verify_slide_text(text)
end

Then(/^user should see "(.*?)" and "(.*?)" tabs$/) do |tab1, tab2|
  ShopMerchantDetailsFunctional.verify_payment_types_exist(tab1, tab2)
end

Then(/^user should be able to tap on "(.*?)"$/) do |type|
  ShopMerchantDetailsFunctional.tap_payment_type(type)
end

Then(/^user taps on merchant info to view more Information$/) do
  ShopMerchantDetailsFunctional.tap_merchant_info
end

Then(/^Verify Contact Information: Map, Directions, Address, and Phone Number are visible$/) do
  ShopMerchantDetailsFunctional.verify_contact_info
end

Then(/^user should see text "(.*?)"$/) do |text|
  ShopMerchantDetailsFunctional.verify_mobile_phone_and_pin(text)
end
