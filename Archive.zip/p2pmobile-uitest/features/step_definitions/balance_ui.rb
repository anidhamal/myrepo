class Balance_UI

  ############################################################################################################
  @@paypal_balance_id = "paypal_balance"
  @@available_balance_id = "available_balance"
  @@refresh_menu_id = "menu_refresh"
  @@addto_button_id = "add_money_button"
  @@withdraw_button_id =  "withdraw_money_button"
  @@scancheck_button_id = "scan_check_button"
  @@balancedetailstxt_id = "pending_balance_disclosure"
  @@currency_title_id = "currency_section_title"
  @@available_currency_id = "currency_name"
  @@pending_currency_id = "currency_name2"
  @@amount_currency_id = "currency_amount"
  @@amount2_currency_id = "currency_amount2"
  @@view_all_activty = "viewAllActivities"
  @@activity_id = "history_tabs"

  ###########################################################################################################
  # Method Name: balance details page
  # Parameters :
  # Description: Method to view balance details on Balance details page
  #############################################################################################################

  def verifyBalanceDetails(available_arr, pending_arr)
    available = available_arr.split(/(?<!\d),/)
    pending = pending_arr.split(/(?<!\d),/)

    available.each do|value|
      if value[0].match("-")
        # Not able to verify - sign on the screen
        ANDROID.assert_text_visible(value[2..-5])
      else
        # Not able to verify currency symbol from Wallet page
        ANDROID.assert_text_visible(value[1..-5])
      end
    end

    pending.each do|value|
      ANDROID.assert_text_visible(value[1..-5])
    end

  end

###########################################################################################################
# Method Name: Balance in wallet page
# Parameters :
# Description: Method to verify balance in wallet page
#############################################################################################################

  def verifyWalletBalanceCurrency(currency)
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_text_visible(currency)
  end

###########################################################################################################
# Method Name: Balance in Activity page
# Parameters :
# Description: Method to verify balance in wallet page
#############################################################################################################

  def verifyActivityBalanceCurrency(currency)
    ANDROID.wait_till_id_visible(@@activity_id)
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_text_visible(currency)
  end

###########################################################################################################
# Method Name: Balance in Activity page
# Parameters :
# Description: Method to verify balance in wallet page
#############################################################################################################

  def verifyBalance(balance_arr)
    balance = balance_arr.split(/\s/)

    balance.each do|value|
      value.match(/[A-Za-z]/)? ANDROID.assert_text_visible(value) : ANDROID.assert_text_visible(value[1..-1])
    end
  end

  ###########################################################################################################
  # Method Name: Currency Details on Wallet page
  # Parameters : Array of available and pending balances with different currencies
  # Description: Method to verify currency details on wallet page
  #############################################################################################################

  def verifyWalletCurrencyDetails(available_arr)
    available = available_arr.split(/(?<!\d),/)

    available.each do|value|
      case value[-3,3]
        when "USD"
          ANDROID.assert_text_visible("U.S. Dollar")
        when "EUR"
          ANDROID.assert_text_visible("Euro")
        when "JPY"
          ANDROID.assert_text_visible("Japanese Yen")
        when "GBP"
          ANDROID.assert_text_visible("British Pound")
        when "CAD"
          ANDROID.assert_text_visible("Canadian Dollar")
        else
          raise "Error: I could not find currency #{value[-3,3]}"
      end
    end

  end

end

