class RtrAdditionalInfoUI

  ID_INFO_ADDITIONAL = 'secondary_fragment_title'
  TEXT_ADDITIONAL_INFO = 'Recipient Info'
  TEXT_COUNTRY = 'United States'

  def self.verify_additional_info_page
    ANDROID.wait_till_id_visible(ID_INFO_ADDITIONAL)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_ADDITIONAL_INFO}'}")
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_COUNTRY}'}")
  end
end

class RtrSMReviewPageUI

  ID_SEND_MONEY_BUTTON = 'ctn_button'
  TEXT_PAYMENT_METHOD = 'Payment method'
  TEXT_BALANCE_EUR = 'Balance (EUR)'
  TEXT_BALANCE_USD = 'Balance (USD)'
  TEXT_AMOUNT = 'Amount'
  TEXT_TOTAL = 'Total'
  TEXT_FEES = 'Fees'
  TEXT_RECEIVER_RECEIVES = 'Recipient Receives'
  ID_REVIEW_SEND_MONEY_BUTTON = 'send_button'
  ID_SENDER_SECTION = 'section1'
  ID_RECEIVER_SECTION = 'section3'

  # user verify the RTR review page
  def self.verify_rtr_review_page
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_PAYMENT_METHOD}'}")
    if  ANDROID.does_element_not_exist?("* text:'#{TEXT_BALANCE_USD}'")
      ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_BALANCE_EUR}'}")
    else
      ANDROID.check_an_element_exists("* {text CONTAINS '#{TEXT_BALANCE_USD}'}")
    end
    # user verifies for sender or receiver fees, amount, total text
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_SECTION}' * {text CONTAINS '#{TEXT_AMOUNT}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_SECTION}' *  {text CONTAINS '#{TEXT_TOTAL}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_RECEIVER_SECTION}'* {text CONTAINS '#{TEXT_AMOUNT}'}")
    if ANDROID.does_element_not_exist?("* id:'#{ID_RECEIVER_SECTION}' * {text CONTAINS '#{TEXT_FEES}'}")
      ANDROID.check_an_element_exists("* id:'#{ID_SENDER_SECTION}' * {text CONTAINS '#{TEXT_FEES}'}")
    else
      ANDROID.check_an_element_exists("* id:'#{ID_RECEIVER_SECTION}' * {text CONTAINS '#{TEXT_FEES}'}")
    end
    ANDROID.check_an_element_exists("* id:'#{ID_RECEIVER_SECTION}' * {text CONTAINS '#{TEXT_TOTAL}'}")
  end

  # user makes sure there is no rtr page
  def self.verify_no_rtr_page
    ANDROID.wait_till_id_visible(ID_REVIEW_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_does_not_exist("* {text CONTAINS '#{TEXT_RECEIVER_RECEIVES}'}")
    ANDROID.check_an_element_does_not_exist("* id:'#{ID_RECEIVER_SECTION}'* {text CONTAINS '#{TEXT_AMOUNT}'}")
    ANDROID.check_an_element_does_not_exist("* id:'#{ID_RECEIVER_SECTION}' * {text CONTAINS '#{TEXT_FEES}'}")
    ANDROID.check_an_element_does_not_exist("* id:'#{ID_RECEIVER_SECTION}' * {text CONTAINS '#{TEXT_TOTAL}'}")
  end
end

class RtrFinalUI

  ID_GREEN_CHECKMARK = 'green_checkmark'
  TEXT_DONE_BUTTON = 'Done'

  # user checks for successful money transfer
  def self.verify_successful_transfer
    ANDROID.wait_till_id_visible(ID_GREEN_CHECKMARK)
    ANDROID.tap2("* text:'#{TEXT_DONE_BUTTON}'")
  end
end