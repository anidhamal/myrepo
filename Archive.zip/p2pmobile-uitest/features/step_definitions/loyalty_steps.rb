###
# Author
# Steve Shenouda
#
###

##################################################################
# Go to Loyalty list view from wallet view
##################################################################
When(/^user goes to loyalty list view$/) do
  NAV.go_to_loyalty_cards
end

##################################################################
# Taps always on first merchant in the loyalty list view
##################################################################
When(/^user taps on first merchant in loyalty list view$/) do
  LoyaltyFunctional.wait_for_merchant_list
  @merchant = LoyaltyFunctional.tap_merchant_in_list_view
end

##################################################################
# Go to Loyalty add card view from list view
##################################################################
Then(/^user goes to loyalty add card view$/) do
  LoyaltyFunctional.dismiss_barcode
  LoyaltyFunctional.verify_add_card_view(nil)
end

##################################################################
# Taps on add card button and adds the card successfully$
##################################################################
Then(/^user adds the loyalty card successfully$/) do
  @card = LoyaltyFunctional.enter_loyalty_card_number(nil)
  LoyaltyFunctional.tap_add_loyalty_card_button
  LoyaltyFunctional.verify_card_on_wallet_page(@merchant)
end

##################################################################
# Should not see loyalty card option in action sheet for
# non supported countries
##################################################################
Then(/^user should not see loyalty card option for "(.*?)"$/) do |_|
  LoyaltyFunctional.verify_no_loyalty
end

When(/^user taps on add button on Wallet page$/) do
  NAV.goToAddCard
end

When(/^user taps on merchant "(.*?)"$/) do |merchant|
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant(merchant)
  @merchant = LoyaltyFunctional.tap_merchant_in_list_view
end

Then(/^user dismisses the barcode screen$/) do
  LoyaltyFunctional.dismiss_barcode
end

Then(/^user sees the loyalty add card view for merchant "(.*?)"$/) do |merchant|
  LoyaltyFunctional.verify_add_card_view(merchant)
end

When(/^user enters loyalty reward number$/) do
  @card = LoyaltyFunctional.enter_loyalty_card_number(nil)
end

When(/^user taps on loyalty add card button$/) do
  LoyaltyFunctional.tap_add_loyalty_card_button
end

Then(/^user should see the loyalty card added in wallet view$/) do
  LoyaltyFunctional.verify_card_on_wallet_page(@merchant)
end

Then(/^user should not see barcode view$/) do
  LoyaltyFunctional.verify_no_barcode
end

Given(/^user searches for merchant "(.*?)"$/) do |merchant|
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant(merchant)
end

When(/^user taps on the merchant from the results table view$/) do
  @merchant = LoyaltyFunctional.tap_merchant_in_list_view
end

Then(/^user goes to loyalty add card view of the first merchant$/) do
  NAV.go_to_loyalty_cards
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant(nil)
  @merchant = LoyaltyFunctional.tap_merchant_in_list_view
  LoyaltyFunctional.dismiss_barcode
  LoyaltyFunctional.verify_add_card_view(nil)
end

When(/^user does not enter any card number$/) do
  # Do nothing
end

Then(/^user sees that the loyalty add card button is disabled$/) do
  LoyaltyFunctional.verify_add_card_disabled
end

When(/^user tries to add loyalty card with card length of "(.*?)" digits$/) do |length|
  LoyaltyFunctional.add_card_with_length(length)
end

Then(/^user adds loyalty card for merchant "(.*?)"$/) do |merchant|
  NAV.go_to_loyalty_cards
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant(merchant)
  @merchant = LoyaltyFunctional.tap_merchant_in_list_view
  LoyaltyFunctional.dismiss_barcode
  LoyaltyFunctional.verify_add_card_view(merchant)
  @card = LoyaltyFunctional.enter_loyalty_card_number(nil)
  LoyaltyFunctional.tap_add_loyalty_card_button
  LoyaltyFunctional.verify_card_on_wallet_page(@merchant)
end

Then(/^user should see the loyalty card for merchant "(.*?)" as greyed out$/) do |merchant|
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant(merchant)
  LoyaltyFunctional.verify_merchant_disabled
end

Then(/^user can see Barcode merchant "(.*?)", Non Barcode "(.*?)" and Seamless merchants "(.*?)" in the list view$/) do |merchant1, merchant2, merchant3|
  NAV.go_to_loyalty_cards
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant(merchant1)
  LoyaltyFunctional.verify_merchant_in_list_view(merchant1)
  LoyaltyFunctional.search_for_merchant(merchant2)
  LoyaltyFunctional.verify_merchant_in_list_view(merchant2)
  LoyaltyFunctional.search_for_merchant(merchant3)
  LoyaltyFunctional.verify_merchant_in_list_view(merchant3)
end

Then(/^user should be able to scroll "(.*?)" the loyalty list view$/) do |direction|
  if (direction == 'up')
    ANDROID.scroll_up
  else
    ANDROID.scroll_down
  end
end

When(/^user search for a loyalty card which is not in the list$/) do
  LoyaltyFunctional.wait_for_merchant_list
  LoyaltyFunctional.search_for_merchant('Non existant merchant')
end

Then(/^user should see a message "(.*?)"$/) do |message|
  ANDROID.assert_text_visible(message)
end

Then(/^user sees the loyalty card added to wallet view$/) do
  LoyaltyFunctional.verify_card_on_wallet_page(@merchant)
end

When(/^user taps on loyalty card in wallet view$/) do
  LoyaltyFunctional.tap_merchant_on_wallet_page(@merchant)
end

Then(/^user should see the loyalty card details$/) do
  LoyaltyFunctional.verify_loyalty_card_details_page(@merchant, @card)
end

Then(/^user sees card number, terms and how to use options for merchant "(.*?)" with card type "(.*?)"$/) do |merchant, _|
  LoyaltyFunctional.verify_loyalty_card_details_page(merchant, @card)
end

When(/^user taps on Terms in cards details view$/) do
  LoyaltyFunctional.tap_on_terms_link
end

Then(/^user sees the terms and condition for merchant "(.*?)"$/) do |_|
  LoyaltyFunctional.verify_terms_load
end

Given(/^user goes to edit view$/) do
  LoyaltyFunctional.tap_merchant_on_wallet_page(@merchant)
  LoyaltyFunctional.tap_edit_card_button
end

Then(/^user should be able to remove the card "(.*?)" with card type "(.*?)"$/) do |_merchant, _|
  LoyaltyFunctional.remove_card(@merchant)
  LoyaltyFunctional.verify_card_deleted(@merchant)
end

When(/^user deletes the card for merchant "(.*?)"$/) do |_merchant|
  LoyaltyFunctional.remove_card(@merchant)
end

Then(/^user verifies card "(.*?)" removed from wallet view$/) do |merchant|
  LoyaltyFunctional.verify_card_deleted(merchant)
end

Then(/^user should be able to edit loyalty card number for Non Barcode merchant "(.*?)"$/) do |merchant|
  LoyaltyFunctional.edit_card(merchant)
end

Then(/^user sees merchant name "(.*?)", card Number, barcode, description$/) do |merchant|
  LoyaltyFunctional.verify_loyalty_edit_card_page(merchant, @card)
end

When(/^user goes to payment preferences$/) do
  NAV.goToSettings
  NAV.goToPaymentPref
end

Then(/^user should not see loyalty card$/) do
  LoyaltyFunctional.verify_loyalty_card_not_in_payment_prefs(@merchant)
end

When(/^user taps back button on add loyalty card view$/) do
  ANDROID.tap2("* id:'home'")
end

Then(/^user should see the loyalty search results view for merchant "(.*?)"$/) do |merchant|
  LoyaltyFunctional.verify_merchant_in_list_view(merchant)
end
