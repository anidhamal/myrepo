class Scan_Check_Functional

  @@scan_check_button_id = "scan_check_button"
  @@accept_button_id= "tou_accept_button"
  @@scan_check_title_id = "wallet_tabs"
  @@amount_frame_id = "amount_frame"
  @@add_funds_message_id = "add_funds_message"
  @@add_funds_button_id = "add_funds_button"
  @@completion_status_id = "completion_status"
  @@content_id = "content"
  @@success_summary_id = "success_summary"
  @@success_details_id = "success_details"
  @@done_button_id = "done_button"

  ############################################################################################################
  # Method Name: goToScanCheckPage
  # Parameters :
  # Description: This method will tap on scan check button and go to scancheck page
  #############################################################################################################

   #def tapAcceptBtn
   #
   #  #ANDROID.wait_till_id_visible(@@accept_button_id)
   #  ANDROID.wait_till_button_visible(@@accept_button_id)
   #
   #  ANDROID.assert_id_visible(@@accept_button_id)
   #  ANDROID.tap(@@accept_button_id, "id")
   #
   #end

  ############################################################################################################
  # Method Name: verifyScanCheckPage
  # Parameters :
  # Description: This method will verify fir elements in scan check page
  #############################################################################################################

   def verifyScanCheckPage

      ANDROID.wait_for_progressbar
      ANDROID.assert_id_visible(@@scan_check_title_id)
      ANDROID.assert_id_visible(@@accept_button_id)

   end


end
