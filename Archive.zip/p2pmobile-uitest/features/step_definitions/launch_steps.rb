require_relative 'login_functional'

login_functional = Login_functional.new
Given /^I launch the app for the first time$/ do

  def wait_for_id(id)
    time=240
    puts "wait for:#{id}"
    for i in 1 .. 240
      x = element_exists("* id:'#{id}'")
      #puts "Checking for button #{id} got : #{x}"
      if x==true
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 0.25
      end
    end
  end

  def wait_for_progress_disappear
    id="progress"
    time=30
    #puts "wait for:#{id}"
    for i in 1 .. time
      x = element_exists("* id:'#{id}'")
      #puts "Checking for button #{id} got : #{x}"
      if x==false
        sleep 1
        break
      else
        #puts "No app yet will retry : #{i}"
        sleep 1
      end
    end
  end
  if ENV['SETUP'] != "FALSE"


  if $initialSetup == FALSE
    #Wait for the app to come up for the first time
    #Accept terms
    wait_for_id("button1")
    tap("button1")

    #First time use
    tap('shop_bottom_button')
    puts "Tapped 1st"
    tap('shop_bottom_button')
    puts "Tapped 2nd"
    tap('shop_bottom_button')
    puts "Tapped 3rd"

    #Banner overlay on the shop screen
    wait_for_id('banner_overlay_section')
    tap('banner_overlay_section')

    #Goto slide out menu
    wait_for_id('home')
    tap('home')

    #Tap on login and set stage
    wait_for_id('button_help')
    ANDROID.long_tap("button_help", "id")

    #scroll up - in some devices there needs to be a scroll
    ANDROID.scroll_to_top(2)

    wait_for_id('text')
    tap('text')
    tap('Stage')

    #Choose the stage drop down list and select Other
    wait_for_id('stage_server_spinner')
    tap('stage_server_spinner')

    ANDROID.scroll_to_bottom(2)
    tap('other')

    ANDROID.scroll_to_top(2)
    #Enter stage here -
    ANDROID.enter_text($test_server, 1)
    ANDROID.hardware_back

    #Login first time
    tap('button_help')
    login_functional.logInWithPhone("4083331231", "5647")

    #Wait for the progress bar to disappear
    wait_for_progress_disappear
    wait_for_id('home')
    tap('home')

    #navigate to settings and set the remember me to OFF
    wait_for_id('button_settings')
    tap('button_settings')
    wait_for_id('security_settings')
    tap('security_settings')


    #check if the checkbox is checked
    check = query("android.widget.CheckBox", :checked)

    if check[0] == true
      tap('remember_me_checkbox')
    end

    #Go back to the slide out menu
    tap('home')
    tap('home')

    #Now log out of the app - app set for automation
    wait_for_id('button_logout')
    tap('button_logout')

    wait_for_id('button1')
    tap('button1')

    $initialSetup = TRUE
  end
end

#end of Given /^I launch the app for the first time$/ do
end


Given /^I launch the app with location "([^"]*)" "([^"]*)"$/ do |lat, lng|
 

 # step "I launch the app for the first time"

 #  set_gps_coordinates(lat,lng)
 
end


When(/^I launch the app with launch pages$/) do
  _STAGE="--esn stage -e endpoint #{STAGE}"
  system "adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity #{_STAGE} --ez AcceptedLicense false"
  sleep 5
  start_test_server_in_background
end
