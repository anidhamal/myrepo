require_relative 'login_functional'

login_functional = Login_functional.new

########################################
# User goes to login screen
########################################
Given /^the user is on the login screen$/ do
  NAV.goToLogin
end

########################################
# User can login with the given details
########################################

Then /^user can login with "([^"]*)", "([^"]*)"$/ do |id, secret|
  NAV.goToLogin
  login_functional.switch_user
  login_functional.login(id, secret)
  login_functional.tapLogin(id)
  login_functional.verifyLoginSuccess
end

Given /^user can login with "([^"]*)", "([^"]*)", "([^"]*)"$/ do |country_code, id, secret|
  NAV.goToLogin
  login_functional.switch_user
  login_functional.loginWithCountryCode(country_code, id, secret)
  login_functional.tapLogin(id)
  login_functional.verifyLoginSuccess
end

########################################
# User sees the light weight login
########################################
Given /^user sees light weight login with "([^"]*)" "([^"]*)"$/ do |id,secret|
  NAV.goToLogin
  login_functional.switch_user
  login_functional.login(id,secret)
  login_functional.tapLogin(id)
  login_functional.verifyLoginSuccess
  login_functional.logOut
  login_functional.goToLWLI
end

########################################
# User enters the secret on LWL
########################################
When /^user enters secret "([^"]*)"$/ do |pwd|
  login_functional.enterPwdOnLWLI(pwd)
end

########################################
# User can login successfully
########################################
Then /^user can login successfully$/ do
  login_functional.verifyLoginSuccess
end

########################################
# User can switch user and logs in
# with another user
########################################
Then /^user is able to switch user to be able to login with a different user$/ do
  login_functional.switch_user
  login_functional.login("kvelumani-us-pre11@paypal.com", "11111111")
  login_functional.tapLogin("kvelumani-us-pre11@paypal.com")
  login_functional.verifyLoginSuccess
end

########################################
# User tries to login with invalid
# secret
########################################
Given(/^user tries to login with "(.*?)" "(.*?)"$/) do |id, secret|
  NAV.goToLogin
  login_functional.switch_user
  login_functional.login(id, secret)
  login_functional.tapLogin(id)
end

########################################
#  User sees the error message
########################################
Then(/^user gets an error message$/) do
  login_functional.verifyErrorMsg
  login_functional.tapOkBtn
end

########################################
#  User goes to the wallet page
########################################
Then(/^user goes to Wallet page$/) do
  NAV.goToWallet
end

########################################
#  User logs out
########################################
Then(/^user logs out after Remember Me$/) do
  login_functional.logoutFromSubmenu
end

########################################
#  User turns on remember me
########################################
Then(/^user turns on Remember Me$/) do
  NAV.goToSettings
  NAV.goToSecuritySettings
  login_functional.turnRememberMeOn
end

########################################
#  User goes to LWL
########################################
Then(/^user goes to light weight login$/) do
  login_functional.goToLWLI
end

########################################
#  Time out the user's session
########################################
Given(/^user has a session timeout with credentials "(.*?)", "(.*?)"$/) do |id, secret|
  sleep 3
  if id == ""
    ppuser = PPUSER.getPPUserInfo
    PPUSER.session_timeout(ppuser["email"],secret)
  else
    PPUSER.session_timeout(id,secret)
  end
  sleep 3
end

########################################
#  User taps on the add to button
# on the wallet page
########################################
Given(/^user taps on Add To button on Wallet page$/) do
  login_functional.tapAddToBtn
end

########################################
#  User goes back to wallet and
# verifies the session timeout
########################################
Then(/^user goes back to Wallet and verifies Login Success$/) do
  NAV.goToWallet
  Bank_Cards_Functional.new.validate_banks_cards
end

########################################
#  User taps on the withdraw button
# on the wallet page
########################################
Given(/^user taps on WithDraw button on Wallet page$/) do
  login_functional.tapWithdrawBtn
end

########################################
#  User goes to activity page
########################################
Given(/^user goes to Activity page$/) do
  NAV.goToActivity
end

########################################
#  User taps on the view all activity
########################################
Then(/^user taps on View All in Activity$/) do
  login_functional.viewAllActivity
end

########################################
#  User goes back to activity and
# verifies session timeout
########################################
Then(/^user goes back to Activity and verifies Login Success$/) do
  NAV.goToActivity
  Balance_UI.new.verifyActivityBalanceCurrency("USD")
end

########################################
#  User changes the credential set
########################################
Given(/^user changes credential set for Light Weight Login$/) do
  login_functional.tapLWLICaret
end

########################################
#  User enters pin after changing
# credential set
########################################
When (/^user enters pin "(.*?)" after changing credential set$/) do |secret|
  login_functional.logInWithPhonePin(secret)
  login_functional.tapLoginButton
end

########################################
#  User enters password after changing
# credential set
########################################
When (/^user enters password "(.*?)" after changing credential set$/) do |password|
  login_functional.logInWithEmailPassword(password)
  login_functional.tapLoginButton
end

########################################
#  User refreshes the wallet page
########################################
And /^user refreshes Wallet Page$/ do
  NAV.goToWallet
  login_functional.refreshWallet
end

########################################
#  User logs out
########################################
Then /^user logs out$/ do
  login_functional.logOut
end

########################################
#  Change Locale to the given value
########################################
Given /^the locale is set to "([^"]*)"$/ do |locale|
  $locale = locale
  if IQA
    ANDROID.change_device_locale(locale)
  else
    ANDROID.change_locale(locale)
  end
end

########################################
#  The login button should be disabled
########################################
Then /^the login button is hidden$/ do
  login_functional.verifyDisabledLogin
end

########################################
#  User taps on forgot password
########################################
Then /^the user taps on Forgot Password$/ do
  login_functional.tapForgotPassword
end

########################################
#  User should see security settings
########################################
Then /^user should see Security Setting$/ do
  NAV.goToSettings
  login_functional.checkSecuritySetting(true)
end

########################################
#  User should not see security settings
########################################
Then /^user should not see Remember Me option in Security Setting$/ do
  NAV.goToSettings
  login_functional.checkSecuritySetting(false)
end

########################################
#  User should be on the login screen
########################################
And /^user should be on the login screen$/ do
  login_functional.verifyLoginScreen
end

########################################
#  User should be on the Shop screen
########################################
And /^user should see the shop screen on launch$/ do
  login_functional.verifyShopScreen
end

And /^user's Access Token is killed$/ do
  PPUSER.kill_access_token_android
end

Then /^user gets an toast message "([^"]*)"$/ do |msg|
  login_functional.verifyToastMsg(msg)
end

########################################
#  User should be on the login screen
########################################
Then /^user should not see phone pin option for "([^"]*)"$/ do |locale|
  login_functional.verify_no_phone_pin
end

########################################
#  verify login view
########################################
Given /^user sees the login screen$/ do
  NAV.goToLogin
  login_functional.switch_user
  LoginUI.verify_login_view
end

Then /^user sees "([^"]*)" is pre-populated in the login screen$/ do |phone|
  login_functional.goToLWLI
  LoginUI.verify_phone_num(phone)
end

When /^user switches account$/ do
  login_functional.tap_on_login_options
  LoginOptionsUI.verify_switch_user
  LoginOptionsUI.verify_login_options_ui
  login_functional.tap_on_switch_user
  LoginUI.verify_login_view
end

Then /^user should see Login window with empty credentials$/ do
  login_functional.verify_login_after_switch_account
end

And /^previous users data is deleted from the app$/ do
  login_functional.verify_login_after_switch_account
end

######################################################
# user logs in after logging out
#######################################################
Then(/^user logs in again with "([^"]*)", "([^"]*)"$/) do |id, secret|
  login_functional.login_after_logout(secret)
end
####################################################################
# 2fa user logs in
#####################################################################
Then(/^2FA user can login with "([^"]*)", "([^"]*)"$/) do |id, secret|
  NAV.goToLogin
  login_functional.switch_user
  login_functional.login(id, secret)
  login_functional.tapLogin(id)
end