class GiftCardInitFunctional

# taps on gift card merchant
  def self.tap_giftcard_mercant
    ANDROID.tap2("* id:'#{'gift_card_merchant_name'}'index:1")
  end

# verifies added gift card in wallet page
  def self.verify_added_giftcard
    ANDROID.wait_for_progressbar
    ANDROID.wait_till_id_visible('item_background')
  end

  # user verifies the gift card options in Action sheet
  def self.verify_giftcard
    ANDROID.check_an_element_exists("* {text CONTAINS '#{'Gift Card'}'}")
  end

  # user verifies no gift card in Action sheet
  def self.verify_no_giftcard
    ANDROID.check_an_element_does_not_exist("* id:'#{ID_GIFT_CARD}'")
  end

# user navigates back to merchant page
  def self.merchant_search_page
    ANDROID.wait_till_id_visible('search_src_text')
  end

# user taps on added gift card
  def self.tap_wallet_giftcard
    ANDROID.tap2("* id:'#{'item_background'}'")
  end
end

class GiftCardInfoFunctional

  def self.enter_giftcard_details(cardnumber, pin)
    enter_giftcard_number(cardnumber)
    enter_giftcard_pin(pin)
  end

  def self.enter_giftcard_pin(pin)
    ANDROID.wait_till_id_visible('wallet_tabs')
    # user enters gift card pin
    ANDROID.tap2("* id:'#{'gift_card_pin_number'}'")
    ANDROID.clear_text(2)
    ANDROID.enter_text(pin, 2)
  end

  def self.enter_giftcard_number(cardNumber)
    ANDROID.wait_till_id_visible('wallet_tabs')
    #user enters gift card number
    ANDROID.tap2("* id:'#{'gift_card_card_number'}'")
    ANDROID.clear_text(1)
    ANDROID.enter_text(cardNumber, 1)
  end

# user taps on add gift card button
  def self.tap_add_giftcard
    ANDROID.wait_till_id_visible('action_add')
    ANDROID.tap2("* id:'#{'action_add'}'")
  end

# user taps on "where I can find the information"
  def self.tap_info_finder
    ANDROID.tap2("* id:'#{'gift_card_info_message'}'")
  end

  #user closes "where I can find the information" page by tapping anywhere
  def self.tap_anywhere_back_image
    #ANDROID.tap2("* id:'#{'back_image'}'")
    ANDROID.tap2("* id:'#{'gift_card_info_message'}'")
  end

# user taps on "terms and condition"
  def self.taps_terms_conditions
    ANDROID.tap2("* id:'#{'gift_card_terms_and_conditions'}'")
  end

# user enters the merchant name in search box
  def self.search_giftcard_merchant(merchant)
    ANDROID.wait_till_id_visible('search_src_text')
    ANDROID.clear_input_field_with_id(ID_SEARCH)
    ANDROID.enter_text_by_id(merchant, ID_SEARCH) unless merchant.nil?
  end

# user taps on merchant name after the search
  def self.tap_giftcard_merchant_in_search_list
    ANDROID.wait_till_element_visible("* {id CONTAINS '#{'gift_card_merchant_logo'}'}")
    ANDROID.tap2("* {id CONTAINS '#{'gift_card_merchant_logo'}'}")
  end

# user taps on home page logo
  def self.tap_back
    ANDROID.tap2("* {id CONTAINS '#{'home'}'}")
  end

# user taps on cancel when add balance message pops up
  def self.tap_cancel_message
    ANDROID.wait_till_id_visible('message')
    ANDROID.tap2("* {id CONTAINS '#{'button2'}'}")
  end

# user taps on cancel link add balance message pops up
  def self.tap_link_message
    ANDROID.wait_till_id_visible('message')
    ANDROID.tap2("* {id CONTAINS '#{'button1'}'}")
  end
end

class GiftCardEditFunctional

  #user tap on remove card button
  def self.tap_removecard_button
    ANDROID.tap2("* {id CONTAINS '#{'remove_card_button'}'}")
  end

  #user tap on remove card button
  def self.tap_cancel_button
    ANDROID.tap2("* {id CONTAINS '#{'cancel_button'}'}")
  end

  # user taps on yes in remove card confirmation pop up
  def self.tap_yes_removecard
    ANDROID.tap2("* {id CONTAINS '#{'button1'}'}")
  end

  # user enters manually the balance in gift card edit page
  def self.enter_giftcard_balance(balance)
    ANDROID.wait_till_id_visible('gift_card_manual_balance')
    ANDROID.tap2("* {id CONTAINS '#{'gift_card_manual_balance'}'}")
    ANDROID.enter_text_by_id(balance, 'gift_card_manual_balance')
    ANDROID.tap2("* {id CONTAINS '#{'done_button'}'}")
  end

  #user taps on No button on the dialog
  def self.tap_no_button
    ANDROID.tap2("* {id CONTAINS '#{'button2'}'}")
  end

  # user taps on terms and conditions
  def self.taps_terms_conditions_on_details_page
    ANDROID.tap2("* id:'#{'gift_card_terms'}'")
  end
end
