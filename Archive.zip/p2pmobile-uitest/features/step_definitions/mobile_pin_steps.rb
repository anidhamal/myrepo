require_relative 'mobile_pin_functional'
require_relative 'login_functional'

mobile_pin_functional = Mobile_Pin_functional.new
login_functional = Login_functional.new

######################################################################
## Scenario 1: User can create pin
######################################################################
Then /^user can create pin and login successfully$/ do
  NAV.goToPin
  mobile_pin_functional.createPin("4085673345", "5647")
  mobile_pin_functional.logOutFromCreatePin
  NAV.goToLogin
  login_functional.logInWithPhone("4085673345", "5647")
  login_functional.verifyLoginSuccess
end

######################################################################
## Scenario 2: User can change pin
######################################################################
Then /^user can change pin and login successfully$/ do
  NAV.goToPin
  mobile_pin_functional.changePin("5689")
  mobile_pin_functional.logOutFromCreatePin
  NAV.goToLogin
  login_functional.logInWithPhone("5107674222", "5689")
  login_functional.verifyLoginSuccess
end