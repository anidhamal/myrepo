class Launch_Page_UI

  ID_LAUNCH_PAGE_TITLE = 'title'
  ID_SIGNUP_BUTTON = 'sign_up_button'
  ID_LETS_GO_BUTTON = 'start'
  ID_LAUNCH_PAGE_CONTENT = 'message'
  ID_ACTION_OVERFLOW = 'footer'

  # user verifies launch page title (text)
  def self.verify_launch_page_title(title)
    ANDROID.check_an_element_exists("* id:'#{ID_LAUNCH_PAGE_TITLE }' * text:'#{title}'")
  end

  # user verifies launch page content (text)
  def self.verify_launch_page_content(content)
    ANDROID.check_an_element_exists("* id:'#{ID_LAUNCH_PAGE_CONTENT}' * text:'#{content}'")
  end
end

class Create_Account_UI

  ID_CREATE_ACCOUNT_HEADER = 'registration_tabs'
  TEXT_CREATE_ACCOUNT_HEADER = 'Login Information'
  ID_COUNTRY = 'text'
  TEXT_COUNTRY = 'United States'
  ID_EMAIL_ADDRESS_FIELD = 'email_field'
  ID_PASSWORD_FIELD = 'password_field'
  ID_PASSWORD_CONFIRM_FIELD = 'confirm_password_field'

  # user verifies create account page
  def self.verify_create_account_page
    ANDROID.wait_till_id_visible(ID_CREATE_ACCOUNT_HEADER)
    ANDROID.check_an_element_exists("* id:'#{ID_CREATE_ACCOUNT_HEADER}' * {text CONTAINS '#{TEXT_CREATE_ACCOUNT_HEADER}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_COUNTRY}' * {text CONTAINS '#{TEXT_COUNTRY}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_EMAIL_ADDRESS_FIELD}'")
    ANDROID.check_an_element_exists("* id:'#{ID_PASSWORD_FIELD}'")
    ANDROID.check_an_element_exists("* id:'#{ID_PASSWORD_CONFIRM_FIELD}'")
  end
end