# Author
# Steve Shenouda
class OfacFunctional
  ID_CLOCK_ICON = 'clock_icon'
  ID_OFAC_MESSAGE = 'ofac_message'
  ID_DONE_BUTTON = 'done_button'
  STRING_OFAC_PENDING_MESSAGE = 'The payment you sent is currently being reviewed and we will complete this process within 72 hours.'

  def self.verify_ofac_screen
    ANDROID.wait_till_id_visible(ID_DONE_BUTTON)
    ANDROID.check_id_exists(ID_CLOCK_ICON)
    ANDROID.check_id_exists(ID_OFAC_MESSAGE)
    ANDROID.check_text_exists(STRING_OFAC_PENDING_MESSAGE)
  end
end
