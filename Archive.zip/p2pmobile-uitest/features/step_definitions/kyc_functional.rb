# Author
# Steve Shenouda
class KycFunctional
  ID_DECLINED_TRIANGLE_IMAGE = 'declined_triangle_image'
  ID_SENDING_LIMIT_MESSAGE = 'ofac_message'
  ID_VISIT_WEBSITE_BUTTON = 'visit_website_button'
  ID_CONFIRMATION_MESSAGE = 'message'
  STRING_CONFIRMATION_MESSAGE = 'requesting payment for goods and services. By tapping Confirm, you declare that you are requesting payment for goods and services.'
  ID_CONFIRM_BUTTON = 'button1'

  def self.verify_sending_limit_message(message)
    ANDROID.wait_till_id_visible(ID_DECLINED_TRIANGLE_IMAGE)
    ANDROID.check_id_exists(ID_SENDING_LIMIT_MESSAGE)
    ANDROID.check_id_exists(ID_VISIT_WEBSITE_BUTTON)
    ANDROID.check_an_element_exists("* id:'#{ID_SENDING_LIMIT_MESSAGE}' * {text CONTAINS '#{message}'}")
  end

  def self.verify_confirmation_message
    ANDROID.wait_till_id_visible(ID_CONFIRMATION_MESSAGE)
    ANDROID.check_an_element_exists("* id:'#{ID_CONFIRMATION_MESSAGE}' * {text CONTAINS '#{STRING_CONFIRMATION_MESSAGE}'}")
    ANDROID.tap2("* id:'#{ID_CONFIRM_BUTTON}'")
  end
end
