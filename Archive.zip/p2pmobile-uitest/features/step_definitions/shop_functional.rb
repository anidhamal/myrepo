# Author
# Steve Shenouda
class ShopFunctional
  ID_BANNER = 'banner_edu_view'
  ID_MERCHANT_LIST = 'merchant_list'
  ID_MERCHANT_BUTTON = 'checkin_merchant_button'
  ID_MERCHANT_LOGO = 'checkin_merchant_logo'
  ID_MERCHANT_NAME = 'checkin_merchant_name'
  ID_MERCHANT_ADDRESS = 'checkin_merchant_address'
  ID_SLIDER_VIEW = 'AngledSliderView'
  ID_STORE_NAME = 'text_merchant_name'
  ID_STORE_ADDRESS = 'text_merchant_address_line1'
  ID_STORE_PHONE = 'text_merchant_phone'
  ID_STORE_LOGO = 'checkin_merchant_logo'
  ID_SEARCH_BUTTON = 'menu_search'
  ID_SEARCH_QUERY = 'search_src_text_find'
  ID_MAP_CONTAINER = 'googleLocationContainer'
  ID_DIRECTION_CONTAINER = 'googleDirectionContainer'
  ID_STREET_VIEW = 'streetview_default'
  ID_SEARCH_MERCHANT_ADDRESS = 'checkin_merchant_address_row1'
  ID_SEARCH_MERCHANT_LOGO = 'checkin_merchant_logo_list'
  ID_PAYCODE_IMAGE = 'codeImage'
  ID_PAYCODE_TEXT = 'paymentCodeText'

  def self.verify_on_shop_page
    ANDROID.wait_till_id_visible(ID_BANNER)
  end

  def self.verify_merchant_list
    ANDROID.check_id_exists(ID_MERCHANT_LIST)
  end

  def self.tap_merchant_in_list_view
    ANDROID.tap2("* id:'#{ID_MERCHANT_BUTTON}'")
  end

  def self.verify_merchant_details
    ANDROID.wait_till_id_visible(ID_MERCHANT_LOGO)
    ANDROID.check_id_exists(ID_MERCHANT_NAME)
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS)
    ANDROID.check_id_exists(ID_SLIDER_VIEW)
  end

  def self.tap_merchant_on_details_page
    ANDROID.tap2("* id:'#{ID_MERCHANT_NAME}'")
  end

  def self.verify_store_details
    ANDROID.wait_till_id_visible(ID_STORE_NAME)
    ANDROID.check_id_exists(ID_STORE_ADDRESS)
    # TODO: ANDROID.check_id_exists(ID_STORE_PHONE)
    ANDROID.check_id_exists(ID_STORE_LOGO)
    ANDROID.check_id_exists(ID_MAP_CONTAINER)
    ANDROID.check_id_exists(ID_DIRECTION_CONTAINER)
    ANDROID.check_id_exists(ID_STREET_VIEW)
  end

  def self.search_merchant(merchant)
    ANDROID.tap2("* id:'#{ID_SEARCH_BUTTON}'")
    ANDROID.enter_text_by_id(merchant, ID_SEARCH_QUERY)
  end

  def self.swipe_slider(direction)
    ANDROID.wait_till_id_visible(ID_SLIDER_VIEW)

    if direction
      ANDROID.drag_xy_to_xy(32.5, 67.5, 81, 81, 20)
    else
      ANDROID.drag_xy_to_xy(67.5, 32.5, 81, 81, 20)
    end
  end

  def self.verify_search_result(name, address)
    ANDROID.wait_till_id_visible(ID_SEARCH_MERCHANT_LOGO)
    ANDROID.check_element_exists("* id:'#{ID_MERCHANT_NAME}' * text:'#{name}'")
    ANDROID.check_element_exists("* id:'#{ID_SEARCH_MERCHANT_ADDRESS}' * text:'#{address}'")
  end

  def self.verify_pay_code
    ANDROID.wait_till_id_visible(ID_PAYCODE_IMAGE)
    ANDROID.check_id_exists(ID_PAYCODE_TEXT)
  end
end
