###
# Author
# Sarika Kamisetty
###

class Add_Photo_Functional

  @@addPGalleryButton_id = "addPGalleryButton"
  @@addPTakePhotoButton_id = "addPTakePhotoButton"
  @@addPDoneButton_id = "addPDoneButton"
  @@addPYesNoLayout_id = "addPYesNoLayout"
  @@profile_picture_id = "photoEditView"
  @@addPhotoCancelButton = 'addPhotoCancelButton'
  @@progress_id = 'progress'


  def self.add_photo
    # Tap on add photo button
    ANDROID.tap2("* id:'#{@@addPGalleryButton_id}'")
    # add photo from gallery either from shop or settings view
    file_path = File.dirname(File.expand_path(__FILE__)) + '/gallery-select-first-album.py'
    system "monkeyrunner #{file_path}"
    system "monkeyrunner #{file_path}"
    # tap on done button on add photo screen after selecting picture from gallery
    ANDROID.tap2("* id:'#{@@addPDoneButton_id}'")
    # add photo takes around 30 sec
    # wait until progress bar is invisible
    ANDROID.wait_till_id_invisible(@@progress_id)
    end

  #Check the content of the MyPhoto initial page
  def self.verifyAddPhoto
    ANDROID.assert_id_visible(@@addPGalleryButton_id)
    ANDROID.assert_id_visible(@@addPTakePhotoButton_id)
    ANDROID.assert_id_visible(@@profile_picture_id)
  end

  # when adding picture in stage, an error message pops up, user taps on ok button in error message pop up
  def self.tap_ok_error_popup
    ANDROID.wait_till_id_invisible('buttonPanel')
    ANDROID.tap2("* id:'#{'buttonPanel'}'")
  end
end