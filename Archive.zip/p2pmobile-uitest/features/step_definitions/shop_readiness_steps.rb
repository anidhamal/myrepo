###
# Author
# Sarika Kamisetty
###

add_card_functional = AddCard_Functional.new

# verify banner in featured banner list
Given(/^user sees the Readiness banner in featured banners list$/) do
  NAV.goToShopPage
  ShopReadinessBannerFunctional.verify_readiness_banner
end

# Tap on readiness banner
When(/^user taps on the "([^"]*)" banner$/) do |banner_type|
  ShopReadinessBannerFunctional.tap_on_banner(banner_type)
end

# Add credit card from the readiness banner
When(/^user adds credit card with the 'Add card' flow$/) do
  add_card_functional.enterCardDetails("Visa", "11/2018", "123")
  add_card_functional.tapAddCard
end

# Tap on "Add a Photo" button after adding card
And /^user taps on 'Add a Photo' button$/ do
  ShopReadinessLandingViewFunctional.tap_setup_button
end

# Add photo from the readiness banner
When(/^user adds photo with the 'Add photo' page from readiness banner$/) do
  Add_Photo_Functional.add_photo
  Add_Photo_Functional.tap_ok_error_popup
  ShopReadinessLandingViewFunctional.verify_shopreadiness_success_view
  ShopReadinessLandingViewFunctional.tap_done_button
end

# Functional - Verify landing view of add card and photo
Then(/^user taken to a landing screen of "([^"]*)"$/) do |banner_type|
  ShopReadinessLandingViewFunctional.verify_landing_view
end

Then /^user taps on Set Up button on the landing view$/ do
  ShopReadinessLandingViewFunctional.tap_setup_button
end

# Verify user sees no banner in featured banners list
Then /^user should no longer see the banner in featured banners list$/ do
  ShopReadinessBannerFunctional.verify_no_banner
end

# Tap on Done button in the readiness view
And /^user taps on Done button in the readiness view$/ do
  ShopReadinessLandingViewFunctional.verify_shopreadiness_success_view
  ShopReadinessLandingViewFunctional.tap_done_button
end

# user deletes card successfully
And(/^user deletes the card successfully$/) do
  add_card_functional.delete_added_creditcard
end

# user verifies LWL
Then(/^LWL should be displayed$/) do
  LoginUI.verify_LWL
end

# user navigates to shop page verifies the shop readiness banner
Then(/^user sees the "([^"]*)" banner in the featured banners list$/) do |arg|
  NAV.goToShopPage
  ShopReadinessBannerFunctional.verify_readiness_banner
end

# user verifies the add photo flow page
Then(/^user should go back to the Get Set Up Page$/) do
  ShopReadinessLandingViewUI.verify_add_photo_flow
end