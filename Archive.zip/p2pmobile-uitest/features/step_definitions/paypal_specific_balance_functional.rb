require 'rubygems'
class Paypal_Specific_Balance_Functional
  include Calabash::Android::Operations
  @@PSBs_section_id = "PSBs_section"
  @@PSBs_grid_view_id = "PSBs_grid_view"
  @@PSBs_section_title_id = "PSBs_section_title"
  @@tap_psb_text_id = "item_desc"
  @@psb_show_terms_id = "show_terms_button"
  @@psb_terms_txt_id = "terms_txt"

  def verify_psb
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_visible(@@PSBs_section_id)
    ANDROID.assert_id_visible(@@PSBs_section_title_id)
    ANDROID.assert_id_visible(@@PSBs_grid_view_id)
    ANDROID.assert_text_visible("99")
  end

  def verify_no_psb
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_invisible(@@PSBs_section_id,'','')
  end

  def tap_psb
    ANDROID.tap(@@tap_psb_text_id, 'id')
  end

  def verify_psb_details
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_visible(@@psb_show_terms_id)
  end

  def tap_terms
    ANDROID.tap(@@psb_show_terms_id, 'id')
  end

  def verify_psb_terms
    ANDROID.wait_for_actionbar_progress
    ANDROID.assert_id_visible(@@psb_terms_txt_id)
  end

  def random_string(length)
      return (0...length).map { (65 + rand(26)).chr }.join
  end

  def add_psb_to_account(funder, receiver, endDate, country, amount, currentAmount,currency)
    lower_bound = Time.now.to_i+ 15
    campaign_code = "CS_PSB"+"_"+random_string(5)
    res = PPUSER.create_psb_program(lower_bound.to_s,endDate,country,currency,"en_AU","PSB Compaign AU","New PSB Campaign","S","desc",funder,"0",amount,campaign_code,"0","true","true","true")
    sleep(15)
    res2 = PPUSER.add_psb(campaign_code,"0",receiver,"true",amount,currentAmount,"0",currency)
  end
end