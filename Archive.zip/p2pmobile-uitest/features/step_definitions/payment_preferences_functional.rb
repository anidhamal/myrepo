
class PaymentPreferences_Functional

  ############################################################################################################

  @@payment_preferences_id = "payment_preferences"
  @@payment_pref_desc_id = "ppPPrefsDesc"
  @@paypref_title_text_id = "ppPPrefsTitle"

  ############################################################################################################
  # Method Name: waitForPaymentPref
  # Parameters : this method is used to wait for payment preferences
  #############################################################################################################

  def waitForPaymentPref

    ANDROID.wait_till_id_visible(@@payment_pref_desc_id)
    ANDROID.wait_till_id_visible(@@paypref_title_text_id )

  end

  ############################################################################################################
  # Method Name: verifyPaymentPref
  # Parameters : this method is used to verify payment preferences
  #############################################################################################################

  def verifyPaymentPref

    ANDROID.assert_id_visible(@@payment_pref_desc_id)
    ANDROID.assert_id_visible(@@paypref_title_text_id)

  end

  ############################################################################################################
  # Method Name: changePayPrefToCreditCard
  # Parameters : this method is used to change paymeny preference to credit card
  #############################################################################################################

  def changePayPrefToCreditCard()

    ANDROID.drag_xy_to_xy(90,50,50,50,50)
    ANDROID.drag_xy_to_xy(90,50,50,50,50)
    ANDROID.drag_xy_to_xy(90,50,50,50,50)
    ANDROID.drag_xy_to_xy(90,50,50,50,50)
    ANDROID.drag_xy_to_xy(90,50,50,50,50)

  end

  ############################################################################################################
  # Method Name: changePayPrefToBank
  # Parameters : this method is used to change paymenet preferene to bank
  #############################################################################################################

  def changePayPrefToBank()

    ANDROID.drag_xy_to_xy(10,50,50,50,50)
    ANDROID.drag_xy_to_xy(10,50,50,50,50)
    ANDROID.drag_xy_to_xy(10,50,50,50,50)
    ANDROID.drag_xy_to_xy(10,50,50,50,50)
    ANDROID.drag_xy_to_xy(10,50,50,50,50)
  end


end

