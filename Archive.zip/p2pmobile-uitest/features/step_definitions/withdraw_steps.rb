Given(/^user can go to withdraw money$/) do
  NAV.goToWithdraw
end

When(/^user selects Balance, enters amount "(.*?)"$/) do |amount|
  WithdrawInitFunctional.enterAmount(amount)
  WithdrawInitFunctional.tapWithdrawBtn
  ANDROID.wait_for_progressbar
end

Then(/^user is able to withdraw money successfully$/) do
  WithdrawFinalPageFunctional.verifyWithdrawSuccess
  WithdrawFinalPageFunctional.tapDone
end

When(/^user can switch bank to withdraw$/) do
  WithdrawInitFunctional.switchBankAcct
end

And(/^user can switch balance to withdraw$/) do
  WithdrawInitFunctional.switchBalance
end

And(/^user can switch from bank to card$/) do
  WithdrawInitFunctional.switchBankAcct
end

And(/^user agrees to withdraw with fees$/) do
  WithdrawInitFunctional.tapOkBtn
end

Then(/^withdraw button should be disabled$/) do
  WithdrawInitFunctional.verifyWithdrawButtonDisabled
end

Then(/^user confirms withdraw with fees$/) do
  WithdrawInitFunctional.confirmwithFees
end

Then(/^user agrees to withdraw$/) do
  WithdrawInitFunctional.tapConfirm
end

And(/^user sees withdraw screen$/) do
  WithdrawInitUI.verify_withdraw_money_page
end

Then(/^user sees withdraw success screen$/) do
  WithdrawSuccessfulPage.verify_withdraw_successful_page
end