require_relative 'scan_check_functional'

scancheck_functional = Scan_Check_Functional.new


#########################################################################
## Scenario 1: US user is able to see Scan Check button and intro screen
#########################################################################

When(/^user taps on scan check button on wallet screen$/) do

  NAV.goToWallet
  NAV.goToScanCheckPage

end

Then(/^user sees scan check page$/) do

  scancheck_functional.verifyScanCheckPage


end