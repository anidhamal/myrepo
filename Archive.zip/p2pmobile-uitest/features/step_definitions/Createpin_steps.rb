############################################
#user goes to create pin page
############################################

And(/^user goes to create or change pin view$/) do
  NAV.goToPin
end

############################################
#user creates pin and phone number
############################################

Then(/^user creates pin "([^"]*)" for phone "([^"]*)" successfully$/) do |pin, phone|
  CreatePinFunctional.create_pin(pin, phone)
end

##############################################
#user logs out from tab bar
###############################################

Then(/^user logs out from Tab Bar$/) do
  CreatePinFunctional.logout_tabbar
end

####################################################
#user goes to change pin page to enter new pin
####################################################

Then(/^user should be able to change pin "([^"]*)" successfully$/) do |pin|
  CreatePinFunctional.change_pin(pin)
end

######################################################
#user create different pin1 and pin2
#######################################################

Then(/^user tries to Create Pin with pin1 as "([^"]*)" and pin2 as "([^"]*)"$/) do |pin1, pin2|
  CreatePinFunctional.create_differentpin(pin1, pin2)
  end

####################################################
#user gets warning message
###################################################

Then(/^user gets warning message$/) do
  ANDROID.wait_till_id_visible ('error_text')
end

