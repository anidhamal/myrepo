# Author
# Steve Shenouda
class ShopMerchantDetailsFunctional
  ID_MERCHANT_LOGO = 'checkin_merchant_logo'
  ID_MERCHANT_NAME = 'checkin_merchant_name'
  ID_MERCHANT_ADDRESS = 'checkin_merchant_address'
  ID_SLIDE_TEXT = 'slide_text'
  ID_PAY_TAB = 'tab_1_text'
  ID_ORDER_TAB = 'tab_2_text'
  ID_ANGLED_SLIDER_VIEW = 'AngledSliderView'
  ID_ORDER_BUTTON = 'enhanced_checkin_button'
  ID_MAP = 'googleLocation'
  ID_DIRECTIONS = 'googleDirection'
  ID_PHONE_NUMBER = 'text_merchant_phone'
  ID_MOBILE_PHONE_AND_PIN = 'touchstone_title'

  def self.verify_merchant_details(name)
    ANDROID.wait_till_id_visible(ID_MERCHANT_LOGO)
    ANDROID.wait_till_id_visible(ID_MERCHANT_NAME)
    ANDROID.check_element_exists("* id:'#{ID_MERCHANT_NAME}' * {text CONTAINS '#{name}'}")
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS)
  end

  def self.verify_slide_text(type)
    ANDROID.wait_till_id_visible(ID_SLIDE_TEXT)
    ANDROID.check_element_exists("* id:'#{ID_SLIDE_TEXT}' * text:'#{type}'")
  end

  def self.verify_payment_types_exist(tab1, tab2)
    ANDROID.wait_till_id_visible(ID_PAY_TAB)
    ANDROID.check_element_exists("* id:'#{ID_PAY_TAB}' * text:'#{tab1}'")
    ANDROID.check_element_exists("* id:'#{ID_ORDER_TAB}' * text:'#{tab2}'")
  end

  def self.tap_payment_type(type)
    ANDROID.tap2("* text:'#{type}'")
    if type == 'PAY'
      ANDROID.check_id_exists(ID_ANGLED_SLIDER_VIEW)
    else
      ANDROID.check_element_exists("* id:'#{ID_SLIDE_TEXT}' * text:'Click to Order'")
    end
  end

  def self.tap_merchant_info
    ANDROID.wait_till_id_visible(ID_MERCHANT_LOGO)
    ANDROID.tap2("* id:'#{ID_MERCHANT_LOGO}'")
  end

  def self.verify_contact_info
    ANDROID.wait_till_id_visible(ID_MAP)
    ANDROID.check_id_exists(ID_DIRECTIONS)
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS)
    ANDROID.check_id_exists(ID_PHONE_NUMBER)
  end

  def self.verify_mobile_phone_and_pin(text)
    ANDROID.wait_till_id_visible(ID_MOBILE_PHONE_AND_PIN)
    ANDROID.check_element_exists("* id:'#{ID_MOBILE_PHONE_AND_PIN}' * text:'#{text}'")
  end
end
