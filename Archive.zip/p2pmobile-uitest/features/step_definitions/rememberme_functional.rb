
class RememberMe_Functional

  ############################################################################################################

  @@rememberme_checkbox_id = "remember_me_checkbox"
  @@rememberme_footer_id = "remember_footer"

  ############################################################################################################
  # Method Name: tapOnRememberMe
  # Parameters :
  # Description: This method will check the checkbox in Security Settings
  #############################################################################################################

  def turnRememberMeOff

    check = ANDROID.check_checkbox(@@rememberme_checkbox_id)
    if check == true
      ANDROID.wait_till_id_visible(@@rememberme_checkbox_id)
      ANDROID.tap(@@rememberme_checkbox_id, "id")
    end

  end

end