# Author
# Steve Shenouda

When(/^user tries to send money to "(.*?)", amount "(.*?)", currency "(.*?)", type "(.*?)", message "(.*?)"$/) do |recipient, amount, currency, type, message|
  NAV.goToSendMoney
  SendMoneyInitFunctional.send_money(recipient, amount, currency, type, message)
  SendMoneyReviewFunctional.tap_send_money
end

Then(/^user sees the OFAC Payment Pending page$/) do
  OfacFunctional.verify_ofac_screen
end
