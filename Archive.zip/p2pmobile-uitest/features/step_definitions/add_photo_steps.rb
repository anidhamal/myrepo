###
# Author
# Sarika Kamisetty
###

#################################################
## Scenario 1: User can see add photo page
#####################################################
When /^user taps on my photo button on settings screen$/ do
  NAV.goToPhoto
end

Then /^user sees add photo page$/ do
  Add_Photo_Functional.verifyAddPhoto
end

# User adds photo
Given(/^user adds photo from Settings$/) do
  NAV.goToPhoto
  Add_Photo_Functional.add_photo
  Add_Photo_Functional.tap_ok_error_popup
  NAV.go_to_previous_screen
end