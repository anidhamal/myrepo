require 'rubygems'
require 'calabash-android'

login_functional = Login_functional.new

Given(/^user launch pptouch app$/) do
  #@@touch = Calabash::Android::Operations::Device.new(self, nil, "34802", "#{PPTOUCH_APP_PATH}", test_server_path("/Users/arsivaraman/repos/fork_rohan/p2pmobile-uitest/pptouch/test_servers/ea917e9c41a1391b023121f724ed09d6_0.4.21.apk"), 7104)
  @@touch = Calabash::Android::Operations::Device.new(self, nil, "34802", "#{PPTOUCH_APP_PATH}", "#{PPTOUCH_TEST_APP_PATH}", 7104)
  @@touch.reinstall_apps
  set_default_device(@@touch)
  @@touch.start_test_server_in_background
  set_default_device(@@touch)

end

Given(/^user tap "(.*?)" to see the PayPal App$/) do |arg1|
  sleep 2
  puts element_exists("* text:'PP Touch consent'")
  touch("* text:'PP Touch consent'")
  #ANDROID.wait_till_text_visible("Not Now")
end

Then(/^user sees Consent page$/) do
  ANDROID.wait_till_element_visible("* id:'title'")
end

When(/^user taps on "(.*?)" on the KMLI$/) do |text|
  if text.downcase == "turn it on"
  ANDROID.tap2("* id:'right_split_button'")
  elsif text.downcase == "not now"
    ANDROID.tap2("* id:'left_split_button'")
  end
end

When(/^user taps on "(.*?)" on Consent page$/)  do |text|
  if text.downcase == "agree"
  ANDROID.tap2("* id:'left_split_button'")
 elsif text.downcase == "cancel"
  ANDROID.tap2("* id:'left_split_button'")
    end
end

Then(/^user sees LWLD with KMLI "(.*?)"$/) do |arg1|
  ANDROID.wait_till_element_visible("* id:'tvMsg'")
end

Then(/^PPTouch app is activated$/) do
  wait_till_element_visible("* text:'PayPal Touch Sample App 2'")
end

When(/^PPTouch app is not activated$/) do
  #ANDROID.wait_till_element_visible("* class:'android.widget.TextView index:2'")
  wait_till_element_visible("* id:'result_textView'")
   sleep 1
end

Then(/^PPTouch app shows "(.*?)"$/) do |arg1|
  wait_till_element_visible("* text:'#{arg1}'")
end

Then(/^user taps Cancel on KMLI Page$/) do
  sleep 1
  #Dismiss keyboard
  ANDROID.hardware_back
  #Press back
  ANDROID.hardware_back
  sleep 1
end

Then(/^user sees KMLI alert message$/) do
  sleep 1
  ANDROID.wait_till_element_visible("* id:'kmli_for_checkout'")
  #ANDROID.wait_till_element_visible("* text:'OK'")
end

def wait_till_element_visible (element)
  debug = "Tried waiting for element:#{element} for #{TIMEOUT} and was not able to find it."
  n = TIMEOUT.to_i*4
  for i in 1 .. n
    if element_exists(element)
      break
    else
      puts "No app yet will retry : #{i}"
      sleep 0.25
    end
  end
  if i==n
    raise debug
  end
end

When(/^user change environment to "(.*?)"$/) do |ar|
  touch("* text:'mock'")
  sleep 1
  touch("* text:'#{ar}'")
  sleep 1

end
Then(/^user switches KMLI to On$/) do
  NAV.goToSettings
  NAV.goToLoginOptions
  ANDROID.tap2("* id:'#{'horizontal_divider'}'")
end

#PPTouch login
Then /^user login with "([^"]*)", "([^"]*)"$/ do |id, secret|
  NAV.goToLogin
  login_functional.login(id, secret)
  login_functional.tapLogin(id)
  ANDROID.wait_till_element_visible("* text:'app two asks that you:'")
end
When(/^user taps on  the Agree on Consent page$/) do
  ANDROID.tap2("* id:'right_split_button'")
end

When(/^user switch to phone pin login$/) do
  ANDROID.tap2("* id:'ibMenuPrefilled'")
  sleep 1
  ANDROID.tap2("* id:'row' index:1")
end