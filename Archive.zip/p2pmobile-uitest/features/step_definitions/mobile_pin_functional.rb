require 'calabash-android'
class Mobile_Pin_functional

  ############################################################################################################
  @@paypal_logo_id='home'
  @@settings_menu_id = "button_settings"
  @@mobile_phone_pin_id = "mobile_phone_pin"
  @@create_pin_button_linkPg_id = "create_change_pin_button"
  @@create_pin_button_page_id="changePINButton"
  @@logout_menu_id = "button_logout"
  @@logout_menu_text = "Log Out"
  @@yes_id = "button1"
  @@yes_text = "Yes"
  @@create_pin_spinner_id = "creatPINPhoneNumberSpinner"
  @@other_text = "Other"
  ############################################################################################################

  ############################################################################################################
  # Method Name: createPin
  # Parameters : phone, pin
  # Description: The method takes phone, pin to enter on Create Pin page
  #############################################################################################################
  def createPin(phone, pin)
    ANDROID.tap(@@create_pin_spinner_id, "id")
    ANDROID.wait_till_text_visible(@@other_text)
    ANDROID.tap(@@other_text, "text")
    ANDROID.clear_text(1)
    ANDROID.enter_text(phone, "1")
    ANDROID.clear_text(2)
    ANDROID.enter_text(pin, "2")
    ANDROID.clear_text(3)
    ANDROID.enter_text(pin, "3")
    ANDROID.tap(@@create_pin_button_page_id, "id")
  end

  def changePin(pin)
  ANDROID.clear_text(1)
  ANDROID.enter_text(pin, "1")
  ANDROID.clear_text(2)
  ANDROID.enter_text(pin, "2")
  ANDROID.tap(@@create_pin_button_page_id, "id")
  end

  def logOutFromCreatePin
    ANDROID.wait_for_progressbar
    ANDROID.wait_till_id_visible(@@create_pin_button_linkPg_id)
    ANDROID.hardware_back
    ANDROID.wait_till_id_visible(@@mobile_phone_pin_id)
    ANDROID.swipe_left
    ANDROID.tap(@@logout_menu_text, "text")
    ANDROID.wait_till_id_visible(@@yes_id)
    ANDROID.tap(@@yes_text,"text")
  end
end
