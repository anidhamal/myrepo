###
# Author
# Steve Shenouda
# Indumathy Kesavan
#
###
Given(/^user goes to send money$/) do
  NAV.goToSendMoney
end

Then(/^user can select between friends and family and goods and services$/) do
  SendMoneyInitFunctional.verify_payment_for_choice
end

Then(/^user can send money to "(.*?)" with amount "(.*?)" in currency "(.*?)" with message "(.*?)"$/) do |recipient, amount, currency, message|
  SendMoneyInitFunctional.send_money(recipient, amount, currency, nil, message)
end

Then(/^user can change funding source$/) do
  SendMoneyInitFunctional.change_funding_source(nil)
end

Then(/^user is able to send money successfully$/) do
  SendMoneyReviewFunctional.tap_send_money
  SendMoneyFinalFunctional.verify_successful_transfer
end

Given(/^user goes to send money review page with "(.*?)", amount "(.*?)", currency "(.*?)", type "(.*?)", message "(.*?)"$/) do |recipient, amount, currency, type, message|
  NAV.goToSendMoney
  SendMoneyInitFunctional.send_money(recipient, amount, currency, type, message)
end

Given(/^user goes to send money review page by sending money more than balance to "(.*?)", currency "(.*?)", type "(.*?)", message "(.*?)"$/) do |recipient, currency, type, message|
  balance = SendMoneyInitFunctional.retrieve_balance
  NAV.goToSendMoney
  SendMoneyInitFunctional.send_money(recipient, balance + 1, currency, type, message)
end

Given(/^user can change funding method on review page from bank "(.*?)" to card "(.*?)"$/) do |_arg1, fund|
  SendMoneyInitFunctional.change_funding_source(fund)
end

Then(/^user should be able to see recipient "(.*?)", amount "(.*?)", fees "(.*?)", total amount "(.*?)"$/) do |recipient, amount, fees, total_amount|
  SendMoneyReviewFunctional.verify_send_money_review_page(recipient, amount, fees, total_amount)
end

When(/^user goes to Activity screen$/) do
  NAV.goToActivity
end

Then(/^user should see transaction details with payment amount "(.*?)" as "(.*?)" for account "(.*?)" with message "(.*?)"$/) do |amount, status, name, message|
  ActivityDetailsUI.verify_transaction_details(amount, status, name)
end

Then(/^user should see "(.*?)" as funding method on review page$/) do |fund|
  SendMoneyInitFunctional.verify_funding_method(fund)
end


Then(/^Review button should be disable$/) do
  SendMoneyInitFunctional.verify_review_button_disabled
end

Then(/^user is able to send money$/) do
  SendMoneyInitFunctional.tap_sendmoney
end

And(/^user can change funding method on review page from Bank to Card$/) do
  SendMoneyReviewFunctional.change_funding_type
end

Then(/^user sees the send money screen$/) do
  SendMoneyInitUI.verify_send_money_page
end

Then(/^user sees the send money review screen$/) do
  SendMoneyReviewUI.verify_sendmoney_review_page
end

When(/^user taps on send button$/) do
  SendMoneyReviewUI.send_money_button
end

Then(/^user sees the send money success screen$/) do
  SendMoneyFinalUI.verify_successful_transfer
end