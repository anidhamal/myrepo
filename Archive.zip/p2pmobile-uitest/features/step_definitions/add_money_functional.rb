class Add_Money_Functional

  @@add_button_id = "Add"
  @@amount_edit_id = "amount_edit"
  @@account_balance_label_id =  "account_balance_label"
  @@aggregate_total_balance_id = "aggregate_total_balance"
  @@amount_frame_id = "amount_frame"
  @@add_funds_message_id = "add_funds_message"
  @@add_funds_button_id = "add_funds_button"
  @@completion_status_id = "completion_status"
  @@content_id = "content"
  @@success_summary_id = "success_summary"
  @@success_details_id = "success_details"
  @@done_button_id = "done_button"
  @@bank_id = "text"
  @@select_bank_id = "android.widget.TextView index:1"


  def goToAddMoneyOnWallet
    NAV.goToAddFunds
  end

  def verifyAddMoneyPage()
    ANDROID.assert_id_visible(@@account_balance_label_id)
    ANDROID.assert_id_visible(@@aggregate_total_balance_id)
    ANDROID.assert_id_visible(@@amount_frame_id)
    ANDROID.assert_id_visible(@@amount_edit_id)
    ANDROID.assert_id_visible(@@add_funds_message_id)
    ANDROID.assert_id_visible(@@add_funds_button_id)
  end

  def enterAmount(amount)
    ANDROID.enter_text(amount, 1)
    ANDROID.tap(@@add_button_id, "button")
  end

  def tapDone
    ANDROID.wait_till_id_visible(@@done_button_id)
    ANDROID.tap(@@done_button_id,"id")
  end

  def verifyAddMoneySuccessful
    ANDROID.assert_id_visible(@@completion_status_id)
    ANDROID.assert_id_visible(@@success_summary_id)
    ANDROID.assert_id_visible(@@success_details_id)
    ANDROID.assert_id_visible(@@done_button_id)
  end

  def switchBankAcct
      ANDROID.assert_id_visible(@@bank_id)
      ANDROID.tap(@@bank_id, "id")
      ANDROID.wait_till_element_visible(@@select_bank_id)
      ANDROID.tap(@@select_bank_id, "element")
  end

end
