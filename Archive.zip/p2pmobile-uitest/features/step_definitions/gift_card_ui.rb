class GiftCardInitUI

  # user verifies the gift card category
  def self.verify_giftcard_category
    ANDROID.wait_till_id_visible("gift_cards_section")
    ANDROID.check_an_element_exists("* id:'gift_cards_section'")
    ANDROID.check_an_element_exists("* id:'menu_wallet_add_card'")
    ANDROID.check_an_element_exists("* id:'menu_refresh'")
  end

  # user comfirms there is no gift cards in wallet page after deleting
  def self.verify_no_giftcard_category
    ANDROID.wait_till_id_visible("button_wallet")
    ANDROID.check_an_element_does_not_exist("* id:'#{'gift_cards_section'}'")
  end

  # user verifies error message on search page
  def self.verify_error_message_on_search(message)
    ANDROID.wait_till_id_visible("gift_card_program_empty_search")
    ANDROID.check_an_element_exists("* id:'#{'gift_card_merchant_icon'}'")
    ANDROID.check_an_element_exists("* id:'#{'gift_card_program_empty_search'}'")
    ANDROID.check_an_element_exists("* id:'#{'gift_card_program_add_notification_part1'}'")
    ANDROID.assert_text_visible(message)
  end

end

class GiftCardInfoUI

  # user verifies the gift card information page
  def self.verify_giftcard_info_page
    ANDROID.wait_till_id_visible('wallet_tabs')
    ANDROID.wait_till_id_visible('logo')
    # merchant name
    ANDROID.check_an_element_exists("* id:'logo'")
    # card  number container
    ANDROID.check_an_element_exists("* id:'gift_card_card_number'")
    # card pin container
    ANDROID.check_an_element_exists("* id:'gift_card_pin_number'")
    # card information message
    ANDROID.check_an_element_exists("* id:'gift_card_info_message'")
    # card terms and condition
    ANDROID.check_an_element_exists("* id:'gift_card_terms_and_conditions'")
  end

  # user verifies terms and conditions label in gift card information page
  def self.verify_terms_conditions
    ANDROID.wait_till_id_visible('wallet_tabs')
    #ANDROID.check_an_element_exists("* id:'wallet_tabs'")
    ANDROID.check_an_element_exists("* id:'#{'wallet_tabs'}' * {text CONTAINS '#{'Terms and Conditions'}'}")
    ANDROID.tap2("* id:'#{'home'}'")
  end

  # user verifies gift card logo on wallet
  def self.verify_giftcard_logo
    ANDROID.wait_till_id_visible('wallet_tabs')
    ANDROID.wait_till_id_visible('logo')
    # merchant name
    ANDROID.check_an_element_exists("* id:'logo'")
  end

  # user verifies gift card text on details page
  def self.verify_giftcard_text
    ANDROID.wait_till_id_visible('wallet_tabs')
    # merchant name
    ANDROID.check_an_element_exists("* id:'gift_card_card_number'")
  end

  # user verifies gift card back image on the add gift card image
  def self.verify_back_image
    # Back of the image
    ANDROID.check_an_element_exists("* id:'back_image'")
  end

  # user verifies gift card not added on wallet page
  def self.verify_giftcard_not_added
    verify_giftcard_info_page
  end

  # user verifies gift card doesn't have Info link
  def self.verify_giftcard_no_info_finder
    ANDROID.wait_till_id_visible('wallet_tabs')
    # gift card info page
    ANDROID.check_an_element_does_not_exist("* id:'gift_card_info_message'")
  end

  # user verifies gift card on wallet
  def self.verify_giftcard_wallet(merchant)
    ANDROID.wait_till_id_visible("button_wallet")
    ANDROID.wait_till_id_visible("merchant_logo")
    ANDROID.check_an_element_exists("* id:'gift_cards_section'")
    ANDROID.check_an_element_exists("* id:'item_background'")
    ANDROID.check_an_element_exists("* id:'merchant_logo'")
  end
end

class GiftcardDetailUI

  # user verifies gift card detail page
  def self.verify_giftcard_detail_page
    ANDROID.wait_till_id_visible('home')
    #user verifies card number label
    ANDROID.check_an_element_exists("* id:'#{'cardNumberText'}' * {text CONTAINS '#{'555 1234 1234 1234'}'}")
    # user verifies pin number label
    ANDROID.check_an_element_exists("* id:'#{'pin_text'}' * {text CONTAINS '#{'PIN: 111'}'}")
    # user verifies balance label
    ANDROID.check_an_element_exists("* id:'#{'balance_label'}' * {text CONTAINS '#{'Balance'}'}")
    # user verifies how to use the card label
    ANDROID.check_an_element_exists("* id:'#{'redemption_header'}' * {text CONTAINS '#{'HOW TO USE'}'}")
    # user verifies bar code image label
    ANDROID.check_an_element_exists("* id:'codeImage'")
  end

  def self.verify_giftcard_detail_page_text(curr_bal_val, bal_ref_btn,lst_upt_time,manual)
    ANDROID.wait_till_id_visible('home')
    #user verifies card number label
    ANDROID.check_an_element_exists("* id:'#{'balance_label'}'")

    # user verifies pin number label
    if bal_ref_btn.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'#{'refresh_balance'}'}")
    end

    if lst_upt_time.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'#{'balance_last_updated'}'}")
    end

    if manual.downcase == 'yes'
      # user verifies balance label
      ANDROID.check_an_element_exists("* id:'#{'balance_manual'}' * {text CONTAINS '#{'(Manual)'}'}")
      ANDROID.check_an_element_exists("* id:'#{'available_balance'}'* {text CONTAINS '#{'Not Entered'}'}")
    else
      ANDROID.check_an_element_exists("* id:'#{'available_balance'}'* {text CONTAINS '#{curr_bal_val}'}")
    end
  end

  # user verifies how to use section
  def self.verify_how_to_use(online, instore, both)
    ANDROID.wait_till_id_visible('actionbar_edit_button')
    ANDROID.check_an_element_exists("* id:'#{'redemption_header'}' * {text CONTAINS '#{'HOW TO USE'}'}")
    if online.downcase == 'yes' or both.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'#{'redeem_online_title'}' * {text CONTAINS '#{'Online'}'}")
      ANDROID.check_an_element_exists("* id:'#{'redeem_online_body'}' * {text CONTAINS '#{'At checkout, enter your card number and PIN.'}'}")
    end

    if instore.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'#{'redeem_store_title'}' * {text CONTAINS '#{'In-Store'}'}")
      ANDROID.check_an_element_exists("* id:'#{'redeem_store_body'}' * {text CONTAINS '#{'Show the cashier your card number and PIN.'}'}")
    end

    if both.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'#{'redeem_store_title'}' * {text CONTAINS '#{'In-Store'}'}")
      ANDROID.check_an_element_exists("* id:'#{'redeem_store_body'}' * {text CONTAINS '#{'Show the cashier your card number and PIN, or let them scan your code.'}'}")
    end
  end

  # user verifies terms and conditions link
  def self.verify_terms_conditions_link
    ANDROID.wait_till_id_visible('actionbar_edit_button')
    #user verifies card number label
    sleep 0.2
    ANDROID.check_an_element_exists("* id:'#{'gift_card_terms'}'")
    #ANDROID.check_an_element_exists("* id:'#{'wallet_tabs'}' * {text CONTAINS '#{'Card Terms and Conditions'}'}")
  end

  # user verifies terms and conditions
  def self.verify_terms_conditions
    ANDROID.wait_till_id_visible('home')
    #ANDROID.check_an_element_exists("* id:'#{'wallet_tabs'}' * {text CONTAINS '#{'Terms and Conditions'}'}")
    #ANDROID.check_an_element_exists("* id:'#{'card_details_pager'}'")
  end

  # user verifies gift card w params
  def self.verify_view_giftcard(merchant_name, card_number,pin, merchant_logo, card_number_value, how_to_use, terms_link, edit_button, back_button,bar_code)
    ANDROID.wait_till_id_visible('home')
    ANDROID.wait_till_id_visible('barcode_details_container')
    # user verifies pin number label
    ANDROID.check_an_element_exists("* id:'#{'cardNumberText'}'")
    # user verifies balance label
    ANDROID.assert_text_visible(pin)
    if merchant_logo.downcase=='yes'
      ANDROID.wait_till_id_visible('logo')
      ANDROID.check_an_element_exists("* id:'#{'logo'}'")
    end

    if how_to_use.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'#{'redemption_header'}'")
    end

    if terms_link.downcase == 'yes'
      ANDROID.scroll_down
      ANDROID.check_an_element_exists("* id:'#{'gift_card_terms'}'")
    end

    if edit_button.downcase == 'yes'
      ANDROID.scroll_down
      ANDROID.check_an_element_exists("* id:'#{'actionbar_edit_button'}'")
    end

    if bar_code.downcase == 'yes'
      ANDROID.scroll_down
      ANDROID.check_an_element_exists("* id:'#{'codeImage'}'")
    end

  end

  # user verifies error message on info page
  def self.verify_error_message_info_page(message)
    ANDROID.wait_till_id_visible("alert_red_banner")
    ANDROID.check_an_element_exists("* id:'#{'alert_red_banner'}'")
    ANDROID.assert_text_visible(message)
  end
end

class GiftCardEditUI

  # user verifies gift card edit page
  def self.verify_giftcard_editpage
    ANDROID.wait_till_id_visible('codeImage')
    #user verifies card number label
    ANDROID.check_an_element_exists("* id:'#{'cardNumberText'}'")
    # user verifies bar code image label
    ANDROID.check_an_element_exists("* id:'codeImage'")
    # user verifies pin number label
    ANDROID.check_an_element_exists("* id:'#{'pin_text'}'")
    # user verifies manual balance container label
    #ANDROID.check_an_element_exists("* id:'#{'gift_card_manual_balance'}'")
    # user verifies remove card button
    ANDROID.check_an_element_exists("* id:'#{'remove_card_button'}'")

  end


  def self.verify_giftcard_editpage_with_params(merchant_name, customer_service, delete_button, done_button, cancel_button, merchant_logo, card_number,bar_code)
    ANDROID.wait_till_id_visible('remove_card_button')

    #user verifies card number label
    ANDROID.check_an_element_exists("* id:'logo'")

    ANDROID.check_an_element_exists("* id:'#{'remove_card_button'}'")

    ANDROID.check_an_element_exists("* id:'done_button'")

    ANDROID.check_an_element_exists("* id:'cancel_button'")

    ANDROID.check_an_element_exists("* id:'#{'cardNumberText'}'")
    # user verifies bar code image label

    if bar_code.downcase == 'yes'
      ANDROID.check_an_element_exists("* id:'codeImage'")
    end

    # user verifies pin number label
    ANDROID.check_an_element_exists("* id:'#{'pin_text'}'")
  end

  # user taps on yes to remove card
  def self.verify_removecard_confirmation
    ANDROID.wait_till_id_visible('message')
    ANDROID.check_an_element_exists("* {text CONTAINS '#{'Yes'}'}")
  end

  def self.verify_pin(pin)
    ANDROID.assert_text_visible(pin)
  end
end