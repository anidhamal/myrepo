require 'singleton'
require 'forgery'

class Nav5x
  include Singleton
  include Calabash::Android::Operations

  ############################################################################################################
  @@signUp_text="Sign Up"
  @@SIGNUP_text = "SIGN UP"
  @@next_text = "Next"
  @@ftn_getStarted = "Get Started"
  @@emailTab_text = "Email"
  @@phoneTab_text = "Phone"
  @@agree_text = "Agree"
  @@getGooglePlayServices_text = "Get Google Play service"
  @@help_text = "Help"
  @@logIn_text = "Log In"
  @@wallet_button_id = "button_wallet"
  @@live_text = "Live"
  @@stage_text = "Stage"
  @@other_text ="other"
  @@settings_button_id = "button_settings"
  @@transfer_button_id = "button_transfer"
  @@request_id="money_request"
  @@activity_text = "Activity"
  @@createPIN_text="Create PIN"
  @@changePin_text = "Change PIN"
  @@addMoney_text = "Add To"
  @@withdrawMoney_text="Withdraw From"
  @@profilePhoto_text = "Profile Photo"
  @@securitysettings_id = "security_settings"
  @@shop_text = "Shop"
  @@paymentpreferences_id = "payment_preferences"
  @@scanCheck_text = "Scan Check"
  @@mobilePhonePin_text = "Mobile Phone and PIN"
  ############################################################################################################
  @@viewTermsDialog_id = "parentPanel"
  @@viewTermsMessage_id = "message"
  @@agree_id = "button1"
  @@firstTimeNextBtn_id = "shop_bottom_button"
  @@firstTimeGetStartedBtn_id = "shop_bottom_button"
  @@loginHelp_id = "button_help"
  @@balanceCaret_id = "balance_caret_right"
  @@historyRefresh_id = "menu_history_refresh"
  @@addCard_icon = "menu_wallet_add_card"
  #@@addCard_icon = "menu_wallet_add_card"
  @@stageDropdown_id = "stage_server_spinner"
  @@signup_menu_id = "button_logout"
  @@login_menu_id = "button_help"
  @@paypal_balance = "paypal_balance"
  @@paypal_logo_id="home"
  @@wallet_home_id = "wallet_tabs"
  @@refresh_wallet_id = "menu_refresh"
  @@creditcard_text = "Credit Card"
  @@activity_refresh_id = "menu_history_refresh"
  @@remember_my_profile = "remember_my_profile"
  @@settings_tabs = "settings_tabs"
  @@paypal_logo_id_gb="abs__home"
  @@activity_id = "button_activity"
  @@addMoney_id = "add_money_button"
  @@withdrawMoney_id = "withdraw_money_button"
  @@scanCheck_id = "scan_check_button"
  @@transfer_menu_id = "button_transfer"
  @@history_menu_id = "button_activity"
  @@wallet_menu_id = "button_wallet"
  @@settings_menu_id = "button_settings"
  @@profilePhoto_id = "profile_photo"
  @@scan_check_button_id = "scan_check_button"
  @@mobile_phone_pin_id = "mobile_phone_pin"
  @@create_pin_button_linkPg_id = "create_change_pin_button"
  @@no_funding_overlay_id = "no_funding_overlay"
  @@SIGNUP_button = "signup_button"
  @@help_page_id="help"
  ID_MENU_WALLET_REFRESH = 'menu_wallet_refresh'
  ID_LOGIN_BUTTON = 'bttnLogin'

  ############################################################################################################


  ############################################################################################################
  # Method Name: goToLogin
  # Parameters : none
  # Description: The method takes the user to "Login" Page
  #############################################################################################################

  def goToLogin
# Check if the user is on shop or login page
    sleep 2
    unless ANDROID.check_id(ID_LOGIN_BUTTON)
      ANDROID.swipe_left
      ANDROID.wait_till_id_visible(@@login_menu_id)
      ANDROID.tap2("* id:'#{@@login_menu_id}'")
      sleep 2

      if ANDROID.check_id(@@viewTermsMessage_id)
        ANDROID.tap2("* id:'#{@@agree_id}'")
        ANDROID.swipe_left
        ANDROID.wait_till_id_visible(@@login_menu_id)
        ANDROID.tap2("* id:'#{@@login_menu_id}'")
        puts "DEBUG: Tapped logout"
      end

      sleep 2
      if ANDROID.check_id(@@help_page_id)
        ANDROID.hardware_back
        ANDROID.swipe_left
        ANDROID.tap2("* id:'#{@@signup_menu_id}'")
      end
    end
  end

  ############################################################################################################
  # Method Name: goToSignUpPage
  # Parameters : none
  # Description: The method takes the user to "Sign up"
  #############################################################################################################
  def goToSignUpPage
    ANDROID.wait_till_id_visible(@@paypal_logo_id)
    #sleep 5 # wait for the launch process to settle down
    #if @@server_set == FALSE
    #  dismiss_terms
    #  sleep 2
    #  skipFirstTimeNews
    #end
    #sleep 3
    #var = false
    #begin
    #  ANDROID.assert(@@phoneTab_text ,"text", true)
    #  var = true
    #rescue Exception => e
    #  if var == false
    #    goToLoginPgFromShop
    #  end
    #end
    #if state == @@signUp_text
    #  sleep 1
    #  ANDROID.tap(@@SIGNUP_text, "text")
    #end
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@signup_menu_id)
    ANDROID.tap(@@signup_menu_id, "id")
  end

  #################################################################
  # Method Name: firstTimeNews
  # Parameters : none
  # Description: Method to skip first time news
  #################################################################
  def skipFirstTimeNews
    sleep 2
    ANDROID.tap(@@firstTimeNextBtn_id, "id")
    sleep 1
    ANDROID.tap(@@firstTimeNextBtn_id, "id")
    sleep 1
    ANDROID.tap(@@firstTimeGetStartedBtn_id, "id")
  end

  ############################################################################################################
  # Method Name: dismiss_terms
  # Parameters : none
  # Description: Dismisses terms and conditions after launching first time
  #############################################################################################################
  def dismiss_terms
    if ANDROID.check_text(@@agree_text)
      ANDROID.tap(@@agree_text, "button")
    end
  end

  ############################################################################################################
  # Method Name: set_server
  # Parameters : server:: specify stage server
  # Description: The method is for Setting stage server
  #############################################################################################################
  def set_server(server)
    if @@server_set == FALSE
      sleep 2
      ANDROID.long_tap(@@loginHelp_id, "id")

      # Following is a workaround since the method ('select_item_from_spinner_with_id) doesn't
      # detect drop down list on FROYO.
      # It assumes that "Live"" or "SERVER" will be shown in the debug option.
      debugOption = @@live_text
      if STAGE != ""
        server = STAGE
        puts "STAGE server set from the environment #{server}"
      end
      begin
        ANDROID.assert_text_visible(@@live_text)
      rescue Exception => e
        ANDROID.assert_text_visible(server)
        debugOption = server
      ensure
        ANDROID.scroll_up

        ANDROID.tap(@@live_text, "text")

        #begin
        #  ANDROID.wait_till_text_visible(@@live_text)
        #rescue Exception => e
        #  ANDROID.wait_till_text_visible(server)
        #end
        ANDROID.tap(@@stage_text, "text")

        ANDROID.tap(@@stageDropdown_id, "id")
        #ANDROID.scroll_down
        ANDROID.wait_till_text_visible(@@other_text)
        ANDROID.tap(@@other_text, "text")

        ANDROID.clear_text(1)
        ANDROID.enter_text(server, 1)
        ANDROID.hardware_back
        sleep 2
        if ((!ANDROID.check_text(@@help_text)) && (!ANDROID.check_text(@@logIn_text)))
          ANDROID.swipe_left
        end
        @@server_set = TRUE
      end
    end
  end

  ############################################################################################################
  # Method Name: goToSendMoney
  # Parameters : none
  # Description: This method will tap on request money text
  #############################################################################################################
  def goToSendMoney
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@transfer_menu_id)
    ANDROID.tap(@@transfer_menu_id, "id")
  end

  ############################################################################################################
  # Method Name: goToRequestMoney
  # Parameters : none
  # Description: This method will tap on request money text
  #############################################################################################################
  def goToRequestMoney
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@transfer_button_id)
    ANDROID.tap(@@transfer_button_id, "id")
    ANDROID.wait_till_id_visible(@@request_id)
    ANDROID.tap(@@request_id, "id")
  end

  ############################################################################################################
  # Method Name: goToWallet
  # Parameters : none
  # Description: This method takes to Wallet page after successful login
  #############################################################################################################
  def goToWallet
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@wallet_menu_id)
    ANDROID.tap(@@wallet_menu_id, "id")
    sleep 1
  end

  ############################################################################################################
  # Method Name: goToBalanceDetailsPg
  # Parameters : none
  # Description: This method will tap on Paypal Balance id
  #############################################################################################################

  def goToBalanceDetailsPg()
    ANDROID.assert_id_visible(@@paypal_balance)
    if ANDROID.check_id(@@no_funding_overlay_id)
      ANDROID.tap(@@no_funding_overlay_id, "id")
    end
    ANDROID.tap(@@paypal_balance, "id")
  end

  ############################################################################################################
  # Method Name: goToAddFunds
  # Parameters : none
  # Description: The method goes to add fund after successful login
  #############################################################################################################
  def goToAddFunds
    goToWallet
    ANDROID.wait_till_id_visible(@@addMoney_id)
    ANDROID.tap(@@addMoney_id, "id")
  end

  ############################################################################################################
  # Method Name: goToWithdraw
  # Parameters : none
  # Description: The method goes to withdraw page after successful login
  #############################################################################################################
  def goToWithdraw
    goToWallet
    ANDROID.wait_till_id_visible(@@withdrawMoney_id)
    ANDROID.tap(@@withdrawMoney_id, "id")
  end

  ############################################################################################################
  # Method Name: goToCardDetails
  # Parameters : bankOrCC
  # Description: The method goes to Detail pages of Bank or CC from Wallet page
  #############################################################################################################
  def goToCardDetails(bankOrCC)
    goToWallet
    ANDROID.wait_till_text_visible(bankOrCC, "text")
    ANDROID.tap(bankOrCC, "text")
  end

  ############################################################################################################
  # Method Name: goToHistory
  # Parameters : none
  # Description: The method goes to History page from the successful login
  #############################################################################################################
  def goToHistory
    ANDROID.swipe_left
    ANDROID.wait_till_text_visible(@@activity_text, "text")
    ANDROID.tap(@@activity_text, "button")
    ANDROID.wait_till_text_visible(@@historyRefresh_id, "id")
  end

  ############################################################################################################
  # Method Name: goToSettings
  # Parameters :
  # Description: The method goes to Settings page after successful login
  #############################################################################################################
  def goToSettings
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@settings_menu_id)
    ANDROID.tap(@@settings_menu_id, "id")
  end

  ############################################################################################################
  # Method Name: goToNavigationDrawer
  # Parameters :
  # Description: The method goes to the Navigation Drawer after successful login
  #############################################################################################################
  def goToNavigationDrawer
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@settings_menu_id)
  end

  ###########################################################################################################
  # Method Name: goToAddCard
  # Parameters : none
  # Description:  Method to go to Add Card screen after successful login
  #############################################################################################################
  def goToAddCard
    goToWallet
    goToActionSheet
  end

  ###########################################################################################################
  # Method Name: goToAddCardAtWallet
  # Parameters : none
  # Description:  Method to go to Add Card screen after successful login
  #############################################################################################################
  def goToAddCardAtWallet
    goToActionSheet
    #TODO: Need to change this to ID based
    #ANDROID.wait_till_text_visible(@@creditcard_text)
    #ANDROID.assert_text_visible(@@creditcard_text)
    #ANDROID.tap(@@creditcard_text, "text")
  end

  ###########################################################################################################
  # Method Name: goToAddCard
  # Parameters : none
  # Description:  Method to go to Add Card screen after successful login
  #############################################################################################################
  def goToActionSheet
    ANDROID.tap2("* id:'#{ID_MENU_WALLET_REFRESH}'")
    ANDROID.wait_for_progressbar
    ANDROID.wait_till_id_visible(@@addCard_icon)
    ANDROID.tap(@@addCard_icon, "id")
    sleep 1 # Adding sleep as the script executes too fast to see the action sheet
  end

  ############################################################################################################
  # Method Name: goToPin
  # Parameters :
  # Description: The method takes user to Mobile Phone and Pin page
  #############################################################################################################
  def goToPin
    goToSettings
    ANDROID.wait_till_id_visible(@@mobile_phone_pin_id)
    ANDROID.tap(@@mobile_phone_pin_id, "id")
    ANDROID.wait_till_id_visible(@@create_pin_button_linkPg_id)
    ANDROID.tap(@@create_pin_button_linkPg_id, "id")
  end

  ############################################################################################################
  # Method Name: goToPaymentPref
  # Parameters :
  # Description: The method goes to Payment Preference page
  #############################################################################################################
  def goToPaymentPref
    ANDROID.wait_till_id_visible(@@paymentpreferences_id)
    ANDROID.tap(@@paymentpreferences_id, "id")

  end

  ############################################################################################################
  # Method Name: gotoSecuritySettings
  # Parameters : none
  # Description: The method goes to Security Settings page
  #############################################################################################################
  def goToSecuritySettings
    ANDROID.wait_till_id_visible(@@securitysettings_id)
    ANDROID.tap(@@securitysettings_id, "id")
    ANDROID.wait_till_id_visible(@@settings_tabs)
    ANDROID.wait_till_id_visible(@@remember_my_profile)
  end

  ############################################################################################################
  # Method Name: goToShopPage
  # Parameters : none
  # Description: The method goes to Shop page
  #############################################################################################################
  def goToShopPage
    ANDROID.swipe_left
    ANDROID.wait_till_text_visible(@@shop_text)
    ANDROID.tap(@@shop_text, "text")
  end

  ############################################################################################################
  # Method Name: goToScanCheckPage
  # Parameters : none
  # Description: The method goes to Scan Check page
  #############################################################################################################
  def goToScanCheck
    goToWallet
    ANDROID.wait_till_text_visible(@@scanCheck_text, "text")
    ANDROID.tap(@@scanCheck_text, "text")
  end

  ############################################################################################################
  # Method Name: goToPhoto
  # Parameters : none
  # Description: The method goes to Profile Photo
  #############################################################################################################
  def goToPhoto
    goToSettings
    ANDROID.wait_till_id_visible(@@profilePhoto_id)
    ANDROID.tap(@@profilePhoto_id, "id")
  end

  ############################################################################################################
  # Method Name: goToShopPage
  # Parameters : none
  # Description: The method goes to Shop page
  #############################################################################################################
  def goToActivity
    ANDROID.swipe_left
    ANDROID.wait_till_id_visible(@@activity_id)
    ANDROID.tap(@@activity_id, "id")
  end


  ############################################################################################################
  # Method Name: goToScanCheckPage
  # Parameters :
  # Description: This method will tap on scan check button and go to scancheck page
  #############################################################################################################

  def goToScanCheckPage

    ANDROID.assert_id_visible(@@scan_check_button_id)
    ANDROID.tap(@@scan_check_button_id, "id")

  end

###########################################################################################################
# Method Name: generate Credit card number
# Parameters :
# Description: Method to generate credit card number in Add Card screen
#############################################################################################################

  def generate_cc(card_type, digits)
    return Forgery(:credit_card).number(:type => card_type, :length => digits)
  end

  ############################################################################################################
  # Parameters : none
  # Description: This method will go to the loyalty cards page
  #############################################################################################################
  def go_to_loyalty_cards
    goToWallet
    ANDROID.tap2("* id:'#{ID_MENU_WALLET_REFRESH}'")
    ANDROID.wait_for_actionbar_progress
    goToActionSheet
    ANDROID.wait_till_text_visible("Loyalty Card")
    ANDROID.tap("Loyalty Card", "text")
  end

  ############################################################################################################
  # Parameters : none
  # Description: This method will go to the Gift Card Information page
  #############################################################################################################
  def goToGiftCard
    ANDROID.tap2("* text:'#{'Gift Card'}'")
  end

  ##############################################################################################################
  # Tap on back button to goto previous screen
  ###############################################################################################################
  def go_to_previous_screen
    ANDROID.tap2("* id:'#{@@paypal_logo_id}'")
  end
end
