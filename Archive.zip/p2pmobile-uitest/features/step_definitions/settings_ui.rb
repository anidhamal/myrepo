class Settings_UI

  ############################################################################################################
  @@first_name_id = "txt_fname"
  @@last_name_id = "txt_lname"
  ############################################################################################################

  def verify_name(name)
    users_name = ANDROID.get_text_from_id(@@first_name_id).first + " " + ANDROID.get_text_from_id(@@last_name_id).first

    if (name != users_name)
      raise "Name does not match. Expected #{name}. Got #{users_name}."
    end
  end

end