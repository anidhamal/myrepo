require_relative 'login_functional'

# errorhandling_functional=ErrorHandling_Functional.new
loginerrorhandling_UI=LoginerrorHandling_UI.new
addcard_functional=AddCard_Functional.new
login_functional=Login_functional.new

Then(/^user gets an error message "([^"]*)"$/) do |msg|
  loginerrorhandling_UI.verify_error_message(msg)
end

Given(/^with PPUSER: I login with a "([^"]*)" country user with "([^"]*)" credit cards$/) do |country, num_of_cards|
  steps %Q{
  Given with PPUSER: I login with a "#{country}" country user with balance
  }
  for i in 1..num_of_cards.to_i
    steps %Q{
    Given with PPUSER: I add a credit card with type "Visa" to "US" country user, confirmed "yes"
  }
  end
end

When(/^user taps on link a card$/) do
  addcard_functional.tapAddCard
end

Given(/^user tries to login with "([^"]*)" "([^"]*)", "([^"]*)" pin$/) do |country, id, secret|
  NAV.goToLogin
  login_functional.switch_user
  login_functional.login(id, secret)
  login_functional.tapLogin(id)
end