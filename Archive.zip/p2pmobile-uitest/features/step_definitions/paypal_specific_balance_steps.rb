require_relative 'paypal_specific_balance_functional'

psb_functional = Paypal_Specific_Balance_Functional.new

receiver_email_list = Hash.new

Given /^with PPUSER: I create a new user with PayPal Specific Balance in "(.*?)" "(.*?)"$/ do |country, currency|
  buyer = PPUSER.create_user("country," + country + ",currency," + currency + ",type,personal")
  receiver = buyer['account_number']
  receiver_email = buyer['email']
  merchant = PPUSER.create_user("country," + country + ",currency," + currency + ",type,business")
  funder = merchant['account_number']
  funder_email = merchant['email']
  puts "receiver account - #{receiver}"
  puts "funder account - #{funder}"
  options = {"amount" => '9900000', "currency" => currency}
  PPUSER.addBalance(options)
  psb_functional.add_psb_to_account(funder, receiver, '1445385600', country, '9900', '9900', currency)
  receiver_email_list[country+currency] = receiver_email;

end

Given /^user can login with "(.*?)" "(.*?)" PSB receiver account$/ do|country, currency|
  receiver_email = receiver_email_list[country+currency]
  puts receiver_email
  steps %Q{
    Then user can login with "#{receiver_email}", "11111111"
  }
end

##################################################################
# User verify the PSB in the wallet
##################################################################
Then /^user should verify the PayPal Specific Balance$/ do
  psb_functional.verify_psb
end

##################################################################
# User should not observe the PSB in the wallet
##################################################################
Then /^user should not see PayPal Specific Balance$/ do
  psb_functional.verify_no_psb
end

##################################################################
# User taps on the PayPal Specific Balance
##################################################################
When /^user taps on the PayPal Specific Balance$/ do
  psb_functional.tap_psb
end

##################################################################
# User observes the PayPal Specific Balance details
##################################################################
Then(/^user can see PayPal Specific Balance detail screen$/) do
  psb_functional.verify_psb_details
end

##################################################################
# User Taps on See Terms
##################################################################
When(/^user taps on the See Terms$/) do
  psb_functional.tap_terms
end

##################################################################
# User observes the Terms and Conditions
##################################################################
Then /^user should see Terms and Conditions screen$/ do
  psb_functional.verify_psb_terms
end
