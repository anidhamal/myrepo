class TwoFactorAuthUI
ID_ERROR_MESSAGE_BANNER = 'error_banner'
ID_PAGE_TITLE = 'title_label'
ID_PHONE_NUMBER = 'phone_number_label'
ID_PHONE_NUMBER_LIST_HEADER = 'phone_number_list_header'

# user verifies error message after entering wrong code
  def self.verify_error_message(error)
    ANDROID.wait_till_id_visible (ID_ERROR_MESSAGE_BANNER)
    actual_error = ANDROID.get_text_from_id(ID_ERROR_MESSAGE_BANNER).first.strip
    if actual_error != error.strip
      ANDROID.take_screenshot
      raise "Error did not match. Got: #{actual_error} Expected: #{error}"
    end
  end

# user verifies multiple phone number page
  def self.verify_multiple_phone_page
    ANDROID.wait_till_id_visible (ID_PAGE_TITLE)
    ANDROID.check_an_element_exists("* id:'#{ID_PHONE_NUMBER_LIST_HEADER}' * {text CONTAINS '#{'Well send you a text message with a unique security code. Just tell us which number to send the text to.'}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_PHONE_NUMBER}' index:0")
    ANDROID.check_an_element_exists("* id:'#{ID_PHONE_NUMBER}' index:1")
  end
end