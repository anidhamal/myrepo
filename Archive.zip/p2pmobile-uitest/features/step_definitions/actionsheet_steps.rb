######################################################################
## Scenario 1: US user should see options to add card, bank and BML
######################################################################


When(/^user taps add button on wallet page$/) do

  NAV.goToWallet
  NAV.goToActionSheet

end

Then(/^user sees different options to add$/) do

  ActionSheet_Functional.verifyActionSheet

end

Then(/^user of "([^"]*)" sees different options to add$/) do |country|

  case country
  when /CN|DK|NO|SE|TR/
    ActionSheet_Functional.verifyActionSheet(1)
  when /BR|DE|FR|ES|GB|IT|JP|RU|NL|PT/
    ActionSheet_Functional.verifyActionSheet(2)
  when /AU|US|MX/
    ActionSheet_Functional.verifyActionSheet(3)
  else
    ActionSheet_Functional.verifyActionSheet
  end

end

