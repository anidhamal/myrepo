require_relative 'bank_cards_functional'

bankCards_functional = Bank_Cards_Functional.new

##################################################################
# User can view banks and cards on wallet page
##################################################################
Then /^user can see bank and card on wallet page$/ do
  bankCards_functional.validate_banks_cards
end

##################################################################
# User Navigates to the Wallet Screen
##################################################################
When(/^user navigates to Wallet Page$/) do
  NAV.goToWallet
end



##################################################################
# User observes the bank in the wallet
##################################################################
Then /^user should see a bank$/ do
  bankCards_functional.verify_bank
end

##################################################################
# User taps on the bank
##################################################################
When /^user taps on the bank$/ do
  bankCards_functional.tap_bank
end

##################################################################
# Verify that the bank is confirmed
##################################################################
Then(/^user can see the status as "([^"]*)"$/) do |status|
  bankCards_functional.verify_bank_confirmed(status)
end

##################################################################
# User is able to See a card
##################################################################
Then(/^user should see a card$/) do
  bankCards_functional.verify_card
end

##################################################################
# User is able to See a card with the given details in the wallet
##################################################################
Then /^user should see a card type "([^"]*)" and last 4 "([^"]*)"$/ do |type, last4|
  bankCards_functional.verify_given_card(type, last4)
end
##################################################################
# User Taps on a Card
##################################################################
When(/^user taps on the card$/) do
  bankCards_functional.tap_card
end
##################################################################
# User Taps on a Card
##################################################################
When(/^user taps on the card with last 4 "([^"]*)"$/) do |last4|
  bankCards_functional.tap_given_card(last4)
end

##################################################################
# User hits the edit / remove button
##################################################################
Then(/^user taps on edit button$/) do
  bankCards_functional.tap_on_edit
end

##################################################################
# User Deletes a Card Successfully
##################################################################
Then(/^user should be able to delete the card successfully$/) do
  bankCards_functional.tap_on_remove_button
  bankCards_functional.tap_on_remove_popup
end

##################################################################
# User visits Bank Details Screen
##################################################################
Then(/^user can see bank detail screen$/) do
  bankCards_functional.verify_bank_details
end

##################################################################
# User visits Card Details Screen
##################################################################
Then(/^user can see card detail screen$/) do
  bankCards_functional.verify_card_details
end

Then(/^user can see card detail screen with card type "([^"]*)" and last 4 "([^"]*)"$/) do |type, last4|
  bankCards_functional.verify_given_card_details(type,last4)
end

##################################################################
# User does not see any banks or cards
##################################################################
Then(/^user should not see any bank or card$/) do
  bankCards_functional.validate_banks_invisible
end

##################################################################
# On Card Deleted, user returns to the Wallet Screen
# without the deleted card
##################################################################
Then(/^user returns to the Wallet Screen without the card$/) do
  bankCards_functional.verify_card_absent
end

##################################################################
# On Card Deleted, it should disapper from the list
##################################################################
Then(/^user returns to the Wallet Page, in which the card with last 4 "([^"]*)" shouldn't exist$/) do |last4|
  bankCards_functional.verify_given_card_absent(last4)
end

##################################################################
# User can see An Expired Card in Wallet
##################################################################
Then(/^user can see expired card$/) do
  bankCards_functional.verify_expired_card
end

##################################################################
# User Taps on an Expired Card
##################################################################
When(/^user taps on the expired card$/) do
  bankCards_functional.tap_card
end

##################################################################
# User sees an expired Card
##################################################################
Then(/^user can see expired card detail screen$/) do
  bankCards_functional.verify_expired_card_details
end

##################################################################
# User Deletes a Bank Successfully
##################################################################
Then(/^user should be able to delete the bank successfully$/) do
  bankCards_functional.tap_on_remove_button
  bankCards_functional.tap_on_remove_popup
end

##################################################################
# On Bank Deleted, user returns to the Wallet Screen
# without the deleted card
##################################################################
Then(/^user returns to the Wallet Screen without the bank$/) do
  bankCards_functional.verify_bank_absent
end
