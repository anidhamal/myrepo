##########################################
#user can see BML option
###########################################

Then(/^user should see Bill Me Later option$/) do
  ANDROID.check_text("Bill Me Later")
end