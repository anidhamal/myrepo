require_relative 'rememberme_functional'
require_relative 'login_functional'

rememberme_functional = RememberMe_Functional.new
login_functional = Login_functional.new

######################################################################
## Scenario 1: User can turn off Remember Me
######################################################################

Given(/^remembered user logs in with "([^"]*)" "([^"]*)"$/) do |email, pwd|

  NAV.goToLogin
  login_functional.login(email,pwd)
  login_functional.tapLogin(email)
  login_functional.verifyLoginSuccess

end

When(/^user turns off remember me$/) do

  NAV.goToSettings
  NAV.goToSecuritySettings
  rememberme_functional.turnRememberMeOff

end

Then(/^user sees full login while logging in$/) do

  login_functional.logoutFromSubmenu
  NAV.goToLogin
  login_functional.verifyEmailPhoneTab


end
