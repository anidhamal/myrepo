###
# Author
# Sarika Kamisetty
###

class ShopReadinessBannerUI

  STRING_ADD_CARD_PHOTO_TITLE = "Pay with your phone at some of your favorite local places"
  STRING_ADD_CARD_PHOTO_BUTTON = "Get Set Up"
  STRING_PROMO_TITLE = "Link a card to pay with your phone at the places below."
  STRING_ADD_CARD_BUTTON = "Link your card"
  STRING_ADD_PHOTO_BUTTON = "Add your photo"

  # verify readiness banner for no photo and card
  def self.verify_banner_no_card_photo
    ANDROID.check_text_exists(STRING_ADD_CARD_PHOTO_TITLE)
    ANDROID.check_text_exists(STRING_ADD_CARD_PHOTO_BUTTON)
  end

  # verify readiness banner for no card
  def self.verify_banner_no_card
    ANDROID.check_text_exists(STRING_PROMO_TITLE)
    ANDROID.check_text_exists(STRING_ADD_CARD_BUTTON)
  end

  # verify readiness banner for no photo
  def self.verify_banner_no_photo
    ANDROID.check_text_exists(STRING_PROMO_TITLE)
    ANDROID.check_text_exists(STRING_ADD_PHOTO_BUTTON)
  end
end

class ShopReadinessLandingViewUI

  # Landing view with add photo and card
  ID_SET_UP_CANCEL_BUTTON = 'cancel_button'
  STRING_LANDING_VIEW_TITLE = "Let's get set up so you can grab exclusive offers, order for pickup, or just pay at your favorite nearby places."
  STRING_ADD_CARD_LABEL = "Add Your Card"
  STRING_ADD_CARD_BUTTON = "Add a Card"
  STRING_ADD_CARD_DESC = "You'll need a way to pay, so take a moment to link your favorite debit or credit card."
  STRING_ADD_PHOTO_LABEL = "Add Your Photo"
  STRING_ADD_PHOTO_BUTTON = "Add a Photo"
  STRING_ADD_PHOTO_DESC= "Add a clear photo of your face. It's how the cashier will recognize you."

  # verify landing view
  def self.verify_landing_view
    ANDROID.wait_till_id_visible(ID_SET_UP_CANCEL_BUTTON)
    ANDROID.check_text_exists(STRING_LANDING_VIEW_TITLE)
  end

  # verify the landing view for add card
  def self.verify_add_card_view
    ANDROID.check_text_exists(STRING_ADD_CARD_LABEL)
    ANDROID.check_text_exists(STRING_ADD_CARD_DESC)
    ANDROID.check_text_exists(STRING_ADD_CARD_BUTTON)
  end

  # verify add photo landing view
  def self.verify_add_photo_view
    ANDROID.check_text_exists(STRING_ADD_PHOTO_LABEL)
    ANDROID.check_text_exists(STRING_ADD_PHOTO_DESC)
    ANDROID.check_text_exists(STRING_ADD_PHOTO_BUTTON)
  end

  # verify add card and photo landing view
  def self.verify_add_card_photo_view
    verify_landing_view
    verify_add_card_view
    verify_add_photo_view
  end

  # verify add photo flow page
  def self.verify_add_photo_flow
    ANDROID.wait_till_id_visible("wa_settings")
    ANDROID.check_text_exists("A profile photo helps merchants recognize you when you pay in-store with PayPal.")
    ANDROID.check_text_exists("View Gallery")
    ANDROID.check_text_exists("Take Photo")
  end
end