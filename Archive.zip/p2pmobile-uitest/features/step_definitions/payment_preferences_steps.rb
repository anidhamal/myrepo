require_relative 'payment_preferences_functional'

paymentpreferences_functional = PaymentPreferences_Functional.new

######################################################################
## Scenario 1:  User can change the payment preferences from settings
######################################################################


When(/^user goes to payment preferences page$/) do

  NAV.goToSettings
  NAV.goToPaymentPref

end
Then(/^user sees balance, bank and card in payment preferences view$/) do
  paymentpreferences_functional.waitForPaymentPref
end




Then(/^user is able to change payment preferences$/) do

  paymentpreferences_functional.waitForPaymentPref
  paymentpreferences_functional.verifyPaymentPref
  paymentpreferences_functional.changePayPrefToCreditCard
  paymentpreferences_functional.changePayPrefToBank

end

