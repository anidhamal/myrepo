# Author
# Steve Shenouda
# Indumathy Kesavan

require 'timeout'

class RtrAdditionalInfoFunctional

  ID_COUNTRY_SPINNER = 'country_selector'
  ID_COUNTRY_LIST_ITEM = 'generic_list_item'
  ID_NAME_EDITTEXT = 'name_field'
  ID_NEXT_BUTTON = 'next_button'


  # User changes the country in additional information page
  def self.change_country(country)
    if ANDROID.does_element_not_exist?("* text:'#{country}'")
      ANDROID.tap2("* id:'#{ID_COUNTRY_SPINNER}'")
      scroll_to_change_country(country)
      ANDROID.tap2("* text:'#{country}'")
    end
  end

  # User scrolls to select the country
  def self.scroll_to_change_country(text)
    ANDROID.wait_till_id_visible(ID_COUNTRY_LIST_ITEM)

    5.times do
      ANDROID.does_element_not_exist?("* text:'#{text}'") ? ANDROID.scroll_up : break
    end
  end

  #user enters the first name and last name
  def self.enter_recipient_info(country, fname, lname)
    ANDROID.wait_till_id_visible(ID_COUNTRY_SPINNER)
    change_country(country)
    ANDROID.enter_text_by_id(fname + ' ' + lname, ID_NAME_EDITTEXT)
    ANDROID.tap2("* id:'#{ID_NEXT_BUTTON}'")
  end
end

class RtrReviewFunctional

  ID_PAYMENT_METHOD_EDITTEXT = 'text1'
  ID_SENDER_FEES = 'send_fee_id'
  ID_SENDER_TOTAL = 'send_total_id'
  ID_RECIPIENT_AMOUNT = 'recipient_amount_id'
  ID_RECIPIENT_FEES = 'recipient_fee_id'
  ID_RECIPIENT_TOTAL = 'recipient_total_id'
  ID_SEND_MONEY_BUTTON = 'ctn_button'
  ID_CONVERSION_RATE = 'conversion_amount_id'
  ID_SENDER_AMOUNT = 'send_amount_id'
  ID_CARD = 'text1'
  ID_REVIEW_PAYMENT_METHOD_SPINNER = 'payment_method_selector'

  # user verify the payment method in review page
  def self.verify_payment_method(funding)
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_exists("* id:'#{ID_PAYMENT_METHOD_EDITTEXT}' * text:'#{funding}'}")
  end

  #verifies without recipient fees
  def self.verify_transaction_details_1(sender_amount, sender_fees, sender_total, recipient_amount, recipient_total)
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_AMOUNT}' * text:'#{sender_amount}'")
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_FEES}' * text:'#{sender_fees}'")
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_TOTAL}' * text:'#{sender_total}'")
    ANDROID.check_an_element_exists("* id:'#{ID_RECIPIENT_AMOUNT}' * text:'#{recipient_amount}'")
    ANDROID.check_an_element_does_not_exist("* id:'#{ID_RECIPIENT_FEES}'")
    ANDROID.check_an_element_exists("* id:'#{ID_RECIPIENT_TOTAL}' * text:'#{recipient_total}'")
  end

  # verifies without sender fees
  def self.verify_transaction_details_2(sender_amount, sender_total, recipient_amount, recipient_fees, recipient_total)
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_AMOUNT}' * text:'#{sender_amount}'")
    ANDROID.check_an_element_does_not_exist("* id:'#{ID_SENDER_FEES}'")
    ANDROID.check_an_element_exists("* id:'#{ID_SENDER_TOTAL}' * text:'#{sender_total}'")
    ANDROID.check_an_element_exists("* id:'#{ID_RECIPIENT_AMOUNT}' * text:'#{recipient_amount}'")
    ANDROID.check_an_element_exists("* id:'#{ID_RECIPIENT_FEES}'* text:'#{recipient_fees}'")
    ANDROID.check_an_element_exists("* id:'#{ID_RECIPIENT_TOTAL}' * text:'#{recipient_total}'")
  end

  # user taps on send money
  def self.tap_send_money
    ANDROID.tap2("* id:'#{ID_SEND_MONEY_BUTTON}'")
  end

  # user verifies the conversion rate
  def self.verify_conversion_rate(rate)
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_BUTTON)
    ANDROID.check_an_element_exists("* id:'#{ID_CONVERSION_RATE}' * {text CONTAINS '#{rate}'}")
  end

  #user verify card number
  def self.verify_card_number
    ANDROID.wait_till_id_visible(ID_SEND_MONEY_BUTTON)
    ppuser = PPUSER.getPPUserInfo
    card_last4 = 'x-' + ppuser['card_last4']
    ANDROID.check_an_element_exists("* id:'#{ID_CARD}' * {text CONTAINS '#{card_last4}'}")
  end

  #user changes the funding type
  def self.change_funding_type
    ppuser = PPUSER.getPPUserInfo
    card_last4 = 'x-' + ppuser['card_last4']
    ANDROID.tap2("* id:'#{ID_REVIEW_PAYMENT_METHOD_SPINNER}'")
    ANDROID.tap2("* id:'#{ID_CARD}' * {text CONTAINS '#{card_last4}'}")
  end
end

class RtrActivityFunctional

  ID_ACTIVITY_DETAILS_STATUS = 'dcPPHistoryDetailsStatusValue'
  ID_ACTIVITY_DETAILS_AMOUNT = 'dcPPHistoryDetailsAmountValue'
  ID_YES_BUTTON = 'button1'

  # user verifies the transcation details from activity page
  def self.verify_activity_transaction_details(amount, status, recipient)
    ANDROID.tap2("* text:'#{recipient}'")
    ANDROID.wait_till_id_visible(ID_ACTIVITY_DETAILS_AMOUNT)
    sleep 1 # TODO : Find better way
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_AMOUNT}' * {text CONTAINS '#{amount}'}")
    ANDROID.check_an_element_exists("* id:'#{ID_ACTIVITY_DETAILS_STATUS}' * text:'#{status}'")
    # TODO : once message is fixed for RTR bug, call the send money method instead
  end

  def self.taps_set_start_page
    ANDROID.tap2("* id:'#{ID_YES_BUTTON}'")
  end
end

