class TwoFactorAuthFunctional
  ID_PAGE_TITLE = 'title_label'
  ID_CODE_TEXT_FIELD = 'security_code_input_label'
  ID_CONTINUE_BUTTON = 'submit_button'
  ID_2FA_CODE_RESEND = 'try_again_label'
  ID_PHONE_NUMBER = 'phone_number_label'
  ID_SEND_TEXT_BUTTON = 'send_text_button'
  ID_UNLOCK_BUTTON = 'unlock_button'
  ID_CALL_US_BUTTON = 'call_us_button'

  # user verifies 2fa screen
  def self.verify_2fa_screen
    ANDROID.wait_till_id_visible(ID_PAGE_TITLE)
    ANDROID.check_id_exists(ID_CODE_TEXT_FIELD)
    ANDROID.check_id_exists(ID_CONTINUE_BUTTON)
    ANDROID.check_id_exists(ID_2FA_CODE_RESEND)
  end

  # user gets the sms number
  def self.get_sms_number
    text = ANDROID.get_text_from_id('message_label').join
    text.delete('.').split('-').last[0..3]
  end

  # user enters the code in 2fa screen
  def self.enter_security_code(code)
    ANDROID.wait_till_id_visible(ID_CODE_TEXT_FIELD)
    ANDROID.tap2("* id:'#{ID_CODE_TEXT_FIELD}'")
    ANDROID.clear_text(1)
    ANDROID.enter_text(code, 1)
  end

  # user taps on sumbit button after enetring the code
  def self.tap_continue_button
    ANDROID.tap2("* id:'#{ID_CONTINUE_BUTTON}'")
  end

  # user taps in second phone number
  def self.tap_second_number
    ANDROID.tap2("* id:'#{ID_PHONE_NUMBER}' index:1")
  end

  # user taps on send text button in phone number list page
  def self.tap_send_text_button
    ANDROID.tap2("* id:'#{ID_SEND_TEXT_BUTTON}'")
  end

  # user verifies locked screen after entering the wrong code more than 6 times
  def self.verify_locked_screen
    ANDROID.wait_till_id_visible(ID_PAGE_TITLE)
    ANDROID.check_id_exists(ID_UNLOCK_BUTTON)
    ANDROID.check_id_exists(ID_CALL_US_BUTTON)
  end
end