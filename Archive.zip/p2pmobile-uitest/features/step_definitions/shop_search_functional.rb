###
# Author
# Sarika Kamisetty
###

class ShopSearchFunctional

  ID_SEARCH_BUTTON = 'menu_search'
  ID_SEARCH_FIND_QUERY = 'search_src_text_find'
  ID_SEARCH_CLEAR_QUERY = 'search_close_btn_find'
  ID_SEARCH_LOCATION_QUERY = 'search_src_text_near'

  ID_SEARCH_FIND_LABEL = 'label_find'
  ID_SEARCH_NEAR_LABEL = 'label_near'

  ID_MERCHANT_NAME = 'checkin_merchant_name'
  ID_MERCHANT_ADDRESS = 'checkin_merchant_address'
  ID_MERCHANT_LOGO = 'checkin_merchant_logo'
  ID_MERCHANT_OFFER = 'checkin_merchant_offer'
  ID_LIST_PHONE_BUTTON = 'checkin_merchant_button'
  ID_LIST_DISTANCE_LABEL = 'distance'
  ID_LIST_ORDER_BUTTON = 'right_button_text'
  ID_MERCHANT_ADDRESS_ROW = 'checkin_merchant_address_row1'
  ID_HOME = 'home'

  ID_SEARCH_OPTIONS = 'shop_search_suggestion_text'

  # Verify search view
  def self.verify_search_view
    ANDROID.wait_till_id_visible(ID_SEARCH_FIND_LABEL)
    ANDROID.check_id_exists(ID_SEARCH_NEAR_LABEL)
    ANDROID.check_id_exists(ID_SEARCH_FIND_QUERY)
    ANDROID.check_id_exists(ID_SEARCH_CLEAR_QUERY)
    ANDROID.check_id_exists(ID_SEARCH_LOCATION_QUERY)
  end

  # Tap on first merchant from the search result view
  def self.tap_on_merchant(merchant)
    ANDROID.tap2("* id:'#{ID_MERCHANT_NAME}' * {text CONTAINS '#{merchant}'}")
  end

  # Traverse to merchant details from search result
  def self.verify_merchant_details(merchant)
    ANDROID.wait_till_element_visible("* id:'#{ID_MERCHANT_NAME}' * {text CONTAINS '#{merchant}'}")
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS)
    ANDROID.check_id_exists(ID_MERCHANT_LOGO)
  end

  # Tap on search button in merchant listing view
  def self.tap_on_search_button
    ANDROID.tap2("* id:'#{ID_SEARCH_BUTTON}'")
  end

  # Search merchant with either by merchant name or location
  def self.search_merchant(merchant, option="Find")
    if option.include? "Near"
      ANDROID.enter_text_by_id(merchant, ID_SEARCH_LOCATION_QUERY)
      tap_on_first_address
    else
      ANDROID.enter_text_by_id(merchant, ID_SEARCH_FIND_QUERY)
    end
  end

  # Search merchant with filter and merchant name
  def self.search_merchant_with_filter(merchant, filter, option="Find")
    select_search_filter(filter)
    search_merchant(merchant, option)
  end

  # User selects either offers/pay by phone/order filter in the search view
  def self.select_search_filter(search_filter)
    if search_filter == "Places with Offers"
      ANDROID.tap2("* id:'#{ID_SEARCH_OPTIONS}' index:0")
    elsif search_filter == "Pay by Phone"
      ANDROID.tap2("* id:'#{ID_SEARCH_OPTIONS}' index:1")
    else
      ANDROID.tap2("* id:'#{ID_SEARCH_OPTIONS}' index:2")
    end
  end

  # Verify the search results - merchant name and address
  def self.verify_search_result(name, address)
    ANDROID.wait_till_id_visible(ID_SEARCH_MERCHANT_LOGO)
    ANDROID.assert_element_exist("* id:'#{ID_MERCHANT_NAME}' * text:'#{name}'")
    ANDROID.assert_element_exist("* id:'#{ID_MERCHANT_ADDRESS_ROW}' * text:'#{address}'")
  end

  # verify the options displayed in search view
  def self.verify_search_options
    # Places with Offers
    ANDROID.assert_element_exist("* id:'#{ID_SEARCH_OPTIONS}' index:0")
    # Pay by Phone
    ANDROID.assert_element_exist("* id:'#{ID_SEARCH_OPTIONS}' index:1")
    # Order
    ANDROID.assert_element_exist("* id:'#{ID_SEARCH_OPTIONS}' index:2")
  end

  # select the first address from list of addresses
  def self.tap_on_first_address
    ANDROID.tap2("* id:'#{ID_SEARCH_LOCATION_QUERY}'")
    ANDROID.tap2("* id:'#{ID_SEARCH_OPTIONS}' index:1")
  end

  # verify address in merchant details screen
  def self.verify_address(address)
    ANDROID.wait_till_id_visible(ID_MERCHANT_NAME)
    ANDROID.assert_element_exist("* id:'#{ID_MERCHANT_ADDRESS}' * text:'#{address}'")
  end

  # verify the search list view displays merchant with offers
  def self.verify_list_with_offers
    ANDROID.wait_till_id_visible(ID_MERCHANT_OFFER)
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS_ROW)
    ANDROID.check_id_exists(ID_MERCHANT_NAME)
    ANDROID.check_id_exists(ID_LIST_PHONE_BUTTON)
    ANDROID.check_id_exists(ID_LIST_DISTANCE_LABEL)
  end

  # verify the search list view displays "Pay with Phone" merchants
  def self.verify_list_with_phone
    ANDROID.wait_till_id_visible(ID_LIST_PHONE_BUTTON)
    ANDROID.check_id_exists(ID_MERCHANT_NAME)
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS_ROW)
  end

  # verify the search list view displays "Order" merchants
  def self.verify_list_with_order
    ANDROID.wait_till_id_visible(ID_LIST_ORDER_BUTTON)
    ANDROID.check_id_exists(ID_MERCHANT_NAME)
    ANDROID.check_id_exists(ID_MERCHANT_ADDRESS_ROW)
  end

  # Cancel/clear search results in search view or search list view
  def cancel_search
    ANDROID.tap2("* id:'#{ID_SEARCH_CLEAR_QUERY}'")
  end

  # Tap 'back' button on search list view to go back to search view
  def tap_back_to_search_view
    ANDROID.tap2("* id:'#{ID_HOME}'")
  end

  # Tap hardware 'back' button on search view to go back to merchant list
  def tap_back_to_merchant_list
    ANDROID.hardware_back
  end
end