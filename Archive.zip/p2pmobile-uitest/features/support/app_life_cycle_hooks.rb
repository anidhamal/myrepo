require 'calabash-android/management/adb'
require 'calabash-android/management/app_installation'

Before do |scenario|
  #shutdown_test_server
  case scenario
    when Cucumber::Ast::Scenario
      Kernel.puts "SCENARIO: #{scenario.description}"
    when Cucumber::Ast::OutlineTable::ExampleRow
      Kernel.puts "SCENARIO: #{scenario.name}"
  end

  if $app_Installed == FALSE && INSTALL == "TRUE"
    uninstall_apps
    Kernel.puts "First time install... Test app path: #{ENV["TEST_APP_PATH"]}.... App Path: #{ENV["APP_PATH"]}"
    install_app(ENV["TEST_APP_PATH"])
    install_app(ENV["APP_PATH"])
    $app_Installed = TRUE

    set_app_preferences
    sleep 1
  end

  begin
    # Might need to kill process in future? Just to get rid of stray process ?
    #system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --esn killprocess")
    #shutdown_test_server
    remove_account
    start_test_server_in_background
  rescue
    puts "Error: App did not start. Trying to reinstall apps..."
    Kernel.puts "Error: App did not start. Trying to reinstall apps..."
    reinstall_apps
    set_app_preferences
    sleep 1
    start_test_server_in_background
  end
  start_log
end

After do |scenario|
  # after each scenario is completed, empty the contents of ppuser hash
  PPUSER.flush_ppuser

  # Take Screenshot if there was a failure
  if scenario.failed?
    case scenario
      when Cucumber::Ast::Scenario
        Kernel.puts "FAILED SCENARIO: #{scenario.description}"
      when Cucumber::Ast::OutlineTable::ExampleRow
        Kernel.puts "FAILED SCENARIO: #{scenario.name}"
    end

    take_logs_screenshots
  end

  @scenario_tags = scenario.source_tag_names

  if @scenario_tags.include?('@locale') and !IQA
    Kernel.puts "Resetting locale back to US"
    ANDROID.change_locale("en_US")
  end

  # At the end of each Scenario take a screen shot of last page
  if IQA
    ANDROID.take_screenshot
  end

  # updates test case results in ET after scenario is executed
  PPUSER.update_ET(scenario)

end

# Set App Preferences after installing and res-installing the app
def set_app_preferences
  if (STAGE != "live")
    _STAGE="--esn stage -e endpoint #{STAGE}"
  else
    _STAGE="--esn live"
  end
  _command="adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity #{_STAGE} --ez haveShownShopCoachMarks true --ez AcceptedLicense true --ez haveShownOverlay true --ez PrefsSuppressFeedbackDialogs true"
  puts "APP preferences: #{_command}"
  puts "SLEPT 2 SECONDS 1"
  system (_command)
  puts "SLEPT 2 SECONDS 2"
  sleep 2
  puts "SLEPT 2 SECONDS 3"
end

# Remove account after each scenario is executed as it saves in the device account
def remove_account
  system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --esn remove-account")
  #system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --esn remove-account")
  #system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --esn remove-account")
  sleep 2
  kill_app_process
  sleep 2
end

def kill_app_process
  system ("adb -s #{DEVICE} shell am start -n com.paypal.android.p2pmobile/com.paypal.android.p2pmobile.activity.QADevConfigActivity --esn killprocess")
end

def start_log
  system("adb -s #{DEVICE} logcat com.paypal.android.p2pmobile:D > #{PPUSER.get_android_log_path} &")
end

def take_logs_screenshots
  time = Time.now.strftime("%F_%H-%M-%S")

  screenshot_file = "P2P#{time}.png"
  log_file = "P2P#{time}.txt"

  #Create the full path
  log_path= Dir.pwd + "/logs/" + log_file

  # Add the last 500 lines of the System Log to the Output if the Job Fails
  filename_for_system_logs = PPUSER.get_android_log_path
  `tail -500 #{filename_for_system_logs} >> #{log_path}`

  screenshot_embed(:name => "screenshots/#{screenshot_file}")
  embed("logs/#{log_file}", 'image/png', "logs")

  Kernel.puts "Screenshot and logs captured"
end