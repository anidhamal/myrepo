require 'calabash-android/cucumber'
require_relative '../step_definitions/nav5x'
require_relative '../step_definitions/android'
require_relative '../../features/uitest-support/step_definitions/PPUtils'
require 'rubygems'
require 'yaml'

#Setup screenshot path for calabash
SCREENSHOT_PATH = "screenshots/"

if (ENV['SCREENSHOTS'])
  SCREENSHOTS = true
  $snapshots_container = Array.new
else
  SCREENSHOTS = false
end

# Determine the user -
USERNAME = ENV['USER']
puts "Running Automation as - #{ENV['USER']}"

# Set Default stage here -
if (ENV['STAGE'])
  STAGE = ENV['STAGE']
else
  STAGE = "mb017.stage"
end

STAGEURL = "stage2" + STAGE.split('.')[0] + ".qa.paypal.com"

puts "Running Automation on stage - #{STAGE} and stageUrl - #{STAGEURL}"

# Default Install property set to true
$app_Installed = FALSE
if (ENV['INSTALL'])
  INSTALL = ENV['INSTALL'].upcase
else
  INSTALL = "TRUE"
end

# get the connected devices
devices = `adb devices`
# hack to get the number of connected devices
num_of_devices = devices.count("\t")

if ENV["ADB_DEVICE_ARG"]
  DEVICE = ENV["ADB_DEVICE_ARG"]
elsif num_of_devices == 1
  start_index = devices.index("\n") + 1
  end_index = devices.index("\t") - 1
  DEVICE = devices[start_index..end_index]
else
  raise "#{num_of_devices} devices connected. Please specify ADB_DEVICE_ARG=SERIAL"
end

#For IQA testing this flag is set to true
if (ENV['IQA'])
  IQA = true
else
  IQA = false
end

##########################################
###ETSYNC Properties
##########################################
ETSYNC=ENV['ET_SYNC']

if ETSYNC == "true"
  if ENV['ET_FOLDER']
    ET_PATH=ENV['ET_FOLDER']
    puts "ETFolder: "+ET_PATH
    ARR = ET_PATH.split("/")
    puts "This is Array:"+ARR[0]+ARR[1]+ARR[2]

  end

end

#navigation stack gets initialized here
NAV=Nav5x.instance

#Core methods gets initialized here
ANDROID = Android.instance

# Set system wide time out here
if (ENV['TIMEOUT'])
  TIMEOUT = ENV['TIMEOUT'].to_i
else
  TIMEOUT = 30
end

puts "Automation time out limit - #{TIMEOUT} seconds"


############################################################################################################
# Method Name: setUpSSH
# Parameters :
# Description: The method sets up the stage variables
#############################################################################################################
begin
  puts ENV['AUTO']
  if ENV['AUTO']
    username = '_wallet_nativeuser'
  else
    username = USERNAME
  end
  PPUSER = PPUtils.new(username, STAGEURL)
  if ( File.exists?(STAGE+"_data_map.yaml"))
    LIVE_DATA_MAP = YAML.load_file(STAGE+"_data_map.yaml")
  else
    LIVE_DATA_MAP = {}
  end
end

############################################################################################################
### PPTOUCH PROPERTIES
############################################################################################################

  if ENV['PPTOUCH_APP_PATH']
    PPTOUCH_APP_PATH=ENV['PPTOUCH_APP_PATH']
    PPTOUCH_TEST_APP_PATH=ENV['PPTOUCH_TEST_APP_PATH']
    puts "Looks like you are running PPTouch, please add 2 variables, PPTOUCH_APP_PATH and PPTOUCH_TEST_APP_PATH to the command line args."
  else
    puts "Using Built in PPTOUCH APP"
    PPTOUCH_APP_PATH="pptouch/workspace-release-unaligned.apk"
    PPTOUCH_TEST_APP_PATH="pptouch/ea917e9c41a1391b023121f724ed09d6_0.4.21.apk"
  end

