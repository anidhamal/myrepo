#require 'calabash-android/management/app_installation'
#
#AfterConfiguration do |config|
#FeatureNameMemory.feature_name = nil
#end
#
#$app_Installed = FALSE
#
#Before do |scenario|
#  @scenario_is_outline = (scenario.class == Cucumber::Ast::OutlineTable::ExampleRow)
#  if @scenario_is_outline
#    scenario = scenario.scenario_outline
#    feature_name = scenario.feature.title
#  else
#    feature_name = scenario.feature.title
#  end
#
#
#
#  if (FeatureNameMemory.feature_name != feature_name \
#      or ENV["RESET_BETWEEN_SCENARIOS"] == "1")  &&  $app_Installed == FALSE
#    if ENV["RESET_BETWEEN_SCENARIOS"] == "1"
#      log "New scenario - reinstalling apps"
#    else
#      log "First scenario in feature - reinstalling apps"
#    end
#
#    #uninstall_apps
#    #install_app(ENV["TEST_APP_PATH"])
#    install_app(ENV["APP_PATH"])
#    FeatureNameMemory.feature_name = feature_name
#    $app_Installed = TRUE
#FeatureNameMemory.invocation = 1
#  else
#    FeatureNameMemory.invocation += 1
#  end
#end
#
#FeatureNameMemory = Class.new
#class << FeatureNameMemory
#  @feature_name = nil
#  attr_accessor :feature_name, :invocation
#end
#
##$app_Installed = FALSE
##Before do |scenario|
##  # add support for ScenarioOutlines
##  if scenario.respond_to? :scenario_outline
##    feature_name = scenario.scenario_outline.feature.name
##  else
##    feature_name = scenario.feature.name
##  end
##
##  if FeatureNameMemory.feature_name != feature_name && $app_Installed == FALSE
##    log "Is first scenario - reinstalling apps"
##    uninstall_apps
##    install_app(ENV["TEST_APP_PATH"])
##    install_app(ENV["APP_PATH"])
##    FeatureNameMemory.feature_name = feature_name
##    $app_Installed = TRUE
##  end
##end