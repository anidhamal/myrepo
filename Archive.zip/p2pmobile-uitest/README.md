# p2pmobile-uitest

[Calabash for Android][1] based functional UI tests for [p2pmobile][2].

## Prerequisites

- [Ruby][10]
- [Git][7]
- [Apache Ant][8]
- [Android SDK][9]
 - Set `ANDROID_HOME` environment variable to the location of your sdk.

## First-time setup

#### Clone the repo
    
    $ git clone git@github.paypal.com:android/p2pmobile-uitest.git
    $ git submodule update --init

#### Install bundler gem

    $ sudo gem install bundler

#### Install all required gems (from the root of the cloned repo)

    $ bundle install
    
#### Download debug.keystore 

- Download [debug.keystore][11] and copy it here `~/.android/`

## Running the tests

#### Download the p2pmobile apk

- [p2pmobile-build][3] (from the develop branch)
- [p2pmobile-build-pr][4] (from a pull request)
- [p2pmobile-build-release][5] (from a release branch)

If you have the `p2p.sh` script set up, you can download the latest apk
from the develop branch into the current directory by running

    $ p2p download

#### Sign the .apk file

If you are testing a **non-debug** build, or if you did not [set up your debug
key][6], you need to resign the apk:

    $ calabash-android resign <apk>

#### Set the stage server

    $ export STAGE=md026.stage

#### Run a Cucumber feature file

    $ calabash-android run <apk> features/launch.feature

## Hardware Accelerator for Emulator

1. Go to Android SDK Manager
- Select x86 System Images for each API level you use (Make sure to get the Google x86 API as well if you use that)
- Select Intel x86 Emulator Accelerator (HAXM) under Extras
- Download and Install these.
- Go to ANDROID_HOME/extras/intel/Hardware_Accelerated_Execution_Manager and open IntelHAXM.dmg. Follow the setup instructions.
- If you have Mac OSX 10.9 (Mavericks), go to http://software.intel.com/en-us/android/articles/intel-hardware-accelerated-execution-manager and download the Hotfix for OS X 10.9 only (1.0.7)
- Unzip and open the .dmg file inside. Follow set up instructions.
- Note: It will say you already have it installed, just continue. At the end you may get a message about an external vendor. Just press ok and continue.
- Go to Android Virtual Device Manager.
- Create a new device with the API of your choice and select the x86 system image
- At the bottom, check “Use Host GPU”.
- You now should have a fast Android Emulator ready to run.

[1]: https://github.com/calabash/calabash-android
[2]: https://github.paypal.com/android/p2pmobile
[3]: http://androidciserv/jenkins/job/p2pmobile-build
[4]: http://androidciserv/jenkins/job/p2pmobile-build-pr
[5]: http://androidciserv/jenkins/job/p2pmobile-build-release
[6]: https://github.paypal.com/android/p2pmobile#set-up-debugkeystore
[7]: http://git-scm.com/
[8]: http://ant.apache.org/
[9]: http://developer.android.com/sdk/index.html
[10]: https://www.ruby-lang.org/en/
[11]: https://github.paypal.com/android/p2pmobile/raw/develop/etc/debug.keystore
